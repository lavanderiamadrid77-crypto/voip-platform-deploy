import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { ActualizarTenantDto, CrearTenantDto } from './dto/tenant.dto';
import { TenantsService } from './tenants.service';

@ApiTags('tenants')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('api/tenants')
export class TenantsController {
  constructor(private readonly service: TenantsService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN, Rol.RESELLER)
  listar() {
    return this.service.listar();
  }

  @Get(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN, Rol.RESELLER)
  obtener(@Param('id') id: string) {
    return this.service.obtener(id);
  }

  @Post()
  @Roles(Rol.SUPER_ADMIN, Rol.RESELLER)
  crear(@Body() dto: CrearTenantDto) {
    return this.service.crear(dto);
  }

  @Patch(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN, Rol.RESELLER)
  actualizar(@Param('id') id: string, @Body() dto: ActualizarTenantDto) {
    return this.service.actualizar(id, dto);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN)
  eliminar(@Param('id') id: string) {
    return this.service.eliminar(id);
  }
}
