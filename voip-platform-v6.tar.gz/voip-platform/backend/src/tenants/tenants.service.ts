import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { ActualizarTenantDto, CrearTenantDto } from './dto/tenant.dto';

@Injectable()
export class TenantsService {
  constructor(
    @InjectRepository(Tenant) private readonly repo: Repository<Tenant>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  listar(): Promise<Tenant[]> {
    return this.repo.find({ order: { creadoEn: 'DESC' } });
  }

  async obtener(id: string): Promise<Tenant> {
    const tenant = await this.repo.findOne({ where: { id } });
    if (!tenant) throw new NotFoundException('Tenant no encontrado');
    return tenant;
  }

  async crear(dto: CrearTenantDto): Promise<Tenant> {
    const existe = await this.repo.findOne({ where: { subdominio: dto.subdominio } });
    if (existe) throw new ConflictException('Ese subdominio ya está en uso');
    const tenant = this.repo.create(dto);
    const guardado = await this.repo.save(tenant);
    await this.freeswitch
      .escribirDominioTenantXml({ subdominio: guardado.subdominio, canalesMax: guardado.canalesMax })
      .catch(() => undefined); // FreeSWITCH puede no estar disponible aún; se puede re-provisionar luego
    return guardado;
  }

  async actualizar(id: string, dto: ActualizarTenantDto): Promise<Tenant> {
    const tenant = await this.obtener(id);
    Object.assign(tenant, dto);
    return this.repo.save(tenant);
  }

  async eliminar(id: string): Promise<void> {
    const tenant = await this.obtener(id);
    await this.freeswitch.eliminarDominioTenantXml(tenant.subdominio).catch(() => undefined);
    await this.repo.remove(tenant);
  }
}
