import { IsBoolean, IsHexColor, IsInt, IsOptional, IsString, Matches, Min } from 'class-validator';

export class CrearTenantDto {
  @IsString()
  nombre: string;

  @IsString()
  @Matches(/^[a-z0-9-]{3,32}$/, {
    message: 'El subdominio debe tener solo minúsculas, números y guiones (3-32 caracteres)',
  })
  subdominio: string;

  @IsOptional()
  @IsHexColor()
  colorPrimario?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  canalesMax?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  extensionesMax?: number;
}

export class ActualizarTenantDto {
  @IsOptional()
  @IsString()
  nombre?: string;

  @IsOptional()
  @IsHexColor()
  colorPrimario?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  canalesMax?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  extensionesMax?: number;

  @IsOptional()
  @IsBoolean()
  activo?: boolean;
}
