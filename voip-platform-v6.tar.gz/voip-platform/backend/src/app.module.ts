import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { CdrModule } from './cdr/cdr.module';
import { Cdr } from './common/entities/cdr.entity';
import { Extension } from './common/entities/extension.entity';
import { Tenant } from './common/entities/tenant.entity';
import { Trunk } from './common/entities/trunk.entity';
import { User } from './common/entities/user.entity';
import { ExtensionsModule } from './extensions/extensions.module';
import { FreeswitchModule } from './freeswitch/freeswitch.module';
import { TenantsModule } from './tenants/tenants.module';
import { TrunksModule } from './trunks/trunks.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        host: config.get<string>('DB_HOST', 'postgres'),
        port: config.get<number>('DB_PORT', 5432),
        username: config.get<string>('DB_USER', 'voip'),
        password: config.get<string>('DB_PASSWORD', 'voip'),
        database: config.get<string>('DB_NAME', 'voip_platform'),
        entities: [Tenant, User, Extension, Trunk, Cdr],
        // synchronize=true es aceptable para el entorno de PRUEBA en VM de
        // este MVP; en producción real se debe migrar a TypeORM migrations.
        synchronize: true,
      }),
    }),
    AuthModule,
    TenantsModule,
    ExtensionsModule,
    TrunksModule,
    CdrModule,
    FreeswitchModule,
  ],
})
export class AppModule {}
