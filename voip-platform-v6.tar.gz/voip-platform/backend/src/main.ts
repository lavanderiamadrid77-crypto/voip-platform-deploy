import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import 'reflect-metadata';
import { AppModule } from './app.module';

async function bootstrap() {
  // eslint-disable-next-line no-console
  console.log('[bootstrap] Creando app Nest...');
  const app = await NestFactory.create(AppModule, { cors: true });
  // eslint-disable-next-line no-console
  console.log('[bootstrap] App Nest creada. Configurando pipes globales...');
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  // eslint-disable-next-line no-console
  console.log('[bootstrap] Generando documento Swagger...');
  const config = new DocumentBuilder()
    .setTitle('Plataforma VoIP Multi-Tenant — API')
    .setDescription('API REST para gestión de tenants, extensiones, trunks, CDR y más')
    .setVersion('0.1.0')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, config);
  // eslint-disable-next-line no-console
  console.log('[bootstrap] Documento Swagger generado. Montando en /api/docs...');
  SwaggerModule.setup('api/docs', app, document);
  // eslint-disable-next-line no-console
  console.log('[bootstrap] Swagger montado. Llamando a app.listen()...');

  const port = process.env.PORT ? Number(process.env.PORT) : 3000;
  await app.listen(port, '0.0.0.0');
  // eslint-disable-next-line no-console
  console.log(`Backend escuchando en http://0.0.0.0:${port} — Swagger en /api/docs`);
}
bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('[bootstrap] ERROR FATAL AL ARRANCAR:', err);
  process.exit(1);
});
