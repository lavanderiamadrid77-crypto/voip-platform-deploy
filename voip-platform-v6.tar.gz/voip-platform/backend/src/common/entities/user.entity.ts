import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Tenant } from './tenant.entity';

export enum Rol {
  SUPER_ADMIN = 'super_admin',
  ADMIN = 'admin',
  RESELLER = 'reseller',
  USUARIO = 'usuario',
}

@Entity('users')
@Index(['email'], { unique: true })
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Nulo para super_admin (no pertenece a ningún tenant) */
  @ManyToOne(() => Tenant, { nullable: true, onDelete: 'CASCADE' })
  tenant?: Tenant;

  @Column({ nullable: true })
  tenantId?: string;

  @Column()
  email: string;

  @Column()
  passwordHash: string;

  @Column({ type: 'enum', enum: Rol, default: Rol.USUARIO })
  rol: Rol;

  @Column({ default: 'es' })
  idiomaPreferido: string;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;
}
