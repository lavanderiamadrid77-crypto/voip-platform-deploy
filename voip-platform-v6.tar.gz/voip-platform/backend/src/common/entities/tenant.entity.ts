import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Extension } from './extension.entity';
import { Trunk } from './trunk.entity';

/**
 * Un "tenant" es un cliente de la plataforma con su propia centralita
 * virtual aislada. Cada tenant se mapea 1:1 a un dominio SIP dentro de
 * FreeSWITCH (mod_sofia soporta múltiples dominios de forma nativa).
 */
@Entity('tenants')
export class Tenant {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  nombre: string;

  /** Subdominio SIP y de dashboard, ej: "acme" -> acme.plataforma.local */
  @Column({ unique: true })
  subdominio: string;

  @Column({ nullable: true })
  dominioPersonalizado?: string;

  @Column({ nullable: true })
  logoUrl?: string;

  @Column({ default: '#4f46e5' })
  colorPrimario: string;

  @Column({ default: 10 })
  canalesMax: number;

  @Column({ default: 50 })
  extensionesMax: number;

  @Column({ default: 90 })
  retencionGrabacionesDias: number;

  @Column({ default: true })
  activo: boolean;

  @OneToMany(() => Extension, (ext) => ext.tenant)
  extensiones: Extension[];

  @OneToMany(() => Trunk, (trunk) => trunk.tenant)
  trunks: Trunk[];

  @CreateDateColumn()
  creadoEn: Date;

  @UpdateDateColumn()
  actualizadoEn: Date;
}
