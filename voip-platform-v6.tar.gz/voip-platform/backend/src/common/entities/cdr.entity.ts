import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('cdr')
@Index(['tenantId', 'fechaHoraInicio'])
export class Cdr {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column({ nullable: true })
  callUuid?: string;

  @Column()
  origen: string;

  @Column()
  destino: string;

  @Column()
  fechaHoraInicio: Date;

  @Column({ default: 0 })
  duracionSegundos: number;

  @Column({ default: 'desconocido' })
  estado: string;

  @Column({ default: 0 })
  costo: number;

  @Column({ nullable: true })
  trunkUsado?: string;

  @Column({ nullable: true })
  grabacionUrl?: string;

  @CreateDateColumn()
  creadoEn: Date;
}
