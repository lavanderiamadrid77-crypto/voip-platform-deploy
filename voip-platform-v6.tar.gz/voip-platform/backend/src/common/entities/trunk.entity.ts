import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Tenant } from './tenant.entity';

@Entity('trunks')
export class Trunk {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Nulo = trunk compartido a nivel plataforma, disponible para varios tenants */
  @ManyToOne(() => Tenant, (tenant) => tenant.trunks, { nullable: true, onDelete: 'CASCADE' })
  tenant?: Tenant;

  @Column({ nullable: true })
  tenantId?: string;

  @Column()
  nombre: string;

  @Column()
  proveedor: string;

  @Column()
  host: string;

  @Column({ default: 5060 })
  puerto: number;

  @Column({ nullable: true })
  usuario?: string;

  @Column({ nullable: true })
  passwordCifrada?: string;

  @Column({ default: 1 })
  prioridad: number;

  @Column({ default: 0 })
  costoPorMinuto: number;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;
}
