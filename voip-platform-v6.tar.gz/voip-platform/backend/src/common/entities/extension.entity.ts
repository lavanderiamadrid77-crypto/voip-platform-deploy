import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Tenant } from './tenant.entity';

export enum TipoExtension {
  ESCRITORIO = 'escritorio',
  SOFTPHONE = 'softphone',
  MOVIL = 'movil',
  RING_GROUP = 'ring_group',
  COLA = 'cola',
  IVR = 'ivr',
  BUZON = 'buzon',
  CONFERENCIA = 'conferencia',
}

@Entity('extensions')
@Index(['tenantId', 'numero'], { unique: true })
export class Extension {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Tenant, (tenant) => tenant.extensiones, { onDelete: 'CASCADE' })
  tenant: Tenant;

  @Column()
  tenantId: string;

  /** Número/usuario SIP dentro del dominio del tenant */
  @Column()
  numero: string;

  @Column()
  nombre: string;

  @Column({ type: 'enum', enum: TipoExtension, default: TipoExtension.SOFTPHONE })
  tipo: TipoExtension;

  /** Contraseña SIP en claro solo se ve una vez al crearla; aquí se guarda cifrada */
  @Column()
  passwordCifrada: string;

  @Column({ default: 'OPUS,G722,PCMU,PCMA' })
  codecs: string;

  @Column({ default: true })
  webrtcHabilitado: boolean;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;
}
