import * as crypto from 'crypto';

/**
 * Cifrado simétrico reversible (AES-256-GCM) para secretos que la
 * plataforma necesita poder volver a leer en claro (contraseñas SIP de
 * extensiones, credenciales de trunks) para regenerar la configuración de
 * FreeSWITCH en caso de pérdida del volumen o migración a otro servidor.
 *
 * Esto es DISTINTO de bcrypt (usado para passwordHash de usuarios del
 * panel): esos son de un solo sentido porque nunca necesitamos recuperar
 * la contraseña de login en claro.
 *
 * La clave se toma de la variable de entorno APP_ENCRYPTION_KEY (32 bytes
 * en base64). En docker-compose.yml / .env.example se genera un valor de
 * ejemplo; en producción DEBE reemplazarse por una clave propia.
 */
const ALGORITMO = 'aes-256-gcm';

function obtenerClave(): Buffer {
  const claveB64 = process.env.APP_ENCRYPTION_KEY;
  if (!claveB64) {
    throw new Error(
      'Falta la variable de entorno APP_ENCRYPTION_KEY (32 bytes en base64) para cifrar secretos',
    );
  }
  const clave = Buffer.from(claveB64, 'base64');
  if (clave.length !== 32) {
    throw new Error('APP_ENCRYPTION_KEY debe decodificar a exactamente 32 bytes');
  }
  return clave;
}

export function cifrar(textoPlano: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITMO, obtenerClave(), iv);
  const cifrado = Buffer.concat([cipher.update(textoPlano, 'utf-8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  // Formato almacenado: iv.authTag.cifrado, todo en base64
  return [iv.toString('base64'), authTag.toString('base64'), cifrado.toString('base64')].join('.');
}

export function descifrar(valor: string): string {
  const [ivB64, tagB64, dataB64] = valor.split('.');
  const decipher = crypto.createDecipheriv(ALGORITMO, obtenerClave(), Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  const plano = Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]);
  return plano.toString('utf-8');
}
