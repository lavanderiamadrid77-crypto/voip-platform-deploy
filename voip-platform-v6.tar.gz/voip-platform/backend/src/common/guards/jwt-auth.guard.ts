import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

/** Exige un JWT válido (ver auth/jwt.strategy.ts) en todas las rutas protegidas */
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
