import { SetMetadata } from '@nestjs/common';
import { Rol } from '../entities/user.entity';

export const ROLES_KEY = 'roles';
/** Restringe un endpoint a los roles indicados, ej: @Roles(Rol.SUPER_ADMIN, Rol.ADMIN) */
export const Roles = (...roles: Rol[]) => SetMetadata(ROLES_KEY, roles);
