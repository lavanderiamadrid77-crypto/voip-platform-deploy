import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Cdr } from '../common/entities/cdr.entity';
import { CdrController } from './cdr.controller';
import { CdrService } from './cdr.service';

@Module({
  imports: [TypeOrmModule.forFeature([Cdr])],
  controllers: [CdrController],
  providers: [CdrService],
})
export class CdrModule {}
