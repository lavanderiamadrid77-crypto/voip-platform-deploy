import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Between, Repository } from 'typeorm';
import { Cdr } from '../common/entities/cdr.entity';

@Injectable()
export class CdrService {
  constructor(@InjectRepository(Cdr) private readonly repo: Repository<Cdr>) {}

  listar(
    tenantId: string,
    filtros: { desde?: Date; hasta?: Date; limite?: number },
  ): Promise<Cdr[]> {
    const desde = filtros.desde ?? new Date(0);
    const hasta = filtros.hasta ?? new Date();
    return this.repo.find({
      where: { tenantId, fechaHoraInicio: Between(desde, hasta) },
      order: { fechaHoraInicio: 'DESC' },
      take: filtros.limite ?? 100,
    });
  }
}
