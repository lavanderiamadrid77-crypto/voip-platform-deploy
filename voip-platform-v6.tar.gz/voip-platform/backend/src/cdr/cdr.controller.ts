import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { CdrService } from './cdr.service';

@ApiTags('cdr')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('api/cdr')
export class CdrController {
  constructor(private readonly service: CdrService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN, Rol.RESELLER, Rol.USUARIO)
  listar(
    @Query('tenantId') tenantId: string,
    @Query('desde') desde?: string,
    @Query('hasta') hasta?: string,
    @Query('limite') limite?: string,
  ) {
    return this.service.listar(tenantId, {
      desde: desde ? new Date(desde) : undefined,
      hasta: hasta ? new Date(hasta) : undefined,
      limite: limite ? Number(limite) : 100,
    });
  }
}
