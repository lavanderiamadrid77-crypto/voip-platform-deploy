import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import * as bcrypt from 'bcryptjs';
import { Repository } from 'typeorm';
import { User } from '../common/entities/user.entity';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User) private readonly userRepo: Repository<User>,
    private readonly jwt: JwtService,
  ) {}

  async login(email: string, password: string) {
    const user = await this.userRepo.findOne({ where: { email }, relations: ['tenant'] });
    if (!user || !user.activo) {
      throw new UnauthorizedException('Credenciales inválidas');
    }
    const valido = await bcrypt.compare(password, user.passwordHash);
    if (!valido) {
      throw new UnauthorizedException('Credenciales inválidas');
    }

    const payload = { sub: user.id, email: user.email, rol: user.rol, tenantId: user.tenantId };
    return {
      accessToken: await this.jwt.signAsync(payload),
      usuario: {
        id: user.id,
        email: user.email,
        rol: user.rol,
        tenantId: user.tenantId,
        idiomaPreferido: user.idiomaPreferido,
      },
    };
  }
}
