import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Trunk } from '../common/entities/trunk.entity';
import { FreeswitchModule } from '../freeswitch/freeswitch.module';
import { TrunksController } from './trunks.controller';
import { TrunksService } from './trunks.service';

@Module({
  imports: [TypeOrmModule.forFeature([Trunk]), FreeswitchModule],
  controllers: [TrunksController],
  providers: [TrunksService],
})
export class TrunksModule {}
