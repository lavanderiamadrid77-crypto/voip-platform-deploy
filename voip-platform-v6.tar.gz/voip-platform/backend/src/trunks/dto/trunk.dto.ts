import { IsInt, IsOptional, IsString, Min } from 'class-validator';

export class CrearTrunkDto {
  @IsString()
  nombre: string;

  @IsString()
  proveedor: string;

  @IsString()
  host: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  puerto?: number;

  @IsOptional()
  @IsString()
  usuario?: string;

  @IsOptional()
  @IsString()
  password?: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  costoPorMinuto?: number;
}
