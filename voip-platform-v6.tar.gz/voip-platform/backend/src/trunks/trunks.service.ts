import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { cifrar, descifrar } from '../common/crypto.util';
import { Trunk } from '../common/entities/trunk.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { CrearTrunkDto } from './dto/trunk.dto';

@Injectable()
export class TrunksService {
  constructor(
    @InjectRepository(Trunk) private readonly repo: Repository<Trunk>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  /** tenantId undefined -> lista solo trunks compartidos a nivel plataforma */
  listar(tenantId?: string): Promise<Trunk[]> {
    return this.repo.find({ where: tenantId ? { tenantId } : {}, order: { creadoEn: 'DESC' } });
  }

  async crear(tenantId: string | undefined, dto: CrearTrunkDto): Promise<Trunk> {
    const trunk = this.repo.create({
      tenantId,
      nombre: dto.nombre,
      proveedor: dto.proveedor,
      host: dto.host,
      puerto: dto.puerto ?? 5060,
      usuario: dto.usuario,
      passwordCifrada: dto.password ? cifrar(dto.password) : undefined,
      costoPorMinuto: dto.costoPorMinuto ?? 0,
    });
    const guardado = await this.repo.save(trunk);

    await this.freeswitch
      .escribirTrunkXml({
        nombre: guardado.nombre,
        host: guardado.host,
        puerto: guardado.puerto,
        usuario: guardado.usuario,
        passwordPlano: dto.password,
      })
      .catch(() => undefined); // FreeSWITCH puede no estar disponible en este momento; se reintenta manualmente

    return guardado;
  }

  async eliminar(id: string): Promise<void> {
    const trunk = await this.repo.findOne({ where: { id } });
    if (!trunk) throw new NotFoundException('Trunk no encontrado');
    await this.freeswitch.eliminarTrunkXml(trunk.nombre).catch(() => undefined);
    await this.repo.remove(trunk);
  }

  /** Solo para uso interno (ej. reconstrucción de config tras migración) */
  async obtenerPasswordEnClaro(id: string): Promise<string | undefined> {
    const trunk = await this.repo.findOne({ where: { id } });
    return trunk?.passwordCifrada ? descifrar(trunk.passwordCifrada) : undefined;
  }
}
