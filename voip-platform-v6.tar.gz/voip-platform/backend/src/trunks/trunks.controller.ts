import { Body, Controller, Delete, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { CrearTrunkDto } from './dto/trunk.dto';
import { TrunksService } from './trunks.service';

@ApiTags('trunks')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('api/trunks')
export class TrunksController {
  constructor(private readonly service: TrunksService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  listar(@Query('tenantId') tenantId?: string) {
    return this.service.listar(tenantId);
  }

  @Post()
  @Roles(Rol.SUPER_ADMIN)
  crear(@Query('tenantId') tenantId: string | undefined, @Body() dto: CrearTrunkDto) {
    return this.service.crear(tenantId, dto);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN)
  eliminar(@Param('id') id: string) {
    return this.service.eliminar(id);
  }
}
