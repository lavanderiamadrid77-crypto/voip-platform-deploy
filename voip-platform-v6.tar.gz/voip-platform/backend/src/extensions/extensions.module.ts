import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Extension } from '../common/entities/extension.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchModule } from '../freeswitch/freeswitch.module';
import { ExtensionsController } from './extensions.controller';
import { ExtensionsService } from './extensions.service';

@Module({
  imports: [TypeOrmModule.forFeature([Extension, Tenant]), FreeswitchModule],
  controllers: [ExtensionsController],
  providers: [ExtensionsService],
})
export class ExtensionsModule {}
