import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import * as crypto from 'crypto';
import { Repository } from 'typeorm';
import { cifrar } from '../common/crypto.util';
import { Extension } from '../common/entities/extension.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { CrearExtensionDto } from './dto/extension.dto';

@Injectable()
export class ExtensionsService {
  constructor(
    @InjectRepository(Extension) private readonly repo: Repository<Extension>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  listarPorTenant(tenantId: string): Promise<Extension[]> {
    return this.repo.find({ where: { tenantId }, order: { numero: 'ASC' } });
  }

  /** Genera una contraseña SIP segura (16 caracteres alfanuméricos) */
  private generarPasswordSegura(): string {
    return crypto.randomBytes(12).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 16);
  }

  /**
   * Crea la extensión en la base de datos y la aprovisiona en FreeSWITCH
   * (fichero XML de directory + reloadxml). Devuelve la contraseña en
   * claro UNA sola vez: el llamador debe mostrarla al usuario y no se
   * vuelve a poder recuperar.
   */
  async crear(
    tenantId: string,
    dto: CrearExtensionDto,
  ): Promise<{ extension: Extension; passwordSip: string }> {
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Tenant no encontrado');

    const total = await this.repo.count({ where: { tenantId } });
    if (total >= tenant.extensionesMax) {
      throw new ConflictException(
        `Se alcanzó el límite de ${tenant.extensionesMax} extensiones para este tenant`,
      );
    }

    const existe = await this.repo.findOne({ where: { tenantId, numero: dto.numero } });
    if (existe) throw new ConflictException('Ese número de extensión ya existe en este tenant');

    const passwordSip = this.generarPasswordSegura();
    const passwordCifrada = cifrar(passwordSip);

    const extension = this.repo.create({
      tenantId,
      numero: dto.numero,
      nombre: dto.nombre,
      tipo: dto.tipo,
      codecs: dto.codecs ?? 'OPUS,G722,PCMU,PCMA',
      webrtcHabilitado: dto.webrtcHabilitado ?? true,
      passwordCifrada,
    });
    const guardada = await this.repo.save(extension);

    try {
      await this.freeswitch.escribirExtensionXml({
        subdominioTenant: tenant.subdominio,
        numero: dto.numero,
        nombre: dto.nombre,
        passwordPlano: passwordSip,
        codecs: extension.codecs,
      });
    } catch (err) {
      // Si FreeSWITCH no está disponible, la extensión queda creada en BD
      // pero marcada para re-aprovisionar; no bloqueamos el flujo de gestión.
      await this.repo.update(guardada.id, { activo: false });
    }

    return { extension: guardada, passwordSip };
  }

  async eliminar(tenantId: string, id: string): Promise<void> {
    const extension = await this.repo.findOne({ where: { id, tenantId } });
    if (!extension) throw new NotFoundException('Extensión no encontrada');
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (tenant) {
      await this.freeswitch.eliminarExtensionXml(tenant.subdominio, extension.numero).catch(() => undefined);
    }
    await this.repo.remove(extension);
  }
}
