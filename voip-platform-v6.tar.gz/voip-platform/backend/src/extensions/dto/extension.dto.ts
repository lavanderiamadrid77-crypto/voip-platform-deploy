import { IsBoolean, IsEnum, IsOptional, IsString, Matches } from 'class-validator';
import { TipoExtension } from '../../common/entities/extension.entity';

export class CrearExtensionDto {
  @IsString()
  @Matches(/^[0-9]{3,6}$/, { message: 'El número de extensión debe ser numérico (3-6 dígitos)' })
  numero: string;

  @IsString()
  nombre: string;

  @IsEnum(TipoExtension)
  tipo: TipoExtension;

  @IsOptional()
  @IsString()
  codecs?: string;

  @IsOptional()
  @IsBoolean()
  webrtcHabilitado?: boolean;
}
