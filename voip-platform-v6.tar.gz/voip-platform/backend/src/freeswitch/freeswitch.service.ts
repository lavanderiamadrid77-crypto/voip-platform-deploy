import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs/promises';
import * as path from 'path';

// `modesl` no trae tipos oficiales; se declara mínimamente aquí para no
// depender de @types/modesl (no existe en npm).
// eslint-disable-next-line @typescript-eslint/no-var-requires
const esl = require('modesl');

/**
 * Encapsula toda la comunicación con FreeSWITCH:
 *  - Conexión ESL (Event Socket Library) para comandos y eventos en vivo.
 *  - Generación de los ficheros XML de directory/dialplan/gateways que
 *    FreeSWITCH lee desde disco (montados como volumen compartido).
 *
 * Nota: FreeSWITCH normalmente usa mod_xml_curl para configuración 100%
 * dinámica vía HTTP. Para el MVP se usa el enfoque más simple de escribir
 * ficheros XML a un volumen compartido + "reloadxml" por ESL, que es más
 * fácil de depurar y no requiere levantar un servidor XML-RPC aparte.
 * Migrar a mod_xml_curl queda documentado como mejora de Fase 2.
 */
@Injectable()
export class FreeswitchService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(FreeswitchService.name);
  private connection: any;
  private reconectando = false;

  constructor(private readonly config: ConfigService) {}

  async onModuleInit() {
    await this.conectar();
  }

  onModuleDestroy() {
    this.connection?.disconnect?.();
  }

  private conectar(): Promise<void> {
    return new Promise((resolve) => {
      const host = this.config.get<string>('FREESWITCH_ESL_HOST', 'freeswitch');
      const port = this.config.get<number>('FREESWITCH_ESL_PORT', 8021);
      const password = this.config.get<string>('FREESWITCH_ESL_PASSWORD', 'ClueCon');

      this.connection = new esl.Connection(host, port, password, () => {
        this.logger.log(`Conectado a FreeSWITCH ESL en ${host}:${port}`);
        resolve();
      });

      this.connection.on('error', (err: Error) => {
        this.logger.error(`Error de conexión ESL: ${err.message}`);
        this.reintentar();
      });

      this.connection.on('esl::end', () => {
        this.logger.warn('Conexión ESL cerrada, reintentando...');
        this.reintentar();
      });
    });
  }

  private reintentar() {
    if (this.reconectando) return;
    this.reconectando = true;
    setTimeout(() => {
      this.reconectando = false;
      this.conectar().catch(() => undefined);
    }, 5000);
  }

  /** Ejecuta un comando de la consola de FreeSWITCH (fs_cli) vía ESL */
  async ejecutarComando(comando: string): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.connection || !this.connection.connected?.()) {
        return reject(new Error('Sin conexión activa a FreeSWITCH ESL'));
      }
      this.connection.api(comando, (res: any) => {
        resolve(res?.getBody?.() ?? '');
      });
    });
  }

  /** Recarga toda la configuración XML (directory, dialplan, sip_profiles includes) */
  async recargarXml(): Promise<void> {
    await this.ejecutarComando('reloadxml');
  }

  /** Fuerza a un perfil Sofia a releer sus gateways sin reiniciar el perfil entero */
  async recargarGateways(perfil = 'external'): Promise<void> {
    await this.ejecutarComando(`sofia profile ${perfil} rescan reloadxml`);
  }

  /**
   * Declara el dominio SIP de un tenant: conf/directory/<subdominio>.xml
   * Este fichero es lo que hace que cada tenant sea un dominio SIP
   * independiente dentro de FreeSWITCH (aislamiento real, no solo lógico),
   * incluyendo a su vez todos los usuarios/extensiones que viven en
   * conf/directory/<subdominio>/*.xml
   */
  async escribirDominioTenantXml(params: { subdominio: string; canalesMax: number }): Promise<void> {
    const dir = path.join(this.confPath(), 'directory');
    await fs.mkdir(dir, { recursive: true });
    await fs.mkdir(path.join(dir, params.subdominio), { recursive: true });
    const xml = `<include>
  <domain name="${params.subdominio}">
    <params>
      <param name="dial-string" value="\${sofia_contact(*/\${dialed_user}@\${dialed_domain})}"/>
    </params>
    <variables>
      <variable name="tenant_subdominio" value="${params.subdominio}"/>
      <variable name="max_channels" value="${params.canalesMax}"/>
    </variables>
    <groups>
      <group name="default">
        <users>
          <X-PRE-PROCESS cmd="include" data="${params.subdominio}/*.xml"/>
        </users>
      </group>
    </groups>
  </domain>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.subdominio}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarDominioTenantXml(subdominio: string): Promise<void> {
    await fs.rm(path.join(this.confPath(), 'directory', `${subdominio}.xml`), { force: true });
    await fs.rm(path.join(this.confPath(), 'directory', subdominio), { recursive: true, force: true });
    await this.recargarXml();
  }

  /**
   * Escribe el XML de <directory> para una extensión dentro de
   * conf/directory/<subdominio>/<numero>.xml
   */
  async escribirExtensionXml(params: {
    subdominioTenant: string;
    numero: string;
    nombre: string;
    passwordPlano: string;
    codecs: string;
  }): Promise<void> {
    const dir = path.join(this.confPath(), 'directory', params.subdominioTenant);
    await fs.mkdir(dir, { recursive: true });
    const xml = `<include>
  <user id="${params.numero}">
    <params>
      <param name="password" value="${params.passwordPlano}"/>
    </params>
    <variables>
      <variable name="toll_allow" value="domestic,international,local"/>
      <variable name="accountcode" value="${params.subdominioTenant}"/>
      <variable name="user_context" value="tenant_${params.subdominioTenant}"/>
      <variable name="effective_caller_id_name" value="${params.nombre}"/>
      <variable name="effective_caller_id_number" value="${params.numero}"/>
      <variable name="codec_string" value="${params.codecs}"/>
    </variables>
  </user>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.numero}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarExtensionXml(subdominioTenant: string, numero: string): Promise<void> {
    const file = path.join(this.confPath(), 'directory', subdominioTenant, `${numero}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  /**
   * Escribe el XML de <gateway> de un trunk saliente/entrante dentro de
   * conf/sip_profiles/external/<nombre>.xml
   */
  async escribirTrunkXml(params: {
    nombre: string;
    host: string;
    puerto: number;
    usuario?: string;
    passwordPlano?: string;
  }): Promise<void> {
    const dir = path.join(this.confPath(), 'sip_profiles', 'external');
    await fs.mkdir(dir, { recursive: true });
    const xml = `<include>
  <gateway name="${params.nombre}">
    <param name="username" value="${params.usuario ?? params.nombre}"/>
    <param name="password" value="${params.passwordPlano ?? ''}"/>
    <param name="realm" value="${params.host}"/>
    <param name="proxy" value="${params.host}:${params.puerto}"/>
    <param name="register" value="${params.usuario ? 'true' : 'false'}"/>
    <param name="caller-id-in-from" value="true"/>
  </gateway>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.nombre}.xml`), xml, 'utf-8');
    await this.recargarGateways('external');
  }

  async eliminarTrunkXml(nombre: string): Promise<void> {
    const file = path.join(this.confPath(), 'sip_profiles', 'external', `${nombre}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarGateways('external');
  }

  /** Ruta al volumen compartido de configuración de FreeSWITCH (montado en docker-compose) */
  private confPath(): string {
    return this.config.get<string>('FREESWITCH_CONF_PATH', '/freeswitch-conf');
  }
}
