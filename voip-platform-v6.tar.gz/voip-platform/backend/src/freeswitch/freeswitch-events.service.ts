import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Cdr } from '../common/entities/cdr.entity';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const esl = require('modesl');

/**
 * Escucha en tiempo real los eventos de FreeSWITCH vía ESL y genera el
 * registro de CDR cuando una llamada cuelga (CHANNEL_HANGUP_COMPLETE).
 * Esta es una conexión ESL independiente de la de comandos (FreeswitchService)
 * porque el modo "event" bloquea el socket para otros usos.
 */
@Injectable()
export class FreeswitchEventsService implements OnModuleInit {
  private readonly logger = new Logger(FreeswitchEventsService.name);

  constructor(
    private readonly config: ConfigService,
    @InjectRepository(Cdr) private readonly cdrRepo: Repository<Cdr>,
  ) {}

  onModuleInit() {
    this.conectar();
  }

  private conectar() {
    const host = this.config.get<string>('FREESWITCH_ESL_HOST', 'freeswitch');
    const port = this.config.get<number>('FREESWITCH_ESL_PORT', 8021);
    const password = this.config.get<string>('FREESWITCH_ESL_PASSWORD', 'ClueCon');

    const conn = new esl.Connection(host, port, password, () => {
      this.logger.log('Suscrito a eventos de FreeSWITCH para generar CDR');
      conn.subscribe('CHANNEL_HANGUP_COMPLETE');
      conn.on('esl::event::CHANNEL_HANGUP_COMPLETE::*', (evt: any) => {
        this.registrarCdr(evt).catch((e) =>
          this.logger.error(`No se pudo guardar CDR: ${e.message}`),
        );
      });
    });

    conn.on('error', () => setTimeout(() => this.conectar(), 5000));
    conn.on('esl::end', () => setTimeout(() => this.conectar(), 5000));
  }

  private async registrarCdr(evt: any): Promise<void> {
    const get = (campo: string) => evt.getHeader(campo) as string | undefined;

    const tenantId = get('variable_accountcode');
    if (!tenantId) {
      // Llamada fuera de un contexto de tenant conocido (ej. tráfico interno de FS); se ignora.
      return;
    }

    const cdr = this.cdrRepo.create({
      tenantId,
      callUuid: get('Unique-ID'),
      origen: get('Caller-Caller-ID-Number') ?? get('Caller-Username') ?? 'desconocido',
      destino: get('Caller-Destination-Number') ?? 'desconocido',
      fechaHoraInicio: new Date(Number(get('Caller-Channel-Created-Time') ?? 0) / 1000 || Date.now()),
      duracionSegundos: Number(get('variable_billsec') ?? 0),
      estado: get('variable_hangup_cause') ?? 'desconocido',
      trunkUsado: get('variable_sip_gateway_name'),
    });
    await this.cdrRepo.save(cdr);
  }
}
