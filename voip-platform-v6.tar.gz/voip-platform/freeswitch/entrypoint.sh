#!/bin/sh
# NOTA: la imagen base (safarov/freeswitch:latest) es una imagen BusyBox
# minimalista sin bash. Este script usa /bin/sh (BusyBox ash) y evita
# "set -o pipefail" (no soportado por ash) y "envsubst" (no instalado);
# en su lugar usa "sed", que sí viene incluido en BusyBox.
set -eu

CONF_DIR="/etc/freeswitch"

# 1) Sustituye SOLO la variable FREESWITCH_ESL_PASSWORD dentro de la
#    plantilla de event_socket.conf. Se limita explícitamente a esa
#    variable para no tocar por accidente la sintaxis nativa de FreeSWITCH
#    (${...} y $${...}) que aparece en el resto de ficheros.
if [ -z "${FREESWITCH_ESL_PASSWORD:-}" ]; then
  echo "Debes definir FREESWITCH_ESL_PASSWORD" >&2
  exit 1
fi
sed "s#\${FREESWITCH_ESL_PASSWORD}#${FREESWITCH_ESL_PASSWORD}#g" \
  "${CONF_DIR}/autoload_configs/event_socket.conf.xml.template" \
  > "${CONF_DIR}/autoload_configs/event_socket.conf.xml"

# 2) Certificados TLS para el perfil WSS (webphone). Normalmente ya vienen
#    incluidos en la imagen (generados en tiempo de build, ver Dockerfile),
#    para no depender de tener openssl disponible en tiempo de ejecución
#    (la imagen base no lo trae). Si por algún motivo no existen y hay un
#    binario openssl disponible, se generan aquí como último recurso.
TLS_DIR="${CONF_DIR}/tls"
mkdir -p "$TLS_DIR"
if [ ! -f "$TLS_DIR/wss.pem" ]; then
  if command -v openssl >/dev/null 2>&1; then
    echo "[entrypoint] Generando certificado TLS autofirmado para WSS (solo pruebas)..."
    openssl req -x509 -newkey rsa:2048 -keyout "$TLS_DIR/wss.key" -out "$TLS_DIR/wss.crt" \
      -days 365 -nodes -subj "/CN=${FREESWITCH_DOMAIN:-plataforma.local}"
    cat "$TLS_DIR/wss.crt" "$TLS_DIR/wss.key" > "$TLS_DIR/wss.pem"
  else
    echo "[entrypoint] AVISO: no existe wss.pem y no hay openssl disponible; el perfil WSS puede fallar al arrancar." >&2
  fi
fi

# 3) Directorios dinámicos que el backend rellena (extensiones/tenants/gateways)
mkdir -p "${CONF_DIR}/directory" "${CONF_DIR}/sip_profiles/external"

echo "[entrypoint] Arrancando FreeSWITCH..."
exec freeswitch -nonat -nf -c
