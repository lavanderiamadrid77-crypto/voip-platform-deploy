# Plataforma de Centralita Virtual VoIP Multi-Tenant
## Fase 1 — Análisis, Arquitectura y Roadmap

**Nota importante sobre este documento:** en tu mensaje, los campos de especificación de ambos servidores (sistema operativo, RAM/CPU, software instalado) llegaron como plantilla sin rellenar. Como no respondiste a la pregunta de cómo proceder, he continuado con la opción por defecto: **asumir una configuración típica** para cada servidor según el rol que sí describiste ("Kolmisoft, orientado a grandes empresas" y "Callshop, pequeños clientes"). Todo lo que en este documento depende de RAM/CPU/almacenamiento reales está marcado como **[SUPUESTO]** y debe validarse antes de tocar producción. En cuanto me confirmes los datos reales, ajusto la recomendación y el dimensionamiento.

---

## 1. Análisis de servidores y recomendación

### 1.1 Lo que sé con certeza (por tus propias palabras)

| | Servidor 1 (Kolmisoft) | Servidor 2 (Callshop) |
|---|---|---|
| Rol actual | Orientado a grandes empresas | Orientado a pequeños clientes, dependiente del Servidor 1 como proveedor |
| Motor VoIP | Kolmisoft/MOR (capa de gestión sobre Asterisk) | Asterisk con configuración personalizada |
| Relación entre ambos | Actúa como proveedor de trunks SIP hacia el Servidor 2 | Consume trunks del Servidor 1 |

### 1.2 Supuestos de trabajo **[SUPUESTO — validar]**

- Servidor 1: CentOS 7 u 8, Asterisk 13/16 bajo Kolmisoft/MOR, 16 GB+ RAM, 8 cores, almacenamiento con RAID para grabaciones, MySQL/MariaDB ya en uso (Kolmisoft depende de MySQL), Apache/Nginx para el panel de Kolmisoft.
- Servidor 2: Debian 10 o Ubuntu 18/20.04, Asterisk plano (sin capa de gestión), recursos más modestos (4–8 GB RAM, 2–4 cores), pensado para volumen bajo/medio de canales concurrentes.

### 1.3 Recomendación

**Construir la nueva plataforma sobre el Servidor 1 (Kolmisoft)**, pero **no reutilizar Kolmisoft/MOR ni su Asterisk como motor de la nueva plataforma**. La recomendación es:

1. Usar el **hardware** del Servidor 1 (más RAM/CPU, más adecuado para multi-tenant real) como base física o como primer nodo del nuevo clúster.
2. Sustituir progresivamente Kolmisoft/MOR por un motor VoIP nativamente multi-tenant (ver sección 3), corriendo en contenedores Docker, en paralelo al Kolmisoft existente durante la transición, para no cortar el servicio de trunks que ya provees.
3. Mantener el Servidor 2 (Callshop) como **nodo secundario/edge** para redundancia geográfica y como candidato a segundo nodo cuando se implemente failover (ver sección 9 de requisitos no funcionales), o reconvertirlo en servidor de grabaciones/backups.

**Justificación:**

- Kolmisoft/MOR es una capa de billing y gestión pensada para revendedores de minutos (rating, tarificación), no para las funcionalidades que pides (IVR visual, WebRTC embebido, API REST moderna, multi-tenant con aislamiento por cliente vía contenedores/dominios). Extender Kolmisoft para todo esto es más caro en esfuerzo que construir sobre un motor VoIP puro y una capa de aplicación propia.
- El Servidor 1 ya tiene más recursos y ya opera como proveedor de trunks: es el punto de menor fricción para migrar.
- El Servidor 2, con menos recursos, encaja mejor como nodo secundario o de respaldo que como núcleo de una plataforma que debe soportar 500 llamadas concurrentes.

**Antes de ejecutar nada de esto necesito que confirmes (Fase 2):** SO exacto y versión, RAM/CPU/disco reales, IP pública y si hay NAT, puertos ya abiertos, y si hay grabaciones o configuraciones de clientes activos en el Servidor 1 que no se puedan interrumpir durante la migración.

---

## 2. Arquitectura propuesta

```
                                   ┌─────────────────────────────┐
                                   │        USUARIOS FINALES      │
                                   │ (Admins, Resellers, Clientes)│
                                   └──────────────┬───────────────┘
                                                  │ HTTPS (TLS 1.3)
                                   ┌──────────────▼───────────────┐
                                   │   NGINX (reverse proxy)      │
                                   │  - SSL (Let's Encrypt/ACME)  │
                                   │  - WAF básico / rate limit   │
                                   │  - Ruteo por subdominio       │
                                   │    (tenant.plataforma.com)   │
                                   └──────┬─────────────┬────────┘
                                          │             │
                        ┌─────────────────▼──┐     ┌────▼─────────────────┐
                        │   FRONTEND (SPA)    │     │   BACKEND API REST   │
                        │  React+TS+Tailwind  │◄────┤  Node/NestJS o       │
                        │  Shadcn UI          │     │  FastAPI             │
                        │  WebRTC Softphone   │     │  Swagger/OpenAPI 3.0 │
                        └─────────────────────┘     └────┬─────────┬──────┘
                                                          │         │
                        ┌─────────────────────────────────┘         │
                        │                                            │
              ┌─────────▼─────────┐                    ┌─────────────▼────────────┐
              │  COLA DE MENSAJES  │                    │   WORKERS ASÍNCRONOS      │
              │  RabbitMQ/NATS     │◄──────────────────►│  Celery/BullMQ            │
              │  (eventos llamada, │                    │  (CDR, webhooks, TTS,     │
              │   webhooks, jobs)  │                    │   transcripción, reportes)│
              └─────────┬──────────┘                    └───────────┬───────────────┘
                        │                                           │
              ┌─────────▼─────────────────────────────────────────▼───────────────┐
              │                     CAPA DE DATOS                                  │
              │  PostgreSQL 16 (config, tenants, extensiones, IVR, facturación)    │
              │  TimescaleDB (métricas de canales, series temporales)              │
              │  Redis (sesiones, cache, rate limiting, presencia SIP)             │
              │  Almacenamiento grabaciones: disco local o S3-compatible (MinIO)   │
              └─────────────────────────────────────────────────────────────────────┘
                        ▲
                        │ ESL (Event Socket Library) / AMI
              ┌─────────┴──────────────────────────────────────────────────────────┐
              │                MOTOR VoIP MULTI-TENANT                             │
              │                    FreeSWITCH (recomendado)                        │
              │  - mod_sofia (SIP) - un perfil/dominio por tenant                   │
              │  - mod_callcenter (colas) - mod_conference                         │
              │  - mod_verto / mod_rtc (WebRTC nativo)                             │
              │  - Dialplan XML generado dinámicamente desde la BD                 │
              └─────────┬─────────────────────────────┬───────────────────────────┘
                        │ SIP/RTP (SRTP)                │ SIP trunk
              ┌─────────▼──────────┐          ┌──────────▼─────────────┐
              │  Extensiones /     │          │  Proveedores SIP Trunk  │
              │  Softphones /      │          │  (múltiples, con        │
              │  Teléfonos IP      │          │   balanceo de carga y   │
              │  (Yealink, etc.)   │          │   failover)             │
              └────────────────────┘          └─────────────────────────┘

        MONITOREO TRANSVERSAL: Prometheus (exporters de FreeSWITCH, Postgres, Nginx)
                                Grafana (dashboards) + Alertmanager
        SEGURIDAD TRANSVERSAL: fail2ban (SIP), firewall (nftables/ufw), backups automáticos
```

**Aislamiento multi-tenant:** cada tenant se mapea a un **dominio SIP** dentro de FreeSWITCH (`mod_sofia` permite múltiples dominios/perfiles), con su propio directorio de extensiones, dialplan y límites de canales concurrentes aplicados vía variables de canal y `mod_limit`. A nivel de aplicación, cada fila de cada tabla lleva `tenant_id` con Row-Level Security en PostgreSQL como segunda barrera de aislamiento.

---

## 3. Stack tecnológico recomendado (con justificación)

### 3.1 Motor VoIP: **FreeSWITCH** sobre Asterisk

| Criterio | FreeSWITCH | Asterisk |
|---|---|---|
| Multi-tenant nativo | Múltiples dominios SIP y perfiles Sofia-SIP de forma nativa, aislamiento limpio por tenant | Requiere trabajo extra (contextos, múltiples archivos de config) para simular multi-tenant real |
| WebRTC | Soporte nativo maduro (mod_verto, mod_rtc) | Soporte más limitado/menos maduro out-of-the-box |
| Escalabilidad de canales | Arquitectura multi-hilo, mejor uso de múltiples cores para picos de concurrencia (500+ canales) | También escala bien pero el modelo multi-tenant real pesa más en configuración |
| Control programático | ESL (Event Socket Library) muy adecuado para generar dialplans dinámicos desde una API | AMI es funcional pero orientado a un modelo más monolítico |
| Curva de aprendizaje | Mayor (XML, sintaxis propia) | Menor si el equipo ya conoce Asterisk (como en tus dos servidores actuales) |
| Ecosistema/comunidad | Menor que Asterisk, pero suficiente para este caso de uso | Enorme, más módulos de terceros (FreePBX, etc.) |

**Conclusión:** para un proveedor VoIP multi-tenant que necesita aislamiento real por cliente, WebRTC de calidad y 500 llamadas concurrentes, **FreeSWITCH es la opción técnicamente superior**, a pesar de que tu equipo ya tiene experiencia con Asterisk. El costo de la curva de aprendizaje se paga una vez; el costo de forzar multi-tenant real sobre Asterisk se paga en cada tenant nuevo.

### 3.2 Backend: **Node.js + NestJS + TypeScript**

Justificación: NestJS da una estructura modular (equivalente a "apps" de Django) ideal para separar tenants/extensiones/trunks/IVR/CDR como módulos independientes; TypeScript comparte tipos con el frontend React+TS; el ecosistema Node tiene librerías maduras para ESL (`modesl`/`esl-lite`) y para WebSockets (necesarios para eventos de llamada en tiempo real en el dashboard). Alternativa igualmente válida: Python + FastAPI, si el equipo tiene más experiencia en Python — la arquitectura no cambia, solo el lenguaje.

### 3.3 Frontend: **React 18 + TypeScript + TailwindCSS + Shadcn UI**

Shadcn UI da componentes accesibles y personalizables (clave para el requisito de white-label) sin el peso de una librería de componentes cerrada. Tailwind facilita modo oscuro/claro y theming por tenant (colores/logo).

### 3.4 Datos: **PostgreSQL 16 + Redis + TimescaleDB**

PostgreSQL con Row-Level Security para aislamiento multi-tenant a nivel de fila; TimescaleDB (extensión de Postgres) para series temporales de métricas de canales sin añadir una base de datos completamente distinta; Redis para sesiones, cache y contadores de rate limiting de la API.

### 3.5 Colas: **RabbitMQ**

Para eventos de llamada (iniciada/contestada/finalizada), disparo de webhooks, jobs de transcripción y generación de reportes. NATS es una alternativa más ligera si se prioriza latencia mínima sobre features de enrutamiento de mensajes.

### 3.6 Infraestructura: **Docker Compose** (con ruta a Kubernetes)

Docker Compose es suficiente para el MVP y para el volumen que describes; se deja documentado el camino a Kubernetes para cuando haya que escalar horizontalmente el backend o distribuir FreeSWITCH en múltiples nodos.

---

## 4. Modelo de datos (tablas principales)

- **tenants**: id, nombre, subdominio, dominio_personalizado, logo_url, colores_tema, plan_id, estado, fecha_creación, límites (canales_max, extensiones_max, retención_grabaciones_días).
- **plans**: id, nombre, precio, canales_incluidos, extensiones_incluidas, minutos_incluidos, features_json.
- **users**: id, tenant_id, email, password_hash, rol (super_admin/admin/reseller/usuario), idioma_preferido, mfa_habilitado.
- **roles_permissions**: rol, permiso, recurso.
- **sip_trunks**: id, tenant_id (nullable si es trunk compartido a nivel plataforma), proveedor, host, puerto, usuario, credenciales_cifradas, códecs_soportados, prioridad, estado, costo_por_minuto.
- **dids**: id, tenant_id, número, trunk_id, tipo (local/internacional), tarifa_entrante, ruta_destino (extensión/ivr/cola/ring_group).
- **extensions**: id, tenant_id, número, tipo (escritorio/softphone/móvil/ring_group/cola/ivr/buzón/conferencia), contraseña_cifrada, códecs, plantilla_id, webrtc_habilitado.
- **phone_templates**: id, marca (Yealink/Grandstream/Polycom/Cisco), modelo, plantilla_config.
- **ivr_menus**: id, tenant_id, nombre, nodo_raíz_id, horario_id.
- **ivr_nodes**: id, ivr_menu_id, tipo_acción (reproducir_audio/submenu/transferir/cola/buzón/tts/colgar/condicional), parámetros_json, nodo_padre_id, orden.
- **business_hours**: id, tenant_id, nombre, reglas_json (días/horas), festivos_json.
- **call_routes**: id, tenant_id, did_id, condición_caller_id, prioridad, destino.
- **queues**: id, tenant_id, nombre, estrategia (ring_all/round_robin/least_recent), timeout, música_espera.
- **ring_groups**: id, tenant_id, nombre, extensiones_json, estrategia.
- **recordings**: id, tenant_id, call_id, ruta_almacenamiento (local o s3://), duración, transcripción_texto, fecha_expiración.
- **cdr**: id, tenant_id, call_id, origen, destino, fecha_hora_inicio, duración, estado, costo, trunk_usado, grabación_id.
- **api_keys**: id, tenant_id, key_hash, scopes_json, rate_limit, estado, última_uso.
- **webhooks**: id, tenant_id, url, eventos_suscritos_json, secreto_firma, estado.
- **audit_logs**: id, tenant_id, user_id, acción, recurso, detalle_json, ip, fecha_hora.
- **invoices**: id, tenant_id, periodo, monto, estado, líneas_json.

Índices clave: `tenant_id` en todas las tablas multi-tenant (para RLS y consultas rápidas por cliente), índice compuesto `(tenant_id, fecha_hora_inicio)` en `cdr` para reportes, índice único `(número, tenant_id)` en `extensions` y `dids`.

---

## 5. Estructura de directorios propuesta

```
voip-platform/
├── backend/
│   ├── src/
│   │   ├── modules/
│   │   │   ├── auth/
│   │   │   ├── tenants/
│   │   │   ├── extensions/
│   │   │   ├── trunks/
│   │   │   ├── dids/
│   │   │   ├── ivr/
│   │   │   ├── queues/
│   │   │   ├── cdr/
│   │   │   ├── recordings/
│   │   │   ├── webhooks/
│   │   │   ├── api-keys/
│   │   │   └── billing/
│   │   ├── freeswitch/          # cliente ESL, generación de dialplan/directory
│   │   ├── common/              # guards, decoradores, RLS middleware
│   │   └── main.ts
│   └── test/
├── frontend/
│   ├── src/
│   │   ├── pages/                # dashboard, tenants, extensiones, ivr-builder, cdr, ajustes
│   │   ├── components/
│   │   ├── webphone/             # cliente WebRTC (SIP.js o JsSIP)
│   │   └── i18n/                 # es.json, en.json
├── freeswitch/
│   ├── conf/
│   │   ├── sip_profiles/
│   │   ├── directory/            # generado dinámicamente por tenant
│   │   └── dialplan/
│   └── scripts/
├── infra/
│   ├── docker-compose.yml
│   ├── nginx/
│   └── monitoring/
│       ├── prometheus/
│       └── grafana/dashboards/
├── scripts/
│   ├── install.sh
│   ├── backup.sh
│   └── restore.sh
└── docs/
```

---

## 6. Roadmap priorizado

**MVP (Fase A):** login + roles básicos, CRUD de tenants, CRUD de extensiones SIP con aprovisionamiento en FreeSWITCH vía ESL, alta de un trunk SIP saliente/entrante básico, webphone WebRTC funcional (llamar y recibir), CDR mínimo visible en el dashboard.

**Fase B:** IVR visual (versión simple: menú por niveles sin drag-and-drop todavía), colas y ring groups, grabación bajo demanda, horarios de oficina.

**Fase C:** API REST pública documentada con Swagger, webhooks, API keys con scopes, reportes exportables (CSV/Excel/PDF).

**Fase D:** IVR drag-and-drop completo, TTS, transcripción con Whisper, monitoreo en vivo (barging/whisper/spy), anti-fraude, failover multi-servidor, Prometheus+Grafana, white-label completo, marketplace interno.

---

## 7. Lo que necesito de ti antes de la Fase 2 (instalación real)

1. Datos reales de ambos servidores (SO exacto, RAM/CPU/disco, IP pública, si hay NAT).
2. Confirmación de si el Servidor 1 tiene clientes/trunks activos que no se puedan interrumpir.
3. Tu preferencia de stack backend (te recomendé Node/NestJS, pero dime si prefieres Python o PHP).
4. Dominio(s) que vas a usar para la plataforma y los subdominios de tenants.
5. Si ya tienes proveedores de SIP trunk contratados o hay que dejarlo configurable desde cero.

Con esos datos puedo generar en la siguiente sesión el script de instalación automatizada, el `docker-compose.yml` completo y el arranque del código del backend (módulo de tenants + extensiones + integración FreeSWITCH vía ESL).
