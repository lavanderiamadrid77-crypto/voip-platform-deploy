#!/bin/bash
#
# Instala y arranca la plataforma VoIP en una VM de pruebas NUEVA
# (Ubuntu/Debian). Este script NO toca los servidores de producción:
# está pensado para ejecutarse en una máquina virtual limpia dedicada a
# probar el software antes de plantearse tocar Kolmisoft/Callshop.
#
# Uso:
#   chmod +x scripts/install.sh
#   ./scripts/install.sh
#
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Este script necesita sudo/root para instalar Docker. Ejecuta: sudo ./scripts/install.sh"
  exit 1
fi

echo "== 1) Instalando dependencias base =="
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl gnupg openssl

echo "== 2) Instalando Docker Engine + Compose plugin (si no están instalados) =="
if ! command -v docker >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  ARCH=$(dpkg --print-architecture)
  CODENAME=$(. /etc/os-release && echo "$VERSION_CODENAME")
  echo "deb [arch=${ARCH} signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
else
  echo "Docker ya estaba instalado, se omite."
fi

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_DIR"

echo "== 3) Preparando fichero .env =="
if [ ! -f .env ]; then
  cp .env.example .env
  JWT_SECRET=$(openssl rand -hex 32)
  APP_KEY=$(openssl rand -base64 32)
  ESL_PASS=$(openssl rand -hex 16)
  ADMIN_PASS=$(openssl rand -base64 12 | tr -d '=+/')
  sed -i "s#^JWT_SECRET=.*#JWT_SECRET=${JWT_SECRET}#" .env
  sed -i "s#^APP_ENCRYPTION_KEY=.*#APP_ENCRYPTION_KEY=${APP_KEY}#" .env
  sed -i "s#^FREESWITCH_ESL_PASSWORD=.*#FREESWITCH_ESL_PASSWORD=${ESL_PASS}#" .env
  sed -i "s#^SEED_ADMIN_PASSWORD=.*#SEED_ADMIN_PASSWORD=${ADMIN_PASS}#" .env
  echo ".env generado con secretos aleatorios. Revísalo y ajusta PUBLIC_API_URL/PUBLIC_WSS_URL con la IP de esta VM."
else
  echo ".env ya existía, no se sobreescribe."
fi

echo "== 4) Levantando el stack (esto compila las imágenes, puede tardar varios minutos) =="
docker compose up -d --build

echo "== 5) Esperando a que el backend esté listo para poblar datos iniciales =="
sleep 10
docker compose exec -T backend node dist/seed.js || echo "AVISO: el seed falló o ya se había ejecutado antes; revisa 'docker compose logs backend'."

IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo ""
echo "======================================================================"
echo " Plataforma levantada. Accede desde tu navegador a:"
echo "   Panel web:      http://${IP:-localhost}:8080"
echo "   API + Swagger:  http://${IP:-localhost}:3000/api/docs"
echo "   Adminer (BD):   http://${IP:-localhost}:8081"
echo ""
echo " Usuario inicial: revisa SEED_ADMIN_EMAIL / SEED_ADMIN_PASSWORD en .env"
echo "======================================================================"
