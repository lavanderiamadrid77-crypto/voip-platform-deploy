#!/bin/bash
# Backup de la base de datos y de la configuración dinámica de FreeSWITCH
# (directorios de tenants/extensiones y gateways de trunks).
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_DIR"
source .env

DESTINO="backups/$(date +%Y-%m-%d_%H%M%S)"
mkdir -p "$DESTINO"

echo "Volcando PostgreSQL..."
docker compose exec -T postgres pg_dump -U "${DB_USER}" "${DB_NAME}" > "${DESTINO}/postgres.sql"

echo "Copiando configuración dinámica de FreeSWITCH..."
# Los nombres de volumen abajo asumen que la carpeta del proyecto se llama
# "voip-platform" (Docker Compose prefija los volúmenes con el nombre de
# carpeta). Si renombraste la carpeta, comprueba los nombres reales con:
#   docker volume ls | grep freeswitch-conf
docker run --rm -v voip-platform_freeswitch-conf-directory:/data -v "$PWD/${DESTINO}:/backup" alpine \
  tar czf /backup/freeswitch-directory.tar.gz -C /data .
docker run --rm -v voip-platform_freeswitch-conf-gateways:/data -v "$PWD/${DESTINO}:/backup" alpine \
  tar czf /backup/freeswitch-gateways.tar.gz -C /data .

echo "Backup completo en: ${DESTINO}"
