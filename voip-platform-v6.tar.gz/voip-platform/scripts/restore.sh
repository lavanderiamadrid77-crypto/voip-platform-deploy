#!/bin/bash
# Restaura un backup generado por scripts/backup.sh
# Uso: ./scripts/restore.sh backups/2026-07-28_101500
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_DIR"
source .env

ORIGEN="${1:?Uso: ./scripts/restore.sh <carpeta_de_backup>}"

echo "Restaurando PostgreSQL desde ${ORIGEN}/postgres.sql ..."
docker compose exec -T postgres psql -U "${DB_USER}" "${DB_NAME}" < "${ORIGEN}/postgres.sql"

echo "Restaurando configuración de FreeSWITCH..."
docker run --rm -v voip-platform_freeswitch-conf-directory:/data -v "$PWD/${ORIGEN}:/backup" alpine \
  sh -c "rm -rf /data/* && tar xzf /backup/freeswitch-directory.tar.gz -C /data"
docker run --rm -v voip-platform_freeswitch-conf-gateways:/data -v "$PWD/${ORIGEN}:/backup" alpine \
  sh -c "rm -rf /data/* && tar xzf /backup/freeswitch-gateways.tar.gz -C /data"

echo "Reiniciando FreeSWITCH para que recargue la configuración restaurada..."
docker compose restart freeswitch

echo "Restauración completa."
