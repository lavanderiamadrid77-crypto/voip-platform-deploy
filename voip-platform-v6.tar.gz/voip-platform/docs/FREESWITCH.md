# Notas sobre la imagen Docker de FreeSWITCH

`freeswitch/Dockerfile` usa como base `safarov/freeswitch:latest`, una imagen
comunitaria ampliamente usada porque evita compilar FreeSWITCH desde fuente
(proceso largo, con muchos módulos opcionales a elegir). No he podido tirar de
esta imagen desde este entorno de desarrollo para confirmarla en el momento de
escribir esto, así que la primera vez que ejecutes `docker compose up --build`
en tu VM es el momento de validar que sigue existiendo en Docker Hub.

## Si la imagen no está disponible

**Opción A — SignalWire (oficial)**: FreeSWITCH pasó a distribuirse vía el
repositorio APT de SignalWire, que en 2023 empezó a requerir un token
personal gratuito para acceder a los paquetes. Pasos generales:
1. Crea una cuenta gratuita en signalwire.com y genera un "personal access token".
2. Sustituye la línea `FROM safarov/freeswitch:latest` por un Dockerfile que
   instale FreeSWITCH desde `https://freeswitch.signalwire.com/repo/deb/debian-release/`
   usando ese token como credencial del repositorio APT.

**Opción B — compilar desde fuente**: usa la imagen oficial `debian:bookworm-slim`
como base y sigue la guía de compilación de FreeSWITCH 1.10.x desde
`https://github.com/signalwire/freeswitch` (requiere más tiempo de build, pero
no depende de ninguna imagen de terceros).

**Opción C — buscar otra imagen comunitaria activa** en Docker Hub buscando
"freeswitch" y comprobando la fecha del último `push` antes de usarla en nada
serio.

Independientemente de la opción elegida, lo único que debe conservarse es la
estructura de `/etc/freeswitch/` (directory, dialplan, sip_profiles,
autoload_configs) tal como la sobreescribe `COPY conf/ /etc/freeswitch/` en el
Dockerfile: el resto de este proyecto (backend, generación de XML, ESL) no
depende de qué imagen base se use, solo de que exponga FreeSWITCH con ESL en
el puerto 8021 y los perfiles Sofia en los puertos documentados en
`docker-compose.yml`.
