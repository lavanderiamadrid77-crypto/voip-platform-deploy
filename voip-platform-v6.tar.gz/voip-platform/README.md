# Plataforma VoIP Multi-Tenant — Entorno de pruebas (VM)

Este paquete es el **MVP funcional** de la plataforma, pensado para levantarse **en una máquina virtual de pruebas, completamente aislada de tus dos servidores actuales (Kolmisoft y Callshop)**. Nada aquí toca esos servidores: es software nuevo que corre en su propia VM vía Docker Compose, para que puedas probarlo, iterar y validar que hace (o mejora) lo que hoy hace el Servidor 1, antes de plantearte migrar nada de verdad.

## Qué incluye este MVP (probado en este momento)

- **Backend** (NestJS + TypeScript + PostgreSQL): login con JWT y roles, CRUD de tenants (clientes), CRUD de extensiones SIP con aprovisionamiento automático en FreeSWITCH, CRUD de troncales SIP (trunks) con generación automática del gateway, listado de CDR, documentación interactiva Swagger en `/api/docs`.
- **Motor VoIP**: FreeSWITCH multi-dominio (un dominio SIP = un tenant, aislamiento real), perfil WSS para llamadas WebRTC desde el navegador.
- **Frontend** (React + TypeScript + Tailwind): login, dashboard con métricas básicas, gestión de tenants/extensiones/trunks, listado de CDR con exportación a CSV, teléfono web (webphone) funcional vía WebRTC, modo oscuro/claro, español/inglés.
- **Infraestructura**: `docker-compose.yml` con PostgreSQL, Redis, FreeSWITCH, backend, frontend (servido con Nginx) y Adminer (inspección de BD en pruebas). Script de instalación automatizada para una VM Ubuntu/Debian limpia. Scripts de backup/restauración.

## Qué NO está todavía (deliberadamente fuera de este primer corte, ver roadmap en `FASE1_ANALISIS_Y_ARQUITECTURA.md`)

IVR visual, colas/ring groups, grabación de llamadas, horarios de oficina, enrutamiento dinámico de DIDs entrantes, webhooks, API keys con scopes, transcripción, monitoreo en vivo (barging/whisper/spy), anti-fraude, failover multi-servidor, Prometheus/Grafana, white-label completo, marketplace. El objetivo de esta entrega es tener la base (tenants + extensiones + trunk + webphone + CDR) real y probada, para construir el resto encima con confianza.

## Importante: qué he podido verificar y qué no

Este entorno de desarrollo no tiene acceso a un daemon Docker (no puedo levantar contenedores desde aquí), así que **no he podido ejecutar el stack de extremo a extremo**. Lo que sí he verificado directamente:

- El backend compila sin errores de TypeScript (`tsc --noEmit`) y con el build real de NestJS (`nest build`).
- El frontend compila y genera el build de producción sin errores (`vite build`).
- El `docker-compose.yml` es válido (`docker compose config` lo procesa sin errores ni warnings).
- Todos los ficheros XML de FreeSWITCH son XML bien formado.

Lo que falta validar en tu VM (primera vez que se levanta de verdad): que la imagen base de FreeSWITCH (`safarov/freeswitch`) siga disponible en Docker Hub, que el registro de un softphone/webphone contra el perfil WSS funcione tal cual, y el flujo completo de llamada interna + generación de CDR. Por eso el siguiente apartado incluye un checklist de pruebas paso a paso: haz cada prueba y dime qué falla para corregirlo con datos reales en vez de suposiciones.

## Cómo levantarlo en tu VM

1. Crea una VM nueva (Ubuntu 22.04 recomendado), con al menos 4 GB de RAM y 2 vCPU para pruebas.
2. Copia esta carpeta completa a la VM (scp, git, o como prefieras).
3. Ejecuta:
   ```bash
   sudo ./scripts/install.sh
   ```
   Esto instala Docker si falta, genera un `.env` con secretos aleatorios, construye las imágenes y levanta todo con `docker compose up -d --build`, y ejecuta el seed de datos iniciales (usuario admin + tenant "demo" + extensión 1000).
4. Al terminar, el script imprime las URLs de acceso (panel, Swagger, Adminer) y te recuerda dónde están las credenciales del admin (en `.env`).

Si prefieres hacerlo manualmente en vez de usar el script:
```bash
cp .env.example .env
# edita .env: como mínimo JWT_SECRET, APP_ENCRYPTION_KEY (openssl rand -base64 32),
# FREESWITCH_ESL_PASSWORD, y las URLs públicas si accedes desde otra máquina
docker compose up -d --build
docker compose exec backend node dist/seed.js
```

## Checklist de pruebas sugerido (antes de tocar nada de producción)

1. Entra a `http://<IP-de-la-VM>:8080` con el email/contraseña del seed. ¿Carga el dashboard?
2. Ve a "Clientes" y crea un segundo tenant de prueba. ¿Aparece en la lista?
3. Ve a "Extensiones", selecciona el tenant "demo" y crea una segunda extensión (ej. 1001). Anota la contraseña SIP que se muestra (solo se ve una vez).
4. Ve a "Teléfono web", regístrate con la extensión 1000 (contraseña del seed: `Demo12345Sip!`, dominio `demo.plataforma.local`, URL WSS `wss://<IP-de-la-VM>:7443`).
5. Abre una segunda pestaña/navegador, regístrate como extensión 1001 con la contraseña que anotaste en el paso 3.
6. Desde una pestaña, llama al número de la otra. ¿Se establece audio en ambos sentidos?
7. Cuelga y revisa "Llamadas (CDR)": ¿aparece el registro con duración y estado?
8. Ve a "Troncales SIP" y da de alta un trunk de prueba (puedes usar datos ficticios si no tienes credenciales reales todavía) para comprobar que el formulario y el aprovisionamiento no dan error.

Si el paso 6 falla (no hay audio o no registra), lo más probable es un tema de certificado TLS autofirmado (el navegador puede bloquear la conexión WSS hasta que aceptes el certificado manualmente visitando `https://<IP-de-la-VM>:7443` una vez) o de puertos UDP de RTP bloqueados por el firewall de la VM/proveedor cloud — dímelo y lo resolvemos juntos con el error exacto.

## Estructura del proyecto

```
voip-platform/
├── backend/       API REST (NestJS) + integración FreeSWITCH vía ESL
├── frontend/      Panel web (React + Tailwind) + webphone WebRTC
├── freeswitch/    Configuración multi-tenant de FreeSWITCH (Dockerfile propio)
├── scripts/       install.sh, backup.sh, restore.sh
├── docker-compose.yml
├── .env.example
└── FASE1_ANALISIS_Y_ARQUITECTURA.md   (documento de arquitectura y roadmap completo)
```

## Próximos pasos

Cuando hayas probado este MVP en la VM y me confirmes qué funciona y qué no (con los errores exactos si algo falla), seguimos con lo que dejamos pendiente de la Fase 1: tus datos reales de servidores para planear la migración, y después las siguientes fases del roadmap (IVR, colas, grabación, reportes, API pública, monitoreo). Todo eso se construye sobre esta misma base sin tener que rehacer nada.
