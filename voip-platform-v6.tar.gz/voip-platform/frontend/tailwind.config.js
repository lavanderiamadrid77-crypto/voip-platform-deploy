/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        marca: {
          DEFAULT: 'var(--color-marca, #4f46e5)',
        },
      },
    },
  },
  plugins: [],
};
