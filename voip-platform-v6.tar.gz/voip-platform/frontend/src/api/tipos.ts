export type Rol = 'super_admin' | 'admin' | 'reseller' | 'usuario';

export interface UsuarioSesion {
  id: string;
  email: string;
  rol: Rol;
  tenantId?: string;
  idiomaPreferido: string;
}

export interface Tenant {
  id: string;
  nombre: string;
  subdominio: string;
  colorPrimario: string;
  canalesMax: number;
  extensionesMax: number;
  retencionGrabacionesDias: number;
  activo: boolean;
  creadoEn: string;
}

export type TipoExtension =
  | 'escritorio'
  | 'softphone'
  | 'movil'
  | 'ring_group'
  | 'cola'
  | 'ivr'
  | 'buzon'
  | 'conferencia';

export interface Extension {
  id: string;
  tenantId: string;
  numero: string;
  nombre: string;
  tipo: TipoExtension;
  codecs: string;
  webrtcHabilitado: boolean;
  activo: boolean;
  creadoEn: string;
}

export interface Trunk {
  id: string;
  tenantId?: string;
  nombre: string;
  proveedor: string;
  host: string;
  puerto: number;
  usuario?: string;
  prioridad: number;
  costoPorMinuto: number;
  activo: boolean;
  creadoEn: string;
}

export interface Cdr {
  id: string;
  tenantId: string;
  origen: string;
  destino: string;
  fechaHoraInicio: string;
  duracionSegundos: number;
  estado: string;
  costo: number;
  trunkUsado?: string;
}
