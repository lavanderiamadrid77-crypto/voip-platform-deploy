import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useI18n } from '../i18n';

export function Login() {
  const { login } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [enviando, setEnviando] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setEnviando(true);
    try {
      await login(email, password);
      navigate('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error de inicio de sesión');
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm bg-white dark:bg-slate-800 shadow rounded-xl p-8 flex flex-col gap-4"
      >
        <h1 className="text-xl font-semibold text-center text-marca">Plataforma VoIP</h1>
        {error && (
          <div className="text-sm text-red-600 bg-red-50 dark:bg-red-950 rounded-md px-3 py-2">
            {error}
          </div>
        )}
        <label className="text-sm flex flex-col gap-1">
          {t('email')}
          <input
            type="email"
            required
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label className="text-sm flex flex-col gap-1">
          {t('password')}
          <input
            type="password"
            required
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <button
          disabled={enviando}
          className="bg-marca text-white rounded-md py-2 font-medium disabled:opacity-50"
        >
          {enviando ? '...' : t('entrar')}
        </button>
      </form>
    </div>
  );
}
