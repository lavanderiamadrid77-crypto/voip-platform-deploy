import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { Cdr, Extension, Tenant, Trunk } from '../api/tipos';

export function Dashboard() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [trunks, setTrunks] = useState<Trunk[]>([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalExtensiones, setTotalExtensiones] = useState(0);
  const [ultimasLlamadas, setUltimasLlamadas] = useState<Cdr[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const t = await api.get<Tenant[]>('/api/tenants');
        setTenants(t);
        const tk = await api.get<Trunk[]>('/api/trunks');
        setTrunks(tk);

        let total = 0;
        const llamadas: Cdr[] = [];
        for (const tenant of t.slice(0, 5)) {
          const exts = await api.get<Extension[]>(`/api/tenants/${tenant.id}/extensions`);
          total += exts.length;
          const cdrs = await api
            .get<Cdr[]>(`/api/cdr?tenantId=${tenant.id}&limite=5`)
            .catch(() => []);
          llamadas.push(...cdrs);
        }
        setTotalExtensiones(total);
        setUltimasLlamadas(
          llamadas
            .sort((a, b) => +new Date(b.fechaHoraInicio) - +new Date(a.fechaHoraInicio))
            .slice(0, 10),
        );
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error cargando el dashboard');
      } finally {
        setCargando(false);
      }
    })();
  }, []);

  if (cargando) return <p>Cargando...</p>;
  if (error) return <p className="text-red-600">{error}</p>;

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Tarjeta titulo="Clientes (tenants)" valor={tenants.length} />
        <Tarjeta titulo="Extensiones" valor={totalExtensiones} />
        <Tarjeta titulo="Troncales SIP" valor={trunks.length} />
      </div>
      <div>
        <h2 className="text-lg font-medium mb-2">Últimas llamadas</h2>
        <TablaCdr filas={ultimasLlamadas} />
      </div>
    </div>
  );
}

function Tarjeta({ titulo, valor }: { titulo: string; valor: number }) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-5">
      <div className="text-sm text-slate-500">{titulo}</div>
      <div className="text-3xl font-semibold mt-1">{valor}</div>
    </div>
  );
}

function TablaCdr({ filas }: { filas: Cdr[] }) {
  if (filas.length === 0) {
    return <p className="text-sm text-slate-500">Todavía no hay llamadas registradas.</p>;
  }
  return (
    <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
      <thead className="bg-slate-100 dark:bg-slate-700 text-left">
        <tr>
          <th className="p-2">Fecha</th>
          <th className="p-2">Origen</th>
          <th className="p-2">Destino</th>
          <th className="p-2">Duración</th>
          <th className="p-2">Estado</th>
        </tr>
      </thead>
      <tbody>
        {filas.map((c) => (
          <tr key={c.id} className="border-t border-slate-100 dark:border-slate-700">
            <td className="p-2">{new Date(c.fechaHoraInicio).toLocaleString()}</td>
            <td className="p-2">{c.origen}</td>
            <td className="p-2">{c.destino}</td>
            <td className="p-2">{c.duracionSegundos}s</td>
            <td className="p-2">{c.estado}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
