import { useEffect, useRef, useState } from 'react';
import * as JsSIP from 'jssip';
import { useI18n } from '../i18n';

/**
 * Softphone WebRTC embebido, para probar llamadas directamente desde el
 * navegador sin necesitar un teléfono IP físico. Se conecta por WSS al
 * perfil "internal" de FreeSWITCH (puerto 7443, ver freeswitch/conf).
 *
 * En este MVP las credenciales SIP se introducen a mano (número de
 * extensión + contraseña que se generó al crear la extensión + dominio
 * del tenant). En una fase posterior esto se autocompleta desde el
 * perfil del usuario logueado.
 */
export function Webphone() {
  const { t } = useI18n();
  const [wsUrl, setWsUrl] = useState(import.meta.env.VITE_FREESWITCH_WSS_URL ?? 'wss://localhost:7443');
  const [dominio, setDominio] = useState('demo.plataforma.local');
  const [extension, setExtension] = useState('1000');
  const [password, setPassword] = useState('');
  const [destino, setDestino] = useState('1001');
  const [estado, setEstado] = useState<'desconectado' | 'conectando' | 'registrado' | 'en_llamada'>(
    'desconectado',
  );
  const [log, setLog] = useState<string[]>([]);

  const uaRef = useRef<JsSIP.UA | null>(null);
  const sesionRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  function agregarLog(linea: string) {
    setLog((prev) => [...prev.slice(-30), linea]);
  }

  function registrar() {
    if (uaRef.current) {
      uaRef.current.stop();
    }
    setEstado('conectando');
    const socket = new JsSIP.WebSocketInterface(wsUrl);
    const ua = new JsSIP.UA({
      sockets: [socket],
      uri: `sip:${extension}@${dominio}`,
      password,
      register: true,
    });

    ua.on('registered', () => {
      setEstado('registrado');
      agregarLog('Registrado correctamente en FreeSWITCH');
    });
    ua.on('registrationFailed', (e: any) => {
      setEstado('desconectado');
      agregarLog(`Fallo de registro: ${e.cause}`);
    });
    ua.on('disconnected', () => {
      setEstado('desconectado');
      agregarLog('Desconectado del servidor WSS');
    });

    ua.on('newRTCSession', (data: any) => {
      const session = data.session;
      sesionRef.current = session;
      session.on('accepted', () => setEstado('en_llamada'));
      session.on('ended', () => {
        setEstado('registrado');
        agregarLog('Llamada finalizada');
      });
      session.on('failed', (e: any) => {
        setEstado('registrado');
        agregarLog(`Llamada fallida: ${e.cause}`);
      });
      session.connection?.addEventListener('track', (event: RTCTrackEvent) => {
        if (audioRef.current) audioRef.current.srcObject = event.streams[0];
      });
    });

    ua.start();
    uaRef.current = ua;
  }

  function llamar() {
    if (!uaRef.current) return;
    const session = uaRef.current.call(`sip:${destino}@${dominio}`, {
      mediaConstraints: { audio: true, video: false },
    });
    sesionRef.current = session;
    agregarLog(`Llamando a ${destino}...`);
  }

  function colgar() {
    sesionRef.current?.terminate();
  }

  useEffect(() => {
    return () => {
      uaRef.current?.stop();
    };
  }, []);

  return (
    <div className="flex flex-col gap-6 max-w-xl">
      <h1 className="text-2xl font-semibold">{t('webphone')}</h1>
      <p className="text-sm text-slate-500">
        Estado: <span className="font-medium">{estado}</span>
      </p>

      <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex flex-col gap-3">
        <Campo etiqueta="URL WSS de FreeSWITCH" valor={wsUrl} onChange={setWsUrl} />
        <Campo etiqueta="Dominio del tenant" valor={dominio} onChange={setDominio} />
        <Campo etiqueta="Extensión" valor={extension} onChange={setExtension} />
        <Campo etiqueta="Contraseña SIP" valor={password} onChange={setPassword} tipo="password" />
        <button onClick={registrar} className="bg-marca text-white rounded-md px-4 py-2 w-fit">
          Registrar
        </button>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex flex-col gap-3">
        <Campo etiqueta="Número destino" valor={destino} onChange={setDestino} />
        <div className="flex gap-2">
          <button
            onClick={llamar}
            disabled={estado !== 'registrado'}
            className="bg-green-600 text-white rounded-md px-4 py-2 disabled:opacity-50"
          >
            Llamar
          </button>
          <button
            onClick={colgar}
            disabled={estado !== 'en_llamada'}
            className="bg-red-600 text-white rounded-md px-4 py-2 disabled:opacity-50"
          >
            Colgar
          </button>
        </div>
      </div>

      <audio ref={audioRef} autoPlay />

      <div className="bg-slate-900 text-slate-100 rounded-xl p-4 text-xs font-mono h-48 overflow-y-auto">
        {log.map((l, i) => (
          <div key={i}>{l}</div>
        ))}
      </div>
    </div>
  );
}

function Campo({
  etiqueta,
  valor,
  onChange,
  tipo = 'text',
}: {
  etiqueta: string;
  valor: string;
  onChange: (v: string) => void;
  tipo?: string;
}) {
  return (
    <label className="flex flex-col text-sm gap-1">
      {etiqueta}
      <input
        type={tipo}
        className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
        value={valor}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}
