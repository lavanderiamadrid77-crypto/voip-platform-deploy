import { FormEvent, useEffect, useState } from 'react';
import { api } from '../api/client';
import { Tenant } from '../api/tipos';
import { useI18n } from '../i18n';

export function Tenants() {
  const { t } = useI18n();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [nombre, setNombre] = useState('');
  const [subdominio, setSubdominio] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [creando, setCreando] = useState(false);

  async function cargar() {
    setTenants(await api.get<Tenant[]>('/api/tenants'));
  }

  useEffect(() => {
    cargar().catch((e) => setError(e.message));
  }, []);

  async function crear(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setCreando(true);
    try {
      await api.post('/api/tenants', { nombre, subdominio });
      setNombre('');
      setSubdominio('');
      await cargar();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creando el tenant');
    } finally {
      setCreando(false);
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/tenants/${id}`);
    await cargar();
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-2xl font-semibold">{t('tenants')}</h1>

      <form onSubmit={crear} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex gap-3 items-end flex-wrap">
        <label className="flex flex-col text-sm gap-1">
          Nombre
          <input
            required
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          Subdominio
          <input
            required
            placeholder="acme"
            pattern="[a-z0-9-]{3,32}"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={subdominio}
            onChange={(e) => setSubdominio(e.target.value.toLowerCase())}
          />
        </label>
        <button disabled={creando} className="bg-marca text-white rounded-md px-4 py-2 h-fit">
          {t('nuevo_tenant')}
        </button>
      </form>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Nombre</th>
            <th className="p-2">Subdominio</th>
            <th className="p-2">Canales máx.</th>
            <th className="p-2">Extensiones máx.</th>
            <th className="p-2">Estado</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody>
          {tenants.map((tn) => (
            <tr key={tn.id} className="border-t border-slate-100 dark:border-slate-700">
              <td className="p-2">{tn.nombre}</td>
              <td className="p-2">{tn.subdominio}</td>
              <td className="p-2">{tn.canalesMax}</td>
              <td className="p-2">{tn.extensionesMax}</td>
              <td className="p-2">{tn.activo ? 'Activo' : 'Inactivo'}</td>
              <td className="p-2">
                <button className="text-red-600 hover:underline" onClick={() => eliminar(tn.id)}>
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
