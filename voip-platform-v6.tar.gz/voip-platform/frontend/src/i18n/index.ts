import { useState } from 'react';

type Idioma = 'es' | 'en';

const textos: Record<Idioma, Record<string, string>> = {
  es: {
    dashboard: 'Panel',
    tenants: 'Clientes',
    extensiones: 'Extensiones',
    trunks: 'Troncales SIP',
    cdr: 'Llamadas (CDR)',
    webphone: 'Teléfono web',
    cerrar_sesion: 'Cerrar sesión',
    modo_oscuro: 'Modo oscuro',
    email: 'Correo electrónico',
    password: 'Contraseña',
    entrar: 'Entrar',
    nuevo_tenant: 'Nuevo cliente',
    nueva_extension: 'Nueva extensión',
    nuevo_trunk: 'Nuevo troncal',
  },
  en: {
    dashboard: 'Dashboard',
    tenants: 'Tenants',
    extensiones: 'Extensions',
    trunks: 'SIP Trunks',
    cdr: 'Calls (CDR)',
    webphone: 'Web phone',
    cerrar_sesion: 'Log out',
    modo_oscuro: 'Dark mode',
    email: 'Email',
    password: 'Password',
    entrar: 'Sign in',
    nuevo_tenant: 'New tenant',
    nueva_extension: 'New extension',
    nuevo_trunk: 'New trunk',
  },
};

export function useI18n() {
  const [idioma, setIdioma] = useState<Idioma>(
    (localStorage.getItem('voip_idioma') as Idioma) || 'es',
  );

  function cambiarIdioma(nuevo: Idioma) {
    localStorage.setItem('voip_idioma', nuevo);
    setIdioma(nuevo);
  }

  function t(clave: string): string {
    return textos[idioma][clave] ?? clave;
  }

  return { idioma, cambiarIdioma, t };
}
