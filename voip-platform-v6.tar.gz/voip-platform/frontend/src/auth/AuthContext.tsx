import { createContext, ReactNode, useContext, useEffect, useState } from 'react';
import { api, borrarToken, guardarToken, hayToken } from '../api/client';
import { UsuarioSesion } from '../api/tipos';

interface AuthContextValue {
  usuario: UsuarioSesion | null;
  cargando: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<UsuarioSesion | null>(null);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    // No hay endpoint "/me" en el MVP; el usuario queda en memoria tras el
    // login y se pierde al recargar la página (limitación conocida, se
    // resuelve fácilmente añadiendo GET /api/auth/me en el backend).
    setCargando(false);
  }, []);

  async function login(email: string, password: string) {
    const respuesta = await api.post<{ accessToken: string; usuario: UsuarioSesion }>(
      '/api/auth/login',
      { email, password },
    );
    guardarToken(respuesta.accessToken);
    setUsuario(respuesta.usuario);
  }

  function logout() {
    borrarToken();
    setUsuario(null);
  }

  return (
    <AuthContext.Provider value={{ usuario, cargando, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth debe usarse dentro de <AuthProvider>');
  return ctx;
}

export function sesionIniciada(): boolean {
  return hayToken();
}
