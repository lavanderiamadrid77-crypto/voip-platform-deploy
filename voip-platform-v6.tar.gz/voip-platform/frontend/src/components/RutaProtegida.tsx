import { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { sesionIniciada } from '../auth/AuthContext';
import { Layout } from './Layout';

export function RutaProtegida({ children }: { children: ReactNode }) {
  if (!sesionIniciada()) {
    return <Navigate to="/login" replace />;
  }
  return <Layout>{children}</Layout>;
}
