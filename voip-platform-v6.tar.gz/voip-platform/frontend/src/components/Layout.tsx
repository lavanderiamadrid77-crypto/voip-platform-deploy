import { ReactNode, useEffect, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useI18n } from '../i18n';

const enlaces = [
  { to: '/', clave: 'dashboard' },
  { to: '/tenants', clave: 'tenants' },
  { to: '/extensiones', clave: 'extensiones' },
  { to: '/trunks', clave: 'trunks' },
  { to: '/cdr', clave: 'cdr' },
  { to: '/webphone', clave: 'webphone' },
];

export function Layout({ children }: { children: ReactNode }) {
  const { logout } = useAuth();
  const { t, idioma, cambiarIdioma } = useI18n();
  const navigate = useNavigate();
  const [oscuro, setOscuro] = useState(
    localStorage.getItem('voip_tema') === 'oscuro',
  );

  useEffect(() => {
    document.documentElement.classList.toggle('dark', oscuro);
    localStorage.setItem('voip_tema', oscuro ? 'oscuro' : 'claro');
  }, [oscuro]);

  return (
    <div className="min-h-screen flex">
      <aside className="w-60 shrink-0 border-r border-slate-200 dark:border-slate-700 p-4 flex flex-col gap-1">
        <div className="font-semibold text-lg mb-4 text-marca">VoIP Platform</div>
        {enlaces.map((e) => (
          <NavLink
            key={e.to}
            to={e.to}
            className={({ isActive }) =>
              `px-3 py-2 rounded-md text-sm ${
                isActive
                  ? 'bg-marca text-white'
                  : 'hover:bg-slate-100 dark:hover:bg-slate-800'
              }`
            }
          >
            {t(e.clave)}
          </NavLink>
        ))}
        <div className="mt-auto flex flex-col gap-2">
          <label className="flex items-center gap-2 text-sm px-3">
            <input type="checkbox" checked={oscuro} onChange={(e) => setOscuro(e.target.checked)} />
            {t('modo_oscuro')}
          </label>
          <select
            className="mx-3 text-sm rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
            value={idioma}
            onChange={(e) => cambiarIdioma(e.target.value as 'es' | 'en')}
          >
            <option value="es">Español</option>
            <option value="en">English</option>
          </select>
          <button
            className="mx-3 text-sm text-left px-3 py-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
            onClick={() => {
              logout();
              navigate('/login');
            }}
          >
            {t('cerrar_sesion')}
          </button>
        </div>
      </aside>
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
