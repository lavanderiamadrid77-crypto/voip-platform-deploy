#!/usr/bin/env bash
#
# Diagnóstico de la centralita. Se ejecuta en el servidor, dentro de la
# carpeta del proyecto:
#
#   bash scripts/diagnostico-freeswitch.sh
#
# Recorre, de abajo arriba, todo lo que tiene que estar bien para que una
# llamada funcione, y dice en cada paso qué se ha comprobado. La idea es no
# tener que ir mirando ocho sitios distintos a mano cada vez que algo falla.
set -uo pipefail

ok()   { printf '  \033[32m[OK]\033[0m    %s\n' "$1"; }
mal()  { printf '  \033[31m[FALLO]\033[0m %s\n' "$1"; FALLOS=$((FALLOS+1)); }
aviso(){ printf '  \033[33m[AVISO]\033[0m %s\n' "$1"; }
titulo(){ printf '\n\033[1m%s\033[0m\n' "$1"; }

FALLOS=0
FS="$(docker compose ps -q freeswitch 2>/dev/null)"

titulo "1. Contenedores"
if [ -z "$FS" ]; then
  mal "El contenedor freeswitch no existe. Lanza: docker compose up -d --build freeswitch"
  echo; echo "Diagnóstico interrumpido: sin contenedor no hay nada más que mirar."
  exit 1
fi
ESTADO="$(docker inspect -f '{{.State.Status}}' "$FS")"
[ "$ESTADO" = "running" ] && ok "freeswitch está en marcha" || mal "freeswitch está en estado '$ESTADO'"
docker compose ps

titulo "2. Certificados TLS (teléfono web)"
if docker compose exec -T freeswitch test -f /etc/freeswitch/tls/wss.pem 2>/dev/null; then
  ok "wss.pem presente"
else
  mal "falta /etc/freeswitch/tls/wss.pem -> el teléfono web no funcionará. Mira: docker compose logs fs-certs"
fi
if docker compose exec -T freeswitch test -f /etc/freeswitch/tls/agent.pem 2>/dev/null; then
  ok "agent.pem presente (SIP TLS)"
else
  aviso "falta agent.pem: SIP sobre TLS (5061) no estará disponible"
fi

titulo "3. Núcleo de FreeSWITCH"
ESTADO_FS="$(docker compose exec -T freeswitch fs_cli -p "${FREESWITCH_ESL_PASSWORD:-}" -x 'status' 2>/dev/null)"
if printf '%s' "$ESTADO_FS" | grep -q '^UP'; then
  ok "responde a fs_cli"
  printf '%s\n' "$ESTADO_FS" | sed 's/^/      /'
else
  mal "no responde a fs_cli (¿contraseña ESL distinta de la del .env?)"
fi

titulo "4. IP pública anunciada en el SDP"
# Es la causa número uno de "la llamada entra pero no se oye nada".
IP_SDP="$(docker compose exec -T freeswitch fs_cli -p "${FREESWITCH_ESL_PASSWORD:-}" -x 'eval $${external_rtp_ip}' 2>/dev/null | tr -d '\r')"
case "$IP_SDP" in
  ""|*10.42.*|*127.0.0.1*) mal "external_rtp_ip = '$IP_SDP' -> NO habrá audio. Define FREESWITCH_EXTERNAL_IP en el .env" ;;
  *) ok "external_rtp_ip = $IP_SDP" ;;
esac

titulo "5. Perfiles SIP"
PERFILES="$(docker compose exec -T freeswitch fs_cli -p "${FREESWITCH_ESL_PASSWORD:-}" -x 'sofia status' 2>/dev/null)"
printf '%s\n' "$PERFILES" | sed 's/^/      /'
printf '%s' "$PERFILES" | grep -q 'internal.*RUNNING' && ok "perfil 'internal' arrancado (extensiones)" || mal "perfil 'internal' NO está arrancado"
printf '%s' "$PERFILES" | grep -q 'external.*RUNNING' && ok "perfil 'external' arrancado (proveedores)" || mal "perfil 'external' NO está arrancado"

titulo "6. Event Socket (por donde habla el panel con la centralita)"
if docker compose exec -T backend sh -c 'nc -z freeswitch 8021' 2>/dev/null; then
  ok "el backend alcanza freeswitch:8021"
else
  aviso "no se ha podido comprobar con nc; revisa: docker compose logs backend | grep ESL"
fi
docker compose logs backend 2>/dev/null | grep -i 'esl' | tail -3 | sed 's/^/      /'

titulo "7. Configuración generada por el panel"
for d in directory dialplan/public/dinamico dialplan/default/dinamico sip_profiles/external; do
  N="$(docker compose exec -T freeswitch sh -c "ls /etc/freeswitch/$d/*.xml 2>/dev/null | wc -l" | tr -d '\r')"
  echo "      $d: ${N:-0} ficheros"
done

titulo "8. Registros SIP activos"
docker compose exec -T freeswitch fs_cli -p "${FREESWITCH_ESL_PASSWORD:-}" -x 'sofia status profile internal reg' 2>/dev/null | tail -20 | sed 's/^/      /'

titulo "Resumen"
if [ "$FALLOS" -eq 0 ]; then
  printf '  \033[32mTodo correcto: %d fallos.\033[0m\n' "$FALLOS"
else
  printf '  \033[31m%d comprobación(es) fallidas. Revisa los [FALLO] de arriba.\033[0m\n' "$FALLOS"
fi
