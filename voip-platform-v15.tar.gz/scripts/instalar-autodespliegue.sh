#!/usr/bin/env bash
#
# Instala (o actualiza) el auto-despliegue. Se ejecuta una sola vez, desde la
# carpeta del proyecto:
#
#   bash scripts/instalar-autodespliegue.sh
#
# A partir de ahi, para publicar una version nueva basta con subir el paquete
# al repositorio y poner su nombre en despliegue.txt. El servidor la instala
# solo en menos de dos minutos.
set -euo pipefail

AQUI="$(cd "$(dirname "$0")" && pwd)"

install -m 755 "$AQUI/autodespliegue.sh" /usr/local/bin/autodespliegue.sh
install -m 644 "$AQUI/voip-autodespliegue.service" /etc/systemd/system/voip-autodespliegue.service
install -m 644 "$AQUI/voip-autodespliegue.timer" /etc/systemd/system/voip-autodespliegue.timer

systemctl daemon-reload
systemctl enable --now voip-autodespliegue.timer

echo
echo "Auto-despliegue instalado. Estado del temporizador:"
systemctl list-timers voip-autodespliegue.timer --no-pager || true
echo
echo "Registro del ultimo despliegue: http://$(curl -fsS --max-time 8 https://ifconfig.me 2>/dev/null || echo IP-DEL-SERVIDOR):8090/despliegue.log"
