#!/usr/bin/env bash
#
# Auto-despliegue: comprueba cada pocos minutos si hay una version nueva
# publicada en el repositorio y, si la hay, la instala sola. Lo lanza el
# temporizador de systemd voip-autodespliegue.timer.
#
# Para publicar una version nueva:
#   1. Subir "voip-platform-<version>.tar.gz" al repositorio.
#   2. Editar "despliegue.txt" para que contenga esa <version>.
# El servidor hace el resto; no hay que entrar por consola.
#
# Esta pensado para correr sin nadie mirando, asi que es deliberadamente
# desconfiado:
#   - El paquete se descomprime primero aparte y solo se instala si contiene
#     de verdad lo que debe. Un paquete corrupto no puede dejar el proyecto a
#     medias.
#   - Se respalda el .env antes de tocar nada.
#   - Una version que falla se reintenta tres veces y se abandona. Sin ese
#     limite, una version mala se reintentaria cada dos minutos para siempre.
set -uo pipefail

PROYECTO="/root/voip-platform"
REPO="https://raw.githubusercontent.com/lavanderiamadrid77-crypto/voip-platform-deploy/main"
ESTADO="$PROYECTO/estado"
MARCADOR="$ESTADO/version-desplegada.txt"
FALLOS="$ESTADO/intentos-fallidos.txt"
LOG="$ESTADO/despliegue.log"
MAX_INTENTOS=3

mkdir -p "$ESTADO"
registrar() { printf '%s  %s\n' "$(date -u '+%Y-%m-%d %H:%M:%SZ')" "$1" >> "$LOG"; }

DESEADA="$(curl -fsS --max-time 20 "$REPO/despliegue.txt" 2>/dev/null | tr -d ' \t\r\n')"
# Silencio deliberado si GitHub no responde: escribir en el log cada dos
# minutos lo dejaria inservible para ver lo que si importa.
[ -z "$DESEADA" ] && exit 0

ACTUAL="$(tr -d ' \t\r\n' < "$MARCADOR" 2>/dev/null)"
[ "$DESEADA" = "$ACTUAL" ] && exit 0

INTENTOS=0
if [ -f "$FALLOS" ]; then
  GUARDADO="$(head -1 "$FALLOS")"
  case "$GUARDADO" in
    "$DESEADA "*) INTENTOS="${GUARDADO#"$DESEADA "}" ;;
  esac
fi
case "$INTENTOS" in ''|*[!0-9]*) INTENTOS=0 ;; esac
[ "$INTENTOS" -ge "$MAX_INTENTOS" ] && exit 0

# El log se reinicia en cada despliegue para que lo que se lea sea siempre el
# intento actual, sin tener que bucear en el historial.
: > "$LOG"
registrar "=== Despliegue de $DESEADA (instalada ahora: ${ACTUAL:-ninguna}) ==="
registrar "Intento $((INTENTOS + 1)) de $MAX_INTENTOS"

abandonar() {
  registrar "FALLO: $1"
  printf '%s %s\n' "$DESEADA" "$((INTENTOS + 1))" > "$FALLOS"
  registrar "=== Despliegue NO completado ==="
  exit 1
}

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

registrar "Descargando voip-platform-$DESEADA.tar.gz"
curl -fsS --max-time 300 -o "$TMP/paquete.tar.gz" "$REPO/voip-platform-$DESEADA.tar.gz" \
  || abandonar "no se ha podido descargar el paquete"
registrar "Descargado: $(stat -c%s "$TMP/paquete.tar.gz") bytes"

gzip --test "$TMP/paquete.tar.gz" || abandonar "el paquete esta corrupto"

mkdir -p "$TMP/contenido"
tar xzf "$TMP/paquete.tar.gz" -C "$TMP/contenido" || abandonar "no se ha podido descomprimir"

# Si esto no esta, el paquete no es lo que creemos y copiarlo encima del
# proyecto solo serviria para romperlo.
for imprescindible in docker-compose.yml backend/package.json frontend/package.json freeswitch/Dockerfile; do
  [ -e "$TMP/contenido/$imprescindible" ] || abandonar "el paquete no contiene $imprescindible"
done
registrar "Paquete verificado."

cd "$PROYECTO" || abandonar "no existe $PROYECTO"

# El .env no viaja en el paquete (lleva las claves), pero se respalda igual:
# perderlo obligaria a reconstruir la base de datos.
#
# El respaldo va FUERA de la carpeta "estado" a proposito: esa carpeta se
# publica por HTTP para poder consultar el registro del despliegue desde el
# navegador, y dentro lleva la clave de la base de datos, el secreto de los
# tokens y la del Event Socket. Guardarlo ahi seria publicarlas.
if [ -f .env ]; then
  install -m 600 .env /root/env-respaldo
fi

cp -a "$TMP/contenido/." "$PROYECTO/"
registrar "Ficheros actualizados."

registrar "Reconstruyendo contenedores (puede tardar varios minutos)..."
if docker compose up -d --build >> "$LOG" 2>&1; then
  registrar "Contenedores levantados."
else
  abandonar "docker compose up ha fallado (ver la salida de arriba)"
fi

sleep 30
registrar "--- Estado de los contenedores ---"
docker compose ps >> "$LOG" 2>&1

registrar "--- Diagnostico de la centralita ---"
# El diagnostico necesita la contrasena del Event Socket, que vive en el .env.
# Se carga en una subshell para que no quede en el entorno del servicio.
( set -a; . "$PROYECTO/.env" 2>/dev/null; bash "$PROYECTO/scripts/diagnostico-freeswitch.sh" ) >> "$LOG" 2>&1

printf '%s\n' "$DESEADA" > "$MARCADOR"
rm -f "$FALLOS"
registrar "=== $DESEADA desplegada correctamente ==="
