#!/bin/sh
#
# Arranque de FreeSWITCH para la plataforma multi-tenant.
#
# IMPORTANTE: la imagen base (safarov/freeswitch) es MINIMALISTA, construida
# sobre BusyBox. Comprobado sobre el contenedor real: no trae bash, ni
# envsubst, ni openssl, ni gestor de paquetes con el que instalarlos. Por eso
# este script usa /bin/sh (ash) y solo utilidades de BusyBox.
#
# Nota: se usa "set -eu" y no "set -euo pipefail" porque ash no soporta
# pipefail (con bash el script fallaba antes de ejecutar nada).
set -eu

# ---------------------------------------------------------------------------
# 0) Montar la configuración: plantilla de la imagen + nuestra capa encima
# ---------------------------------------------------------------------------
# Esta imagen no guarda su configuración en /etc/freeswitch, sino como
# plantilla en /usr/share/freeswitch/conf/vanilla; su entrypoint original la
# copiaba al arrancar. Al reemplazar ese entrypoint, esa copia dejó de
# hacerse y FreeSWITCH se quedaba sin freeswitch.xml, sin modules.conf.xml y
# sin sofia.conf.xml: no llegaba ni a inicializarse ("Cannot Open log
# directory or XML Root") y se reiniciaba en bucle indefinidamente.
#
# Aquí se rehace ese trabajo de forma explícita y en el orden correcto:
#   1. Se siembra /etc/freeswitch con la plantilla de la imagen.
#   2. Se copia NUESTRA configuración encima, que por tanto siempre gana.
# Ambos pasos son idempotentes: se pueden repetir en cada arranque.
CONF_DIR="/etc/freeswitch"
NUESTRA_CONF="/opt/plataforma-conf"

SEMILLA=""
for candidato in /usr/share/freeswitch/conf/vanilla /usr/share/freeswitch/conf \
                 /etc/freeswitch.dist /usr/local/freeswitch/conf; do
  if [ -f "$candidato/freeswitch.xml" ]; then
    SEMILLA="$candidato"
    break
  fi
done

mkdir -p "$CONF_DIR"

if [ -n "$SEMILLA" ]; then
  echo "[entrypoint] Plantilla de configuración: $SEMILLA"
  for entrada in "$SEMILLA"/*; do
    [ -e "$entrada" ] || continue
    nombre=$(basename "$entrada")
    case "$nombre" in
      # El dialplan y los perfiles SIP de la plantilla son los de
      # DEMOSTRACIÓN de FreeSWITCH: extensiones de eco, conferencias y los
      # usuarios de ejemplo 1000-1019. Se evaluarían antes que los nuestros y
      # capturarían números que aquí significan otra cosa. Los nuestros los
      # sustituyen por completo, así que ni se copian.
      dialplan|sip_profiles|directory) continue ;;
    esac
    # Sin -n a propósito: la plantilla se refresca en cada arranque y es
    # nuestra capa, aplicada justo después, la que decide lo que difiere.
    cp -r "$entrada" "$CONF_DIR/" 2>/dev/null || true
  done
else
  echo "[entrypoint] AVISO: no se encuentra la plantilla de configuración de la imagen."
  echo "[entrypoint] Si FreeSWITCH no arranca, este es el primer sitio donde mirar."
fi

if [ -d "$NUESTRA_CONF" ]; then
  cp -r "$NUESTRA_CONF/." "$CONF_DIR/"
  echo "[entrypoint] Configuración de la plataforma aplicada sobre la plantilla."
else
  echo "[entrypoint] AVISO: no existe $NUESTRA_CONF (imagen mal construida)."
fi

if [ ! -f "$CONF_DIR/freeswitch.xml" ]; then
  echo "[entrypoint] ERROR: falta $CONF_DIR/freeswitch.xml. FreeSWITCH no puede arrancar."
  echo "[entrypoint] Revisa que la imagen base siga trayendo su plantilla de configuración."
  exit 1
fi
echo "[entrypoint] Directorio de configuración: $CONF_DIR"

# ---------------------------------------------------------------------------
# 1) Contraseña del Event Socket (ESL) dentro de su plantilla
# ---------------------------------------------------------------------------
# Antes se usaba `envsubst`, que no existe en esta imagen. Se sustituye con
# expansión de parámetros POSIX, más robusta que un sed: la contraseña puede
# contener /, &, | o cualquier otro carácter que rompería una expresión sed.
: "${FREESWITCH_ESL_PASSWORD:?Debes definir FREESWITCH_ESL_PASSWORD}"

# La contraseña se inserta como ATRIBUTO XML, así que hay que escapar los
# caracteres especiales o el fichero queda mal formado y FreeSWITCH no levanta
# el event socket (el backend se quedaría sin poder hablar con él).
# El valor entra por stdin, nunca dentro de la expresión de sed, así que no hay
# forma de que un carácter raro rompa el propio sed.
escapar_xml() {
  printf '%s' "$1" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g' \
                         -e 's/"/\&quot;/g' -e "s/'/\&apos;/g"
}

PASSWORD_XML=$(escapar_xml "$FREESWITCH_ESL_PASSWORD")

PLANTILLA="${CONF_DIR}/autoload_configs/event_socket.conf.xml.template"
DESTINO="${CONF_DIR}/autoload_configs/event_socket.conf.xml"
MARCA='${FREESWITCH_ESL_PASSWORD}'

if [ -f "$PLANTILLA" ]; then
  CONTENIDO=$(cat "$PLANTILLA")
  case "$CONTENIDO" in
    *"$MARCA"*)
      ANTES=${CONTENIDO%%"$MARCA"*}
      DESPUES=${CONTENIDO#*"$MARCA"}
      printf '%s%s%s\n' "$ANTES" "$PASSWORD_XML" "$DESPUES" > "$DESTINO"
      echo "[entrypoint] event_socket.conf.xml generado."
      ;;
    *)
      printf '%s\n' "$CONTENIDO" > "$DESTINO"
      echo "[entrypoint] AVISO: la plantilla no contenía el marcador de contraseña."
      ;;
  esac
else
  echo "[entrypoint] AVISO: no se encuentra la plantilla del event socket."
fi

# ---------------------------------------------------------------------------
# 2) Variables de la plataforma SIN destruir las de la imagen base
# ---------------------------------------------------------------------------
# Aquí estaba uno de los fallos de raíz: se copiaba un vars.xml propio ENCIMA
# del de la imagen. Ese fichero define centenares de variables ($${sounds_dir},
# $${base_dir}, $${global_codec_prefs}, $${hold_music}, rutas de grabación...)
# que usan el resto de ficheros de configuración de la propia imagen. Al
# reemplazarlo, esas variables quedaban vacías y FreeSWITCH arrancaba con
# módulos y perfiles rotos.
#
# Lo correcto es AÑADIR las nuestras al final del vars.xml original, que es
# donde el preprocesador ya ha definido las de base y donde una redefinición
# gana. Se hace en arranque (no en la imagen) para poder cambiar la IP pública
# sin reconstruir nada.

# IP pública anunciada en el SDP. Sin esto, FreeSWITCH anuncia la IP interna
# del contenedor (10.42.x.x) y NO HAY AUDIO con nada que esté fuera de Docker:
# es el clásico "la llamada conecta pero no se oye a nadie".
IP_PUBLICA="${FREESWITCH_EXTERNAL_IP:-}"
if [ -z "$IP_PUBLICA" ] && [ -n "${PUBLIC_WSS_URL:-}" ]; then
  # wss://159.69.215.51:7443 -> 159.69.215.51
  IP_PUBLICA=$(printf '%s' "$PUBLIC_WSS_URL" | sed -e 's|^[a-zA-Z][a-zA-Z0-9+.-]*://||' -e 's|[:/].*$||')
fi
if [ -z "$IP_PUBLICA" ] || [ "$IP_PUBLICA" = "localhost" ] || [ "$IP_PUBLICA" = "127.0.0.1" ]; then
  # Sin IP pública conocida se deja que FreeSWITCH la descubra por STUN. Es
  # peor que ponerla a mano, pero mejor que anunciar la IP del contenedor.
  EXT_IP="stun:stun.freeswitch.org"
  echo "[entrypoint] AVISO: no hay IP pública configurada (FREESWITCH_EXTERNAL_IP)."
  echo "[entrypoint] Se usará descubrimiento por STUN. Para un servidor con IP fija,"
  echo "[entrypoint] define FREESWITCH_EXTERNAL_IP en el .env: es mucho más fiable."
else
  EXT_IP="$IP_PUBLICA"
  echo "[entrypoint] IP pública anunciada en SDP: $EXT_IP"
fi

VARS_PLATAFORMA="${CONF_DIR}/vars_plataforma.xml"
cat > "$VARS_PLATAFORMA" <<XML
<include>
  <!--
    Generado en cada arranque por entrypoint.sh a partir de variables de
    entorno. NO editar a mano: se sobrescribe. Se incluye al FINAL de
    vars.xml, así que lo que hay aquí gana sobre los valores de la imagen.
  -->
  <X-PRE-PROCESS cmd="set" data="domain=${FREESWITCH_DOMAIN:-plataforma.local}"/>
  <X-PRE-PROCESS cmd="set" data="external_sip_ip=${EXT_IP}"/>
  <X-PRE-PROCESS cmd="set" data="external_rtp_ip=${EXT_IP}"/>
  <X-PRE-PROCESS cmd="set" data="rtp_start_port=${FREESWITCH_RTP_START:-16384}"/>
  <X-PRE-PROCESS cmd="set" data="rtp_end_port=${FREESWITCH_RTP_END:-16484}"/>
  <X-PRE-PROCESS cmd="set" data="default_country=${FREESWITCH_PAIS:-ES}"/>
  <!--
    Carpeta de certificados. Se fija explícitamente al punto de montaje del
    volumen "freeswitch-tls" para que coincidan tres cosas que en la
    configuración por defecto no tienen por qué coincidir: dónde deja el
    certificado el contenedor fs-certs, dónde lo busca el perfil SIP
    (tls-cert-dir) y dónde escribe FreeSWITCH el certificado DTLS que
    genera solo para WebRTC.
  -->
  <X-PRE-PROCESS cmd="set" data="certs_dir=${CONF_DIR}/tls"/>
</include>
XML
echo "[entrypoint] vars_plataforma.xml generado."

# Enganchar nuestro fichero al final del vars.xml de la imagen (idempotente).
VARS_BASE="${CONF_DIR}/vars.xml"
LINEA_INCLUDE='  <X-PRE-PROCESS cmd="include" data="vars_plataforma.xml"/>'
if [ -f "$VARS_BASE" ]; then
  if grep -q 'vars_plataforma.xml' "$VARS_BASE"; then
    echo "[entrypoint] vars.xml ya incluye vars_plataforma.xml."
  else
    # Se inserta justo ANTES del ÚLTIMO </include>, para que nuestras
    # definiciones se procesen las últimas y por tanto ganen.
    # Se busca el número de línea del último cierre en vez de hacer un
    # sed global: un sed "s|</include>|...|" añadiría la línea en TODOS
    # los cierres si el fichero tuviera más de uno.
    LINEA_CIERRE=$(grep -n '</include>' "$VARS_BASE" | tail -n 1 | cut -d: -f1)
    if [ -n "$LINEA_CIERRE" ]; then
      sed -i "${LINEA_CIERRE}i\\${LINEA_INCLUDE}" "$VARS_BASE"
    else
      printf '%s\n' "$LINEA_INCLUDE" >> "$VARS_BASE"
    fi
    echo "[entrypoint] vars.xml enlazado con vars_plataforma.xml."
  fi
else
  echo "[entrypoint] AVISO: no existe $VARS_BASE; se crea uno mínimo."
  printf '<include>\n%s\n</include>\n' "$LINEA_INCLUDE" > "$VARS_BASE"
fi

# ---------------------------------------------------------------------------
# 3) Certificados TLS (teléfono web WSS + SIP TLS)
# ---------------------------------------------------------------------------
# Los genera el contenedor fs-certs ANTES de que arranque este (docker-compose
# lo espera con service_completed_successfully), porque esta imagen no trae
# openssl. Aquí solo se comprueba y se avisa con claridad si falta algo, en
# lugar de abortar: sin WSS el teléfono web no va, pero las llamadas SIP
# normales por UDP/TCP sí, y dejar toda la centralita parada sería peor.
TLS_DIR="${CONF_DIR}/tls"
mkdir -p "$TLS_DIR"

if [ -f "$TLS_DIR/wss.pem" ]; then
  echo "[entrypoint] Certificado WSS encontrado: $TLS_DIR/wss.pem"
  # FreeSWITCH usa agent.pem para SIP TLS (5061). Si no está, se reutiliza el
  # mismo certificado: es autofirmado igualmente y evita un error de arranque
  # del perfil con tls="true".
  if [ ! -f "$TLS_DIR/agent.pem" ]; then
    cp "$TLS_DIR/wss.pem" "$TLS_DIR/agent.pem"
    echo "[entrypoint] agent.pem creado a partir de wss.pem."
  fi
else
  echo "[entrypoint] AVISO: no existe $TLS_DIR/wss.pem."
  echo "[entrypoint] El teléfono web (WSS) NO funcionará. Revisa el contenedor"
  echo "[entrypoint] 'fs-certs' con: docker compose logs fs-certs"
  echo "[entrypoint] Las llamadas SIP normales (UDP/TCP) no se ven afectadas."
fi

# ---------------------------------------------------------------------------
# 4) Directorios dinámicos que rellena el backend
# ---------------------------------------------------------------------------
mkdir -p "${CONF_DIR}/directory" \
         "${CONF_DIR}/sip_profiles/external" \
         "${CONF_DIR}/dialplan/public/dinamico" \
         "${CONF_DIR}/dialplan/default/dinamico" \
         "${CONF_DIR}/prompts"

# Los X-PRE-PROCESS include con comodín fallan ruidosamente si la carpeta está
# vacía (recién creado el volumen, sin clientes todavía). Un fichero vacío
# válido evita ese error sin cambiar el comportamiento.
for carpeta in "${CONF_DIR}/dialplan/public/dinamico" "${CONF_DIR}/dialplan/default/dinamico" \
               "${CONF_DIR}/sip_profiles/external" "${CONF_DIR}/directory"; do
  if [ ! -f "$carpeta/00_vacio.xml" ]; then
    printf '<include>\n  <!-- Marcador para que el include con comodín nunca quede vacío. -->\n</include>\n' > "$carpeta/00_vacio.xml"
  fi
done

# La imagen base trae un gateway de ejemplo que intenta registrarse contra un
# proveedor inexistente y llena el log de errores cada 30 segundos.
rm -f "${CONF_DIR}/sip_profiles/external/example.xml" \
      "${CONF_DIR}/sip_profiles/external/example-ipv6.xml" 2>/dev/null || true

# Perfiles IPv6 de la imagen base: en un servidor sin IPv6 fallan al arrancar
# y ensucian el diagnóstico. Se quitan; si algún día hace falta IPv6, se
# reactivan quitando estas dos líneas.
rm -f "${CONF_DIR}/sip_profiles/internal-ipv6.xml" \
      "${CONF_DIR}/sip_profiles/external-ipv6.xml" 2>/dev/null || true

# ---------------------------------------------------------------------------
# 5) Arranque
# ---------------------------------------------------------------------------
# -nonat: no intentar uPnP/NAT-PMP (es un servidor con IP pública; la IP
#         externa se anuncia explícitamente vía external_sip_ip/external_rtp_ip).
# -nf   : no hacer fork, para que el proceso 1 del contenedor sea FreeSWITCH.
# -c    : salida por consola, que es lo que recoge "docker compose logs".
echo "[entrypoint] Arrancando FreeSWITCH..."
exec freeswitch -nonat -nf -c
