# Notas sobre la imagen Docker de FreeSWITCH

`freeswitch/Dockerfile` usa como base `safarov/freeswitch:latest`, una imagen
comunitaria ampliamente usada porque evita compilar FreeSWITCH desde fuente
(proceso largo, con muchos módulos opcionales a elegir). No he podido tirar de
esta imagen desde este entorno de desarrollo para confirmarla en el momento de
escribir esto, así que la primera vez que ejecutes `docker compose up --build`
en tu VM es el momento de validar que sigue existiendo en Docker Hub.

## Si la imagen no está disponible

**Opción A — SignalWire (oficial)**: FreeSWITCH pasó a distribuirse vía el
repositorio APT de SignalWire, que en 2023 empezó a requerir un token
personal gratuito para acceder a los paquetes. Pasos generales:
1. Crea una cuenta gratuita en signalwire.com y genera un "personal access token".
2. Sustituye la línea `FROM safarov/freeswitch:latest` por un Dockerfile que
   instale FreeSWITCH desde `https://freeswitch.signalwire.com/repo/deb/debian-release/`
   usando ese token como credencial del repositorio APT.

**Opción B — compilar desde fuente**: usa la imagen oficial `debian:bookworm-slim`
como base y sigue la guía de compilación de FreeSWITCH 1.10.x desde
`https://github.com/signalwire/freeswitch` (requiere más tiempo de build, pero
no depende de ninguna imagen de terceros).

**Opción C — buscar otra imagen comunitaria activa** en Docker Hub buscando
"freeswitch" y comprobando la fecha del último `push` antes de usarla en nada
serio.

Independientemente de la opción elegida, lo único que debe conservarse es la
estructura de `/etc/freeswitch/` (directory, dialplan, sip_profiles,
autoload_configs) tal como la sobreescribe `COPY conf/ /etc/freeswitch/` en el
Dockerfile: el resto de este proyecto (backend, generación de XML, ESL) no
depende de qué imagen base se use, solo de que exponga FreeSWITCH con ESL en
el puerto 8021 y los perfiles Sofia en los puertos documentados en
`docker-compose.yml`.

---

# Puesta a punto de la centralita (revisión de septiembre)

Esta sección documenta los fallos que impedían que FreeSWITCH funcionara y
cómo están resueltos, para que no se vuelvan a introducir por descuido.

## Los seis fallos que había

**1. El `vars.xml` propio destruía el de la imagen.** El Dockerfile hacía
`COPY conf/ /etc/freeswitch/`, y entre esos ficheros iba un `vars.xml` de ocho
líneas que reemplazaba —no complementaba— el de la imagen base, que tiene
cientos y define las variables (`$${sounds_dir}`, `$${base_dir}`,
`$${hold_music}`, `$${global_codec_prefs}`…) que usa el resto de la
configuración de la propia imagen. FreeSWITCH arrancaba con módulos y perfiles
a medias. Ahora las variables propias las genera `entrypoint.sh` en
`vars_plataforma.xml` y las engancha con un `X-PRE-PROCESS include` justo antes
del último `</include>` del `vars.xml` original: se procesan las últimas, así
que una redefinición gana, y no se pierde nada.

**2. El perfil interno rechazaba a todos los teléfonos.** Tenía
`apply-inbound-acl="docker_networks"`, y esa lista es `default="deny"` con
sólo `10.42.0.0/16` permitido. Cualquier softphone real recibía un 403 y no
podía registrarse jamás. Esa lista existe para proteger el Event Socket, no
para filtrar SIP. El control de acceso de las extensiones lo hace `auth-calls`
(usuario y contraseña), que es lo correcto para clientes con IP variable.

**3. Ninguna llamada encontraba su dialplan.** Cada extensión se escribía con
`<variable name="user_context" value="tenant_<subdominio>"/>`, un contexto que
no genera nadie. En cuanto una extensión registrada descolgaba, FreeSWITCH
buscaba ese contexto, no lo encontraba y tiraba la llamada. Ahora es `default`.
El aislamiento entre clientes no dependía de eso: lo garantizan la variable
`tenant_subdominio` (que filtra la ruta saliente de cada cliente) y el bridge a
`user/<ext>@<dominio del propio tenant>`.

**4. No había audio.** Faltaban `ext-sip-ip` y `ext-rtp-ip` en los dos perfiles
Sofia, así que FreeSWITCH anunciaba en el SDP la IP interna de Docker
(10.42.x.x). El síntoma es el clásico "la llamada entra, suena y se descuelga,
pero no se oye a nadie". Ahora salen de `FREESWITCH_EXTERNAL_IP` (o del host de
`PUBLIC_WSS_URL` si aquella está vacía), y si no hay ninguna se cae a
descubrimiento por STUN, que es peor pero no deja el sistema mudo.

**5. El dominio SIP no coincidía consigo mismo.** La entidad `Tenant` y el
panel documentaban `acme` → `acme.plataforma.local`, pero el generador de XML
declaraba el dominio como `acme` a secas. Registrarse con el nombre que decía
la interfaz fallaba siempre. Ahora hay una única función,
`FreeswitchService.dominioSipTenant()`, que decide el formato, y la usan el
directorio, los bridge y el buzón de voz.

**6. El teléfono web fallaba en silencio.** El certificado WSS es autofirmado y
el navegador cierra la conexión sin decir nada hasta que se visita
`https://<ip>:7443` una vez y se acepta. Ahora la pantalla del teléfono web lo
explica antes de la primera llamada, con enlace directo, y detecta ese cierre
para volver a avisar. Además `fs-certs` genera también `agent.pem` (SIP TLS),
que faltaba y hacía fallar el arranque del perfil con `tls="true"`.

## Cosas que conviene saber

- **Numeración**: interno 2–5 dígitos, saliente 6–15 más los números cortos de
  emergencia (112, 06x, 08x, 09x). Los rangos no deben solaparse nunca, o el
  destino de un número depende del orden alfabético de los ficheros.
- **DID entrantes**: se reconocen con y sin prefijo internacional, y con `+` o
  `00` delante, porque cada proveedor entrega el mismo número de una forma.
  El prefijo del país sale de `FREESWITCH_PREFIJO_PAIS` (34 por defecto).
- **Fraude telefónico**: la lista `proveedores_sip` de `acl.conf.xml` viene en
  `default="allow"` para que un servidor de pruebas funcione al levantarlo.
  Antes de dar servicio real, ponla en `deny` y añade una línea por cada IP de
  proveedor. Es la principal defensa contra que un desconocido inyecte
  llamadas por tu troncal.
- **Días de la semana**: FreeSWITCH numera 1=domingo y el panel usa ISO
  1=lunes. La conversión está en `rangosWdayFreeswitch()`; un rango que da la
  vuelta a la semana se parte en varias condiciones porque FreeSWITCH no
  entiende rangos que envuelven.

## Diagnóstico

```
bash scripts/diagnostico-freeswitch.sh
```

Recorre de abajo arriba todo lo necesario para que una llamada funcione
(contenedores, certificados, núcleo, IP anunciada en el SDP, perfiles SIP,
Event Socket, configuración generada por el panel y registros activos) y marca
cada paso. Es más rápido que mirar ocho sitios a mano.

---

# El fallo de fondo: la configuración nunca llegaba a existir

Todo lo anterior era necesario, pero por debajo había un fallo que hacía que
nada de ello importara: **FreeSWITCH no llegaba ni a inicializarse.**

La imagen base no guarda su configuración en `/etc/freeswitch`. La trae como
plantilla en `/usr/share/freeswitch/conf/vanilla`, y es su propio entrypoint
el que la copia a `/etc/freeswitch` en el primer arranque. Al sustituir ese
entrypoint por el nuestro, esa copia dejó de hacerse. Y como el Dockerfile
hacía `COPY conf/ /etc/freeswitch/`, el contenedor acababa con exactamente
nuestros diez ficheros y nada más: sin `freeswitch.xml`, sin
`modules.conf.xml`, sin `sofia.conf.xml`. El resultado en el log era

```
switch_xml.c:1439 Couldn't open /etc/freeswitch/freeswitch.xml
Cannot Initialize [Cannot Open log directory or XML Root!]
```

y el contenedor reiniciándose cada dos segundos, indefinidamente.

La solución es explícita y ya no depende de nada implícito: nuestra
configuración se guarda en `/opt/plataforma-conf` y `entrypoint.sh`, en cada
arranque, siembra `/etc/freeswitch` con la plantilla de la imagen y **luego**
copia la nuestra encima. Nuestra capa siempre gana, y no se pierde nada de lo
que la imagen necesita para arrancar.

De la plantilla se excluyen a propósito tres carpetas: `dialplan`,
`sip_profiles` y `directory`. Son el material de demostración de FreeSWITCH
—extensiones de eco, salas de conferencia, los usuarios de ejemplo 1000-1019,
un gateway a ninguna parte— y se evaluaría antes que lo nuestro, capturando
números que en esta plataforma significan otra cosa. Los ficheros
`dialplan/default.xml` y `dialplan/public.xml` propios existen justamente para
sustituir a los de demostración y no incluir más que lo que genera el panel.

## Despliegue automático

`scripts/instalar-autodespliegue.sh` deja instalado un temporizador de systemd
que cada dos minutos mira `despliegue.txt` en el repositorio. Cuando su
contenido cambia, el servidor descarga ese paquete, lo verifica, lo instala,
reconstruye los contenedores y pasa el diagnóstico, todo solo.

Publicar una versión nueva es, por tanto, subir el `.tar.gz` al repositorio y
escribir su nombre en `despliegue.txt`. El registro del último despliegue
queda en `http://<ip>:8090/despliegue.log`.

Salvaguardas, porque esto corre sin nadie mirando: el paquete se descomprime
aparte y sólo se instala si contiene lo que debe; el `.env` se respalda antes
(en `/root/env-respaldo`, fuera de la carpeta que se publica por HTTP, porque
lleva las claves); y una versión que falla se reintenta tres veces y se
abandona, en vez de machacar el servidor cada dos minutos para siempre.
