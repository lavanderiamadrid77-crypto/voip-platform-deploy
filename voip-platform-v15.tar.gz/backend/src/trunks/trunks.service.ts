import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { cifrar, descifrar } from '../common/crypto.util';
import { Tenant } from '../common/entities/tenant.entity';
import { Trunk } from '../common/entities/trunk.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { ActualizarTrunkDto, CrearTrunkDto } from './dto/trunk.dto';

@Injectable()
export class TrunksService {
  constructor(
    @InjectRepository(Trunk) private readonly repo: Repository<Trunk>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  /** tenantId undefined -> lista solo trunks compartidos a nivel plataforma */
  listar(tenantId?: string): Promise<Trunk[]> {
    return this.repo.find({ where: tenantId ? { tenantId } : {}, order: { creadoEn: 'DESC' } });
  }

  async crear(tenantId: string | undefined, dto: CrearTrunkDto): Promise<Trunk> {
    const trunk = this.repo.create({
      tenantId,
      nombre: dto.nombre,
      proveedor: dto.proveedor,
      host: dto.host,
      puerto: dto.puerto ?? 5060,
      usuario: dto.usuario,
      passwordCifrada: dto.password ? cifrar(dto.password) : undefined,
      costoPorMinuto: dto.costoPorMinuto ?? 0,
    });
    const guardado = await this.repo.save(trunk);

    await this.freeswitch
      .escribirTrunkXml({
        nombre: guardado.nombre,
        host: guardado.host,
        puerto: guardado.puerto,
        usuario: guardado.usuario,
        passwordPlano: dto.password,
      })
      .catch(() => undefined); // FreeSWITCH puede no estar disponible en este momento; se reintenta manualmente

    await this.regenerarRutasSalientes(tenantId);
    return guardado;
  }

  /**
   * Edita un proveedor existente. Solo se tocan los campos enviados.
   *
   * Si cambia algo que afecta a la conexión SIP (nombre, host, puerto,
   * usuario o contraseña) hay que reescribir el gateway en FreeSWITCH; y si
   * cambia el NOMBRE hay que borrar además el gateway antiguo, porque el
   * fichero XML se llama como el trunk y si no quedaría uno huérfano
   * registrándose contra el proveedor con la configuración vieja.
   */
  async actualizar(id: string, dto: ActualizarTrunkDto): Promise<Trunk> {
    const trunk = await this.repo.findOne({ where: { id } });
    if (!trunk) throw new NotFoundException('Proveedor (troncal) no encontrado');

    const nombreAnterior = trunk.nombre;

    if (dto.nombre !== undefined) trunk.nombre = dto.nombre;
    if (dto.proveedor !== undefined) trunk.proveedor = dto.proveedor;
    if (dto.host !== undefined) trunk.host = dto.host;
    if (dto.puerto !== undefined) trunk.puerto = dto.puerto;
    if (dto.usuario !== undefined) trunk.usuario = dto.usuario;
    if (dto.costoPorMinuto !== undefined) trunk.costoPorMinuto = dto.costoPorMinuto;
    if (dto.prioridad !== undefined) trunk.prioridad = dto.prioridad;
    if (dto.activo !== undefined) trunk.activo = dto.activo;
    // Una contraseña vacía significa "no la cambies", no "bórrala": si no
    // fuese así, editar solo el nombre dejaría el trunk sin poder registrarse.
    if (dto.password) trunk.passwordCifrada = cifrar(dto.password);

    const guardado = await this.repo.save(trunk);

    if (nombreAnterior !== guardado.nombre) {
      await this.freeswitch.eliminarTrunkXml(nombreAnterior).catch(() => undefined);
    }

    // Para reescribir el gateway hace falta la contraseña EN CLARO: si no
    // viene en el DTO, se descifra la que ya estaba guardada.
    const passwordPlano =
      dto.password ?? (guardado.passwordCifrada ? descifrar(guardado.passwordCifrada) : undefined);

    await this.freeswitch
      .escribirTrunkXml({
        nombre: guardado.nombre,
        host: guardado.host,
        puerto: guardado.puerto,
        usuario: guardado.usuario,
        passwordPlano,
      })
      .catch(() => undefined);

    await this.regenerarRutasSalientes(guardado.tenantId);
    return guardado;
  }

  async eliminar(id: string): Promise<void> {
    const trunk = await this.repo.findOne({ where: { id } });
    if (!trunk) throw new NotFoundException('Trunk no encontrado');
    await this.freeswitch.eliminarTrunkXml(trunk.nombre).catch(() => undefined);
    await this.repo.remove(trunk);
    await this.regenerarRutasSalientes(trunk.tenantId);
  }

  /** Solo para uso interno (ej. reconstrucción de config tras migración) */
  async obtenerPasswordEnClaro(id: string): Promise<string | undefined> {
    const trunk = await this.repo.findOne({ where: { id } });
    return trunk?.passwordCifrada ? descifrar(trunk.passwordCifrada) : undefined;
  }

  /**
   * Recalcula y reescribe el dialplan de salida (ver
   * FreeswitchService.escribirRutaSalienteTenantXml) para un tenant, o
   * para TODOS los tenants si `tenantId` es undefined (esto ocurre cuando
   * cambia un trunk COMPARTIDO, que afecta a cualquier tenant que no tenga
   * trunks propios con mayor prioridad).
   */
  async regenerarRutasSalientes(tenantId?: string): Promise<void> {
    const tenants = tenantId
      ? [await this.tenantRepo.findOne({ where: { id: tenantId } })]
      : await this.tenantRepo.find();

    for (const tenant of tenants) {
      if (!tenant) continue;
      const activos = await this.repo
        .createQueryBuilder('trunk')
        .where('trunk.activo = true')
        .andWhere('(trunk.tenantId = :tenantId OR trunk.tenantId IS NULL)', { tenantId: tenant.id })
        .orderBy('trunk.prioridad', 'ASC')
        .getMany();

      await this.freeswitch
        .escribirRutaSalienteTenantXml({
          tenantId: tenant.id,
          subdominioTenant: tenant.subdominio,
          nombresTrunksOrdenados: activos.map((t) => t.nombre),
        })
        .catch(() => undefined);
    }
  }
}
