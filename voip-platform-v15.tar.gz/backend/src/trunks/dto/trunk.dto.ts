import { IsBoolean, IsInt, IsOptional, IsString, Min } from 'class-validator';

export class CrearTrunkDto {
  @IsString()
  nombre: string;

  @IsString()
  proveedor: string;

  @IsString()
  host: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  puerto?: number;

  @IsOptional()
  @IsString()
  usuario?: string;

  @IsOptional()
  @IsString()
  password?: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  costoPorMinuto?: number;
}

/**
 * Edición de un proveedor ya existente. Todos los campos son opcionales:
 * se actualiza solo lo que llegue. Si se cambia el nombre, el host, el
 * puerto, el usuario o la contraseña hay que reescribir el gateway en
 * FreeSWITCH (lo hace el servicio).
 */
export class ActualizarTrunkDto {
  @IsOptional()
  @IsString()
  nombre?: string;

  @IsOptional()
  @IsString()
  proveedor?: string;

  @IsOptional()
  @IsString()
  host?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  puerto?: number;

  @IsOptional()
  @IsString()
  usuario?: string;

  /** Si no se envía, se conserva la contraseña actual (no se borra). */
  @IsOptional()
  @IsString()
  password?: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  costoPorMinuto?: number;

  @IsOptional()
  @IsInt()
  @Min(0)
  prioridad?: number;

  @IsOptional()
  @IsBoolean()
  activo?: boolean;
}
