import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import * as crypto from 'crypto';
import { Repository } from 'typeorm';
import { cifrar, descifrar } from '../common/crypto.util';
import { Extension } from '../common/entities/extension.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { ActualizarExtensionDto, CrearExtensionDto } from './dto/extension.dto';

@Injectable()
export class ExtensionsService {
  constructor(
    @InjectRepository(Extension) private readonly repo: Repository<Extension>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  listarPorTenant(tenantId: string): Promise<Extension[]> {
    return this.repo.find({ where: { tenantId }, order: { numero: 'ASC' } });
  }

  /** Genera una contraseña SIP segura (16 caracteres alfanuméricos) */
  private generarPasswordSegura(): string {
    return crypto.randomBytes(12).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 16);
  }

  /**
   * Crea la extensión en la base de datos y la aprovisiona en FreeSWITCH
   * (fichero XML de directory + reloadxml). Devuelve la contraseña en
   * claro UNA sola vez: el llamador debe mostrarla al usuario y no se
   * vuelve a poder recuperar.
   */
  async crear(
    tenantId: string,
    dto: CrearExtensionDto,
  ): Promise<{ extension: Extension; passwordSip: string }> {
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Tenant no encontrado');

    const total = await this.repo.count({ where: { tenantId } });
    if (total >= tenant.extensionesMax) {
      throw new ConflictException(
        `Se alcanzó el límite de ${tenant.extensionesMax} extensiones para este tenant`,
      );
    }

    const existe = await this.repo.findOne({ where: { tenantId, numero: dto.numero } });
    if (existe) throw new ConflictException('Ese número de extensión ya existe en este tenant');

    const passwordSip = this.generarPasswordSegura();
    const passwordCifrada = cifrar(passwordSip);

    const extension = this.repo.create({
      tenantId,
      numero: dto.numero,
      nombre: dto.nombre,
      tipo: dto.tipo,
      codecs: dto.codecs ?? 'OPUS,G722,PCMU,PCMA',
      webrtcHabilitado: dto.webrtcHabilitado ?? true,
      passwordCifrada,
    });
    const guardada = await this.repo.save(extension);

    try {
      await this.freeswitch.escribirExtensionXml({
        tenantId: tenant.id,
        subdominioTenant: tenant.subdominio,
        numero: dto.numero,
        nombre: dto.nombre,
        passwordPlano: passwordSip,
        codecs: extension.codecs,
      });
    } catch (err) {
      // Si FreeSWITCH no está disponible, la extensión queda creada en BD
      // pero marcada para re-aprovisionar; no bloqueamos el flujo de gestión.
      await this.repo.update(guardada.id, { activo: false });
    }

    return { extension: guardada, passwordSip };
  }

  /**
   * Edita una extensión. Devuelve la contraseña SIP en claro SOLO si se ha
   * pedido regenerarla (igual que al crear: se enseña una vez y ya no se
   * puede volver a consultar).
   *
   * Si cambia el número hay que borrar el XML antiguo ANTES de escribir el
   * nuevo, porque el fichero se llama como el número: si no, el usuario SIP
   * viejo seguiría registrable y el teléfono seguiría funcionando con la
   * extensión que creíamos haber renombrado.
   */
  async actualizar(
    tenantId: string,
    id: string,
    dto: ActualizarExtensionDto,
  ): Promise<{ extension: Extension; passwordSip?: string }> {
    const extension = await this.repo.findOne({ where: { id, tenantId } });
    if (!extension) throw new NotFoundException('Extensión no encontrada');

    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Tenant no encontrado');

    const numeroAnterior = extension.numero;

    if (dto.numero !== undefined && dto.numero !== extension.numero) {
      const existe = await this.repo.findOne({ where: { tenantId, numero: dto.numero } });
      if (existe) throw new ConflictException('Ese número de extensión ya existe en este tenant');
      extension.numero = dto.numero;
    }
    if (dto.nombre !== undefined) extension.nombre = dto.nombre;
    if (dto.tipo !== undefined) extension.tipo = dto.tipo;
    if (dto.codecs !== undefined) extension.codecs = dto.codecs;
    if (dto.webrtcHabilitado !== undefined) extension.webrtcHabilitado = dto.webrtcHabilitado;
    if (dto.activo !== undefined) extension.activo = dto.activo;

    let passwordSip: string | undefined;
    if (dto.regenerarPassword) {
      passwordSip = this.generarPasswordSegura();
      extension.passwordCifrada = cifrar(passwordSip);
    }

    const guardada = await this.repo.save(extension);

    if (numeroAnterior !== guardada.numero) {
      await this.freeswitch
        .eliminarExtensionXml(tenant.subdominio, numeroAnterior)
        .catch(() => undefined);
    }

    // Para reescribir el XML hace falta la contraseña en claro: la nueva si
    // se ha regenerado, o la que ya había, descifrada.
    const passwordPlano =
      passwordSip ?? (guardada.passwordCifrada ? descifrar(guardada.passwordCifrada) : undefined);

    if (passwordPlano) {
      await this.freeswitch
        .escribirExtensionXml({
          tenantId: tenant.id,
          subdominioTenant: tenant.subdominio,
          numero: guardada.numero,
          nombre: guardada.nombre,
          passwordPlano,
          codecs: guardada.codecs,
        })
        .catch(() => undefined);
    }

    return { extension: guardada, passwordSip };
  }

  async eliminar(tenantId: string, id: string): Promise<void> {
    const extension = await this.repo.findOne({ where: { id, tenantId } });
    if (!extension) throw new NotFoundException('Extensión no encontrada');
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (tenant) {
      await this.freeswitch.eliminarExtensionXml(tenant.subdominio, extension.numero).catch(() => undefined);
    }
    await this.repo.remove(extension);
  }
}
