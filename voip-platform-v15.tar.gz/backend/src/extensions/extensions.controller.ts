import { Body, Controller, Delete, Get, Param, Post, UseGuards, Patch } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { ActualizarExtensionDto, CrearExtensionDto } from './dto/extension.dto';
import { ExtensionsService } from './extensions.service';

@ApiTags('extensions')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('api/tenants/:tenantId/extensions')
export class ExtensionsController {
  constructor(private readonly service: ExtensionsService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN, Rol.RESELLER, Rol.USUARIO)
  listar(@Param('tenantId') tenantId: string) {
    return this.service.listarPorTenant(tenantId);
  }

  @Post()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  crear(@Param('tenantId') tenantId: string, @Body() dto: CrearExtensionDto) {
    return this.service.crear(tenantId, dto);
  }

  @Patch(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  actualizar(
    @Param('tenantId') tenantId: string,
    @Param('id') id: string,
    @Body() dto: ActualizarExtensionDto,
  ) {
    return this.service.actualizar(tenantId, id, dto);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  eliminar(@Param('tenantId') tenantId: string, @Param('id') id: string) {
    return this.service.eliminar(tenantId, id);
  }
}
