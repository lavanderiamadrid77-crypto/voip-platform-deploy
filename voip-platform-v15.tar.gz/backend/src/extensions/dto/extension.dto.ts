import { IsBoolean, IsEnum, IsOptional, IsString, Matches } from 'class-validator';
import { TipoExtension } from '../../common/entities/extension.entity';

export class CrearExtensionDto {
  @IsString()
  @Matches(/^[0-9]{3,6}$/, { message: 'El número de extensión debe ser numérico (3-6 dígitos)' })
  numero: string;

  @IsString()
  nombre: string;

  @IsEnum(TipoExtension)
  tipo: TipoExtension;

  @IsOptional()
  @IsString()
  codecs?: string;

  @IsOptional()
  @IsBoolean()
  webrtcHabilitado?: boolean;
}

/**
 * Edición de una extensión existente. El número se puede cambiar, pero eso
 * obliga a reescribir el fichero XML (el nombre del fichero es el número) y
 * a que el teléfono se reconfigure con el nuevo usuario SIP.
 *
 * `regenerarPassword` fuerza una contraseña SIP nueva: se devuelve en claro
 * una única vez, igual que al crear.
 */
export class ActualizarExtensionDto {
  @IsOptional()
  @IsString()
  @Matches(/^[0-9]{3,6}$/, { message: 'El número de extensión debe ser numérico (3-6 dígitos)' })
  numero?: string;

  @IsOptional()
  @IsString()
  nombre?: string;

  @IsOptional()
  @IsEnum(TipoExtension)
  tipo?: TipoExtension;

  @IsOptional()
  @IsString()
  codecs?: string;

  @IsOptional()
  @IsBoolean()
  webrtcHabilitado?: boolean;

  @IsOptional()
  @IsBoolean()
  activo?: boolean;

  @IsOptional()
  @IsBoolean()
  regenerarPassword?: boolean;
}
