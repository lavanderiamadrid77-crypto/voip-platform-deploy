import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { TenantScopeGuard } from '../common/guards/tenant-scope.guard';
import { ActualizarHorarioDto, CrearHorarioDto } from './dto/horario.dto';
import { HorariosService } from './horarios.service';

/** Horarios de oficina de un cliente: cuándo entran las llamadas y a dónde van. */
@ApiTags('horarios')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, TenantScopeGuard)
@Controller('api/tenants/:tenantId/horarios')
export class HorariosController {
  constructor(private readonly service: HorariosService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  listar(@Param('tenantId') tenantId: string) {
    return this.service.listar(tenantId);
  }

  @Get(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  obtener(@Param('tenantId') tenantId: string, @Param('id') id: string) {
    return this.service.obtener(tenantId, id);
  }

  @Post()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  crear(@Param('tenantId') tenantId: string, @Body() dto: CrearHorarioDto) {
    return this.service.crear(tenantId, dto);
  }

  @Patch(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  actualizar(
    @Param('tenantId') tenantId: string,
    @Param('id') id: string,
    @Body() dto: ActualizarHorarioDto,
  ) {
    return this.service.actualizar(tenantId, id, dto);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  eliminar(@Param('tenantId') tenantId: string, @Param('id') id: string) {
    return this.service.eliminar(tenantId, id);
  }
}
