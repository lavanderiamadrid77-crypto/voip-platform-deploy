import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AudioPrompt } from '../common/entities/audio-prompt.entity';
import { Extension } from '../common/entities/extension.entity';
import { Horario, HorarioDestinoTipo } from '../common/entities/horario.entity';
import { HorarioFranja } from '../common/entities/horario-franja.entity';
import { Ivr } from '../common/entities/ivr.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { ActualizarHorarioDto, CrearHorarioDto, FranjaDto } from './dto/horario.dto';

/** Forma resuelta de un destino, ya lista para el dialplan. */
interface DestinoResuelto {
  tipo: 'extension' | 'ivr' | 'anuncio' | 'buzon' | 'colgar';
  extensionNumero?: string;
  ivrId?: string;
  promptAbsoluto?: string;
}

@Injectable()
export class HorariosService {
  constructor(
    @InjectRepository(Horario) private readonly repo: Repository<Horario>,
    @InjectRepository(HorarioFranja) private readonly franjaRepo: Repository<HorarioFranja>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
    @InjectRepository(Extension) private readonly extensionRepo: Repository<Extension>,
    @InjectRepository(Ivr) private readonly ivrRepo: Repository<Ivr>,
    @InjectRepository(AudioPrompt) private readonly promptRepo: Repository<AudioPrompt>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  listar(tenantId: string): Promise<Horario[]> {
    return this.repo.find({ where: { tenantId }, order: { creadoEn: 'DESC' } });
  }

  async obtener(tenantId: string, id: string): Promise<Horario> {
    const horario = await this.repo.findOne({ where: { id, tenantId } });
    if (!horario) throw new NotFoundException('Horario no encontrado');
    return horario;
  }

  async crear(tenantId: string, dto: CrearHorarioDto): Promise<Horario> {
    await this.exigirTenant(tenantId);
    this.validarFranjas(dto.franjas);

    const horario = this.repo.create({
      tenantId,
      nombre: dto.nombre,
      destinoDentroTipo: dto.destinoDentroTipo,
      destinoDentroId: dto.destinoDentroId,
      promptDentroId: dto.promptDentroId,
      destinoFueraTipo: dto.destinoFueraTipo,
      destinoFueraId: dto.destinoFueraId,
      promptFueraId: dto.promptFueraId,
      franjas: dto.franjas.map((f) => this.franjaRepo.create({ ...f })),
    });

    const guardado = await this.repo.save(horario);
    await this.regenerar(guardado.id, tenantId);
    return this.obtener(tenantId, guardado.id);
  }

  async actualizar(tenantId: string, id: string, dto: ActualizarHorarioDto): Promise<Horario> {
    const horario = await this.obtener(tenantId, id);

    if (dto.franjas) {
      this.validarFranjas(dto.franjas);
      // Se reemplaza el juego completo de franjas: con orphanedRowAction
      // 'delete' TypeORM borra las que ya no están.
      horario.franjas = dto.franjas.map((f) => this.franjaRepo.create({ ...f }));
    }
    if (dto.nombre !== undefined) horario.nombre = dto.nombre;
    if (dto.destinoDentroTipo !== undefined) horario.destinoDentroTipo = dto.destinoDentroTipo;
    if (dto.destinoDentroId !== undefined) horario.destinoDentroId = dto.destinoDentroId || undefined;
    if (dto.promptDentroId !== undefined) horario.promptDentroId = dto.promptDentroId || undefined;
    if (dto.destinoFueraTipo !== undefined) horario.destinoFueraTipo = dto.destinoFueraTipo;
    if (dto.destinoFueraId !== undefined) horario.destinoFueraId = dto.destinoFueraId || undefined;
    if (dto.promptFueraId !== undefined) horario.promptFueraId = dto.promptFueraId || undefined;
    if (dto.activo !== undefined) horario.activo = dto.activo;

    await this.repo.save(horario);
    await this.regenerar(id, tenantId);
    return this.obtener(tenantId, id);
  }

  async eliminar(tenantId: string, id: string): Promise<void> {
    const horario = await this.obtener(tenantId, id);
    await this.freeswitch.eliminarHorarioXml(horario.id).catch(() => undefined);
    await this.repo.remove(horario);
  }

  /**
   * Regenera el dialplan de un horario. Se llama al crear y al editar, y
   * también desde fuera cuando cambia algo de lo que depende (una extensión
   * renombrada, una locución sustituida...).
   */
  async regenerar(id: string, tenantId: string): Promise<void> {
    const horario = await this.repo.findOne({ where: { id, tenantId } });
    if (!horario) return;
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) return;

    if (!horario.activo) {
      await this.freeswitch.eliminarHorarioXml(horario.id).catch(() => undefined);
      return;
    }

    const dentro = await this.resolverDestino(
      tenantId,
      tenant.subdominio,
      horario.destinoDentroTipo,
      horario.destinoDentroId,
      horario.promptDentroId,
    );
    const fuera = await this.resolverDestino(
      tenantId,
      tenant.subdominio,
      horario.destinoFueraTipo,
      horario.destinoFueraId,
      horario.promptFueraId,
    );

    await this.freeswitch
      .escribirHorarioXml({
        horarioId: horario.id,
        tenantId,
        subdominioTenant: tenant.subdominio,
        franjas: (horario.franjas ?? []).map((f) => ({
          diaInicio: f.diaInicio,
          diaFin: f.diaFin,
          horaInicio: f.horaInicio,
          horaFin: f.horaFin,
        })),
        dentro,
        fuera,
      })
      .catch(() => undefined);
  }

  /**
   * Traduce un destino guardado (tipo + id) a lo que necesita el dialplan:
   * el número de la extensión, el id del IVR o la ruta absoluta del audio.
   */
  private async resolverDestino(
    tenantId: string,
    subdominio: string,
    tipo: HorarioDestinoTipo,
    destinoId?: string,
    promptId?: string,
  ): Promise<DestinoResuelto> {
    const promptAbsoluto = promptId ? await this.rutaPrompt(tenantId, subdominio, promptId) : undefined;

    switch (tipo) {
      case HorarioDestinoTipo.EXTENSION: {
        const ext = destinoId
          ? await this.extensionRepo.findOne({ where: { id: destinoId, tenantId } })
          : null;
        return { tipo: 'extension', extensionNumero: ext?.numero, promptAbsoluto };
      }
      case HorarioDestinoTipo.IVR: {
        const ivr = destinoId ? await this.ivrRepo.findOne({ where: { id: destinoId, tenantId } }) : null;
        return { tipo: 'ivr', ivrId: ivr?.id, promptAbsoluto };
      }
      case HorarioDestinoTipo.BUZON: {
        // El buzón es el de una extensión concreta: sin extensión no hay
        // dónde dejar el mensaje.
        const ext = destinoId
          ? await this.extensionRepo.findOne({ where: { id: destinoId, tenantId } })
          : null;
        return { tipo: 'buzon', extensionNumero: ext?.numero, promptAbsoluto };
      }
      case HorarioDestinoTipo.ANUNCIO:
        // En un anuncio la locución puede venir en promptId o directamente
        // como destinoId (que es lo natural al elegirla en la pantalla).
        return {
          tipo: 'anuncio',
          promptAbsoluto:
            promptAbsoluto ?? (destinoId ? await this.rutaPrompt(tenantId, subdominio, destinoId) : undefined),
        };
      case HorarioDestinoTipo.COLGAR:
      default:
        return { tipo: 'colgar' };
    }
  }

  private async rutaPrompt(
    tenantId: string,
    subdominio: string,
    promptId: string,
  ): Promise<string | undefined> {
    const prompt = await this.promptRepo.findOne({ where: { id: promptId, tenantId } });
    if (!prompt) return undefined;
    return this.freeswitch.rutaPromptsTenantFreeswitch(subdominio, prompt.archivoRelativo);
  }

  private async exigirTenant(tenantId: string): Promise<Tenant> {
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Cliente no encontrado');
    return tenant;
  }

  /**
   * Comprueba que las franjas tengan sentido. Se avisa aquí, al guardar, en
   * vez de dejar que el usuario descubra por qué no le entran las llamadas.
   */
  private validarFranjas(franjas: FranjaDto[]): void {
    for (const franja of franjas) {
      if (franja.horaInicio === franja.horaFin) {
        throw new BadRequestException(
          `La franja de ${franja.horaInicio} a ${franja.horaFin} no cubre ningún tiempo: la hora de inicio y la de fin son la misma.`,
        );
      }
    }
  }
}
