import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  Matches,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';
import { HorarioDestinoTipo } from '../../common/entities/horario.entity';

/** Una franja del horario: días (1=lunes ... 7=domingo) y horas HH:MM. */
export class FranjaDto {
  @IsInt()
  @Min(1)
  @Max(7)
  diaInicio: number;

  @IsInt()
  @Min(1)
  @Max(7)
  diaFin: number;

  @IsString()
  @Matches(/^([01]\d|2[0-3]):[0-5]\d$/, { message: 'La hora debe tener el formato HH:MM (24 horas)' })
  horaInicio: string;

  @IsString()
  @Matches(/^([01]\d|2[0-3]):[0-5]\d$/, { message: 'La hora debe tener el formato HH:MM (24 horas)' })
  horaFin: string;
}

export class CrearHorarioDto {
  @IsString()
  nombre: string;

  @IsArray()
  @ArrayMinSize(1, { message: 'Hay que definir al menos una franja horaria' })
  @ValidateNested({ each: true })
  @Type(() => FranjaDto)
  franjas: FranjaDto[];

  @IsEnum(HorarioDestinoTipo)
  destinoDentroTipo: HorarioDestinoTipo;

  @IsOptional()
  @IsString()
  destinoDentroId?: string;

  @IsOptional()
  @IsString()
  promptDentroId?: string;

  @IsEnum(HorarioDestinoTipo)
  destinoFueraTipo: HorarioDestinoTipo;

  @IsOptional()
  @IsString()
  destinoFueraId?: string;

  @IsOptional()
  @IsString()
  promptFueraId?: string;
}

/** Edición: todo opcional, se cambia solo lo que llegue. */
export class ActualizarHorarioDto {
  @IsOptional()
  @IsString()
  nombre?: string;

  @IsOptional()
  @IsArray()
  @ArrayMinSize(1, { message: 'Hay que definir al menos una franja horaria' })
  @ValidateNested({ each: true })
  @Type(() => FranjaDto)
  franjas?: FranjaDto[];

  @IsOptional()
  @IsEnum(HorarioDestinoTipo)
  destinoDentroTipo?: HorarioDestinoTipo;

  @IsOptional()
  @IsString()
  destinoDentroId?: string;

  @IsOptional()
  @IsString()
  promptDentroId?: string;

  @IsOptional()
  @IsEnum(HorarioDestinoTipo)
  destinoFueraTipo?: HorarioDestinoTipo;

  @IsOptional()
  @IsString()
  destinoFueraId?: string;

  @IsOptional()
  @IsString()
  promptFueraId?: string;

  @IsOptional()
  @IsBoolean()
  activo?: boolean;
}
