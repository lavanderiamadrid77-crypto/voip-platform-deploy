import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AudioPrompt } from '../common/entities/audio-prompt.entity';
import { Extension } from '../common/entities/extension.entity';
import { Horario } from '../common/entities/horario.entity';
import { HorarioFranja } from '../common/entities/horario-franja.entity';
import { Ivr } from '../common/entities/ivr.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchModule } from '../freeswitch/freeswitch.module';
import { HorariosController } from './horarios.controller';
import { HorariosService } from './horarios.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Horario, HorarioFranja, Tenant, Extension, Ivr, AudioPrompt]),
    FreeswitchModule,
  ],
  controllers: [HorariosController],
  providers: [HorariosService],
  exports: [HorariosService],
})
export class HorariosModule {}
