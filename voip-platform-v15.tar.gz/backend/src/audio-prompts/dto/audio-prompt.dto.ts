import { IsOptional, IsString } from 'class-validator';

export class CrearAudioPromptDto {
  @IsString()
  nombre: string;
}

/** Renombrar una locución ya subida (el audio no cambia). */
export class ActualizarAudioPromptDto {
  @IsOptional()
  @IsString()
  nombre?: string;
}
