import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { spawn } from 'child_process';
import * as fs from 'fs/promises';
import * as os from 'os';
import * as path from 'path';
import { v4 as uuid } from 'uuid';
import { Repository } from 'typeorm';
import { AudioPrompt } from '../common/entities/audio-prompt.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { ActualizarAudioPromptDto } from './dto/audio-prompt.dto';

/**
 * Gestiona las "locuciones": audios grabados desde el navegador (webm/ogg
 * vía MediaRecorder) o subidos como fichero por el cliente. Se
 * transcodifican SIEMPRE a WAV mono 8kHz PCM con ffmpeg (formato que
 * FreeSWITCH reproduce sin necesidad de módulos de códec adicionales) y se
 * guardan en el volumen compartido de prompts, dentro de la carpeta del
 * tenant.
 */
@Injectable()
export class AudioPromptsService {
  private readonly logger = new Logger(AudioPromptsService.name);

  constructor(
    @InjectRepository(AudioPrompt) private readonly repo: Repository<AudioPrompt>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  listarPorTenant(tenantId: string): Promise<AudioPrompt[]> {
    return this.repo.find({ where: { tenantId }, order: { creadoEn: 'DESC' } });
  }

  async subir(tenantId: string, nombre: string, archivo: { buffer: Buffer; originalname?: string }): Promise<AudioPrompt> {
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Cliente no encontrado');
    if (!archivo?.buffer?.length) throw new BadRequestException('No se recibió ningún audio');

    const dirDestino = this.freeswitch.rutaPromptsTenantBackend(tenant.subdominio);
    await fs.mkdir(dirDestino, { recursive: true });

    const nombreArchivo = `${uuid()}.wav`;
    const rutaDestino = path.join(dirDestino, nombreArchivo);
    await this.transcodificarAWav(archivo.buffer, archivo.originalname, rutaDestino);

    const prompt = this.repo.create({
      tenantId,
      nombre,
      archivoRelativo: nombreArchivo,
    });
    return this.repo.save(prompt);
  }

  /** Renombra una locución. El fichero de audio no se toca. */
  async actualizar(
    tenantId: string,
    id: string,
    dto: ActualizarAudioPromptDto,
  ): Promise<AudioPrompt> {
    const prompt = await this.repo.findOne({ where: { id, tenantId } });
    if (!prompt) throw new NotFoundException('Locución no encontrada');
    if (dto.nombre !== undefined) prompt.nombre = dto.nombre;
    return this.repo.save(prompt);
  }

  async eliminar(tenantId: string, id: string): Promise<void> {
    const prompt = await this.repo.findOne({ where: { id, tenantId } });
    if (!prompt) throw new NotFoundException('Locución no encontrada');
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (tenant) {
      const ruta = path.join(this.freeswitch.rutaPromptsTenantBackend(tenant.subdominio), prompt.archivoRelativo);
      await fs.rm(ruta, { force: true });
    }
    await this.repo.remove(prompt);
  }

  /** Ruta absoluta (lado backend) al fichero WAV, para servirlo en el endpoint de reproducción/descarga */
  async rutaArchivo(tenantId: string, id: string): Promise<string> {
    const prompt = await this.repo.findOne({ where: { id, tenantId } });
    if (!prompt) throw new NotFoundException('Locución no encontrada');
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Cliente no encontrado');
    return path.join(this.freeswitch.rutaPromptsTenantBackend(tenant.subdominio), prompt.archivoRelativo);
  }

  private transcodificarAWav(buffer: Buffer, nombreOriginal: string | undefined, rutaDestino: string): Promise<void> {
    return new Promise(async (resolve, reject) => {
      const ext = nombreOriginal ? path.extname(nombreOriginal) : '.webm';
      const rutaTemporal = path.join(os.tmpdir(), `locucion-${uuid()}${ext || '.webm'}`);
      try {
        await fs.writeFile(rutaTemporal, buffer);
      } catch (err) {
        return reject(err);
      }

      const ffmpeg = spawn('ffmpeg', [
        '-y',
        '-i', rutaTemporal,
        '-ar', '8000',
        '-ac', '1',
        '-f', 'wav',
        rutaDestino,
      ]);

      let stderr = '';
      ffmpeg.stderr.on('data', (chunk) => (stderr += chunk.toString()));
      ffmpeg.on('error', (err) => {
        fs.rm(rutaTemporal, { force: true }).catch(() => undefined);
        reject(err);
      });
      ffmpeg.on('close', (codigo) => {
        fs.rm(rutaTemporal, { force: true }).catch(() => undefined);
        if (codigo === 0) {
          resolve();
        } else {
          this.logger.error(`ffmpeg falló (código ${codigo}): ${stderr.slice(-500)}`);
          reject(new BadRequestException('No se pudo procesar el audio (formato no reconocido)'));
        }
      });
    });
  }
}
