import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Tenant } from './tenant.entity';

/**
 * Tarifa de VENTA: lo que le cobramos a un cliente (Tenant) por minuto
 * según el prefijo del número destino. tenantId nulo = tarifa por defecto
 * de la plataforma, aplicada a cualquier tenant sin tarifa propia para ese
 * prefijo (se resuelve primero la específica del tenant, luego la global).
 */
@Entity('sell_rates')
@Index(['tenantId', 'prefijo'], { unique: true })
export class SellRate {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Tenant, { nullable: true, onDelete: 'CASCADE' })
  tenant?: Tenant;

  @Column({ nullable: true })
  tenantId?: string;

  /** Prefijo del número destino, sin "+". Vacío = tarifa por defecto (catch-all) */
  @Column({ default: '' })
  prefijo: string;

  /** Nombre del destino, ej. "España Móvil". Es la columna "Destination" de Kolmisoft. */
  @Column({ nullable: true })
  descripcion?: string;

  @Column('decimal', { precision: 10, scale: 5, default: 0 })
  precioPorMinuto: number;

  /** Importe fijo que se cobra una sola vez al contestar la llamada (Connection Fee). */
  @Column('decimal', { precision: 10, scale: 5, default: 0 })
  tarifaConexion: number;

  /**
   * Incrementos de facturación en segundos, al estilo "60/60" o "1/1" de
   * Kolmisoft: el primero es el mínimo que se cobra al contestar, el segundo
   * es el escalón con el que se redondea a partir de ahí.
   */
  @Column('int', { default: 1 })
  incrementoInicial: number;

  @Column('int', { default: 1 })
  incrementoSiguiente: number;

  @Column({ default: 'EUR' })
  moneda: string;

  /** Desde cuándo aplica esta tarifa (Effective from). Nulo = aplica ya. */
  @Column({ type: 'timestamp', nullable: true })
  vigenteDesde?: Date;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;
}
