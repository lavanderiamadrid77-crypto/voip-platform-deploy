import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Trunk } from './trunk.entity';

/**
 * Tarifa de COMPRA: lo que nos cobra un proveedor (Trunk) por minuto según
 * el prefijo del número destino. Coincidencia por prefijo más largo (LCR
 * clásico): "34" (España) es más genérico que "34911" (Madrid fijo).
 */
@Entity('buy_rates')
@Index(['trunkId', 'prefijo'], { unique: true })
export class BuyRate {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Trunk, { onDelete: 'CASCADE' })
  trunk: Trunk;

  @Column()
  trunkId: string;

  /** Prefijo del número destino, sin "+". Vacío = tarifa por defecto (catch-all) */
  @Column({ default: '' })
  prefijo: string;

  /** Nombre del destino, ej. "España Móvil". Es la columna "Destination" de Kolmisoft. */
  @Column({ nullable: true })
  descripcion?: string;

  @Column('decimal', { precision: 10, scale: 5, default: 0 })
  precioPorMinuto: number;

  /** Coste fijo que se cobra una sola vez al contestar la llamada (Connection Fee). */
  @Column('decimal', { precision: 10, scale: 5, default: 0 })
  tarifaConexion: number;

  /**
   * Incrementos de facturación en segundos, al estilo "60/60" o "1/1" de
   * Kolmisoft: el primero es el mínimo que se cobra al contestar, el segundo
   * es el escalón con el que se redondea a partir de ahí.
   */
  @Column('int', { default: 1 })
  incrementoInicial: number;

  @Column('int', { default: 1 })
  incrementoSiguiente: number;

  @Column({ default: 'EUR' })
  moneda: string;

  /** Desde cuándo aplica esta tarifa (Effective from). Nulo = aplica ya. */
  @Column({ type: 'timestamp', nullable: true })
  vigenteDesde?: Date;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;
}
