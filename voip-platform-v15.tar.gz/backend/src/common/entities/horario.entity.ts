import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { HorarioFranja } from './horario-franja.entity';
import { Tenant } from './tenant.entity';

/**
 * A dónde se manda la llamada. Es el mismo juego de destinos tanto dentro
 * como fuera del horario de oficina.
 */
export enum HorarioDestinoTipo {
  /** Suena una extensión concreta (y si no contestan, cae al buzón). */
  EXTENSION = 'extension',
  /** Entra en un menú de opciones (IVR). */
  IVR = 'ivr',
  /** Se reproduce una locución y se cuelga. Ej: "estamos cerrados". */
  ANUNCIO = 'anuncio',
  /** Locución + buzón de voz para que dejen mensaje. */
  BUZON = 'buzon',
  /** Se cuelga directamente, sin más. */
  COLGAR = 'colgar',
}

/**
 * Horario de oficina de un cliente.
 *
 * Define QUÉ pasa con una llamada según el día y la hora a la que entra:
 * dentro del horario configurado va a un sitio (ej. suena la centralita) y
 * fuera de él a otro (ej. locución de "estamos cerrados" y buzón de voz).
 *
 * Las franjas son varias porque un horario real casi nunca es continuo:
 * lo normal es "lunes a viernes de 9 a 14 y de 16 a 19".
 */
@Entity('horarios')
export class Horario {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' })
  tenant: Tenant;

  @Column()
  tenantId: string;

  @Column()
  nombre: string;

  @OneToMany(() => HorarioFranja, (franja) => franja.horario, {
    cascade: true,
    eager: true,
    orphanedRowAction: 'delete',
  })
  franjas: HorarioFranja[];

  // --- Dentro del horario de oficina ---
  @Column({ type: 'enum', enum: HorarioDestinoTipo, default: HorarioDestinoTipo.EXTENSION })
  destinoDentroTipo: HorarioDestinoTipo;

  /** Id de la extensión, IVR o locución, según el tipo de destino. */
  @Column({ nullable: true })
  destinoDentroId?: string;

  /**
   * Locución opcional que suena ANTES de pasar la llamada al destino de
   * dentro de horario (ej. "bienvenido a la clínica").
   */
  @Column({ nullable: true })
  promptDentroId?: string;

  // --- Fuera del horario de oficina ---
  @Column({ type: 'enum', enum: HorarioDestinoTipo, default: HorarioDestinoTipo.ANUNCIO })
  destinoFueraTipo: HorarioDestinoTipo;

  @Column({ nullable: true })
  destinoFueraId?: string;

  /** Locución que suena fuera de horario (ej. "estamos cerrados"). */
  @Column({ nullable: true })
  promptFueraId?: string;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;
}
