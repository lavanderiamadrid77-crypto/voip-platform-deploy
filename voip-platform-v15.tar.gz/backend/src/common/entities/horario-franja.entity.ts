import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Horario } from './horario.entity';

/**
 * Una franja del horario de oficina: "de lunes a viernes, de 09:00 a 14:00".
 *
 * Los días van en numeración ISO, que es la natural en España:
 *   1 = lunes ... 5 = viernes, 6 = sábado, 7 = domingo.
 *
 * OJO: FreeSWITCH numera los días distinto (1 = domingo), así que la
 * conversión se hace al generar el dialplan, no aquí. Se guarda en el
 * formato que entiende el usuario para que la pantalla sea directa.
 */
@Entity('horario_franjas')
export class HorarioFranja {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Horario, (horario) => horario.franjas, { onDelete: 'CASCADE' })
  horario: Horario;

  @Column()
  horarioId: string;

  /** Día inicial de la franja (1 = lunes ... 7 = domingo) */
  @Column('int', { default: 1 })
  diaInicio: number;

  /** Día final, inclusive. Puede ser menor que diaInicio (ej. sábado a domingo). */
  @Column('int', { default: 5 })
  diaFin: number;

  /** Hora de inicio en formato HH:MM (24h) */
  @Column({ default: '09:00' })
  horaInicio: string;

  /** Hora de fin en formato HH:MM (24h) */
  @Column({ default: '18:00' })
  horaFin: string;
}
