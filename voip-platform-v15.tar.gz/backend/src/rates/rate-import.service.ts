import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as XLSX from 'xlsx';
import { BuyRate } from '../common/entities/buy-rate.entity';
import { SellRate } from '../common/entities/sell-rate.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { Trunk } from '../common/entities/trunk.entity';

/** Campos lógicos a los que se puede mapear una columna del fichero. */
export type CampoTarifa =
  | 'prefijo'
  | 'descripcion'
  | 'precioPorMinuto'
  | 'tarifaConexion'
  | 'incrementos'
  | 'incrementoInicial'
  | 'incrementoSiguiente'
  | 'moneda'
  | 'vigenteDesde';

/** Mapeo columna-del-fichero -> campo lógico. */
export type MapeoColumnas = Record<string, CampoTarifa | 'ignorar'>;

export interface FilaTarifa {
  prefijo: string;
  descripcion?: string;
  precioPorMinuto: number;
  tarifaConexion: number;
  incrementoInicial: number;
  incrementoSiguiente: number;
  moneda: string;
  vigenteDesde?: Date;
}

export interface ErrorFila {
  fila: number;
  motivo: string;
}

export interface ResultadoAnalisis {
  columnasDetectadas: string[];
  mapeoSugerido: MapeoColumnas;
  totalFilas: number;
  validas: number;
  errores: ErrorFila[];
  muestra: FilaTarifa[];
  duplicadosEnFichero: string[];
}

/**
 * Importación masiva de tarifas desde Excel (.xlsx/.xls) o CSV, al estilo del
 * importador de Kolmisoft/MOR: se sube el fichero, se detectan y mapean las
 * columnas, se previsualiza lo que va a entrar (con los errores marcados) y
 * solo entonces se confirma.
 *
 * Está pensado para ficheros de proveedor reales, que suelen venir "sucios":
 * cabeceras en inglés o español, precios con coma decimal, prefijos con "+"
 * o con espacios, incrementos en formato "60/60", filas de totales vacías...
 */
@Injectable()
export class RateImportService {
  constructor(
    @InjectRepository(BuyRate) private readonly buyRepo: Repository<BuyRate>,
    @InjectRepository(SellRate) private readonly sellRepo: Repository<SellRate>,
    @InjectRepository(Trunk) private readonly trunkRepo: Repository<Trunk>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
  ) {}

  // --- Detección de columnas ---------------------------------------------

  /**
   * Sinónimos habituales de cabecera. Se comparan en minúsculas y sin
   * acentos ni signos, para que "Precio/min", "precio por minuto" y
   * "Rate per minute" caigan todos en el mismo campo.
   */
  private static readonly ALIAS: Array<{ campo: CampoTarifa; nombres: string[] }> = [
    {
      campo: 'prefijo',
      nombres: [
        'prefijo', 'prefix', 'code', 'codigo', 'dialcode', 'dial code', 'dialstring',
        'destination code', 'codigo destino', 'area code', 'prefijos', 'cc',
      ],
    },
    {
      campo: 'descripcion',
      nombres: [
        'destino', 'destination', 'descripcion', 'description', 'nombre', 'name',
        'country', 'pais', 'zona', 'zone', 'destination name', 'nombre destino',
      ],
    },
    {
      campo: 'precioPorMinuto',
      nombres: [
        'precio', 'precioporminuto', 'precio por minuto', 'precio/min', 'preciomin',
        'rate', 'price', 'cost', 'coste', 'tarifa', 'rate per minute', 'rateperminute',
        'ppm', 'eur/min', 'usd/min', 'importe', 'valor', 'sell rate', 'buy rate',
      ],
    },
    {
      campo: 'tarifaConexion',
      nombres: [
        'conexion', 'tarifaconexion', 'tarifa conexion', 'connection', 'connection fee',
        'connectionfee', 'setup', 'setup fee', 'cuota conexion', 'fee', 'establecimiento',
      ],
    },
    {
      campo: 'incrementos',
      nombres: [
        'incremento', 'incrementos', 'increment', 'increments', 'billing increment',
        'facturacion', 'billing', 'interval', 'intervalo', 'tarificacion',
      ],
    },
    {
      campo: 'incrementoInicial',
      nombres: ['incremento inicial', 'initial increment', 'first increment', 'minimo', 'minimum'],
    },
    {
      campo: 'incrementoSiguiente',
      nombres: ['incremento siguiente', 'next increment', 'siguiente', 'step'],
    },
    { campo: 'moneda', nombres: ['moneda', 'currency', 'divisa'] },
    {
      campo: 'vigenteDesde',
      nombres: [
        'vigente', 'vigentedesde', 'vigente desde', 'effective', 'effective from',
        'effectivefrom', 'fecha', 'date', 'valid from', 'desde',
      ],
    },
  ];

  private normalizar(texto: string): string {
    return (texto ?? '')
      .toString()
      .trim()
      .toLowerCase()
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '') // quita acentos
      .replace(/[_\-.]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  private sugerirMapeo(columnas: string[]): MapeoColumnas {
    const mapeo: MapeoColumnas = {};
    const yaUsados = new Set<CampoTarifa>();

    for (const columna of columnas) {
      const norm = this.normalizar(columna);
      const sinEspacios = norm.replace(/\s/g, '');
      let encontrado: CampoTarifa | undefined;

      for (const { campo, nombres } of RateImportService.ALIAS) {
        if (yaUsados.has(campo)) continue;
        const coincide = nombres.some((n) => {
          const nn = this.normalizar(n);
          return norm === nn || sinEspacios === nn.replace(/\s/g, '');
        });
        if (coincide) {
          encontrado = campo;
          break;
        }
      }

      // Segunda pasada más permisiva: la cabecera CONTIENE el alias.
      if (!encontrado) {
        for (const { campo, nombres } of RateImportService.ALIAS) {
          if (yaUsados.has(campo)) continue;
          if (nombres.some((n) => norm.includes(this.normalizar(n)))) {
            encontrado = campo;
            break;
          }
        }
      }

      if (encontrado) {
        yaUsados.add(encontrado);
        mapeo[columna] = encontrado;
      } else {
        mapeo[columna] = 'ignorar';
      }
    }
    return mapeo;
  }

  // --- Conversión de valores ---------------------------------------------

  /**
   * Convierte a número admitiendo coma decimal ("0,0123"), separadores de
   * miles ("1.234,56") y símbolos de moneda pegados ("0,05 €").
   */
  private aNumero(valor: unknown): number | undefined {
    if (valor === null || valor === undefined || valor === '') return undefined;
    if (typeof valor === 'number') return Number.isFinite(valor) ? valor : undefined;

    let texto = valor.toString().trim();
    if (!texto) return undefined;
    texto = texto.replace(/[€$£\s]/g, '');

    const tieneComa = texto.includes(',');
    const tienePunto = texto.includes('.');
    if (tieneComa && tienePunto) {
      // El último separador que aparece es el decimal.
      if (texto.lastIndexOf(',') > texto.lastIndexOf('.')) {
        texto = texto.replace(/\./g, '').replace(',', '.');
      } else {
        texto = texto.replace(/,/g, '');
      }
    } else if (tieneComa) {
      texto = texto.replace(',', '.');
    }

    const numero = Number(texto);
    return Number.isFinite(numero) ? numero : undefined;
  }

  /** Limpia un prefijo: quita "+", espacios, guiones y cualquier cosa que no sea dígito. */
  private aPrefijo(valor: unknown): string {
    if (valor === null || valor === undefined) return '';
    return valor.toString().trim().replace(/^\+/, '').replace(/[^0-9]/g, '');
  }

  /** Interpreta "60/60", "60 / 60", "1/1" o un único número ("60" -> 60/60). */
  private aIncrementos(valor: unknown): { inicial: number; siguiente: number } | undefined {
    if (valor === null || valor === undefined || valor === '') return undefined;
    const texto = valor.toString().trim();
    const partes = texto.split(/[/\\|]/).map((p) => p.trim()).filter(Boolean);
    if (partes.length >= 2) {
      const a = this.aNumero(partes[0]);
      const b = this.aNumero(partes[1]);
      if (a && b && a > 0 && b > 0) return { inicial: Math.round(a), siguiente: Math.round(b) };
      return undefined;
    }
    const unico = this.aNumero(texto);
    if (unico && unico > 0) return { inicial: Math.round(unico), siguiente: Math.round(unico) };
    return undefined;
  }

  private aFecha(valor: unknown): Date | undefined {
    if (valor === null || valor === undefined || valor === '') return undefined;
    if (valor instanceof Date) return Number.isNaN(valor.getTime()) ? undefined : valor;
    const texto = valor.toString().trim();
    // Formato español dd/mm/aaaa
    const es = texto.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
    if (es) {
      const fecha = new Date(Number(es[3]), Number(es[2]) - 1, Number(es[1]));
      return Number.isNaN(fecha.getTime()) ? undefined : fecha;
    }
    const fecha = new Date(texto);
    return Number.isNaN(fecha.getTime()) ? undefined : fecha;
  }

  // --- Lectura del fichero -----------------------------------------------

  private leerFilas(buffer: Buffer, nombreArchivo: string): Array<Record<string, unknown>> {
    let libro: XLSX.WorkBook;
    try {
      // `raw: true` es IMPRESCINDIBLE: sin él la librería intenta adivinar el
      // tipo de cada celda y destroza prefijos como "34 6", que interpreta
      // como una fecha y convierte en "6/1/34". Con raw mantenemos el texto
      // original; los .xlsx siguen dando números y fechas nativos.
      libro = XLSX.read(buffer, { type: 'buffer', cellDates: true, raw: true });
    } catch {
      throw new BadRequestException(
        `No se pudo leer el fichero "${nombreArchivo}". Asegúrate de que es un .xlsx, .xls o .csv válido.`,
      );
    }
    const primeraHoja = libro.SheetNames[0];
    if (!primeraHoja) throw new BadRequestException('El fichero no contiene ninguna hoja de datos.');

    const hoja = libro.Sheets[primeraHoja];
    const filas = XLSX.utils.sheet_to_json<Record<string, unknown>>(hoja, {
      defval: '',
      raw: true,
    });
    if (!filas.length) throw new BadRequestException('El fichero está vacío o no tiene cabecera.');
    return filas;
  }

  /**
   * Analiza el fichero: detecta columnas, aplica el mapeo (el sugerido o el
   * que envíe el usuario) y devuelve las filas ya convertidas junto con los
   * errores encontrados, SIN guardar nada.
   */
  analizar(
    buffer: Buffer,
    nombreArchivo: string,
    mapeoManual?: MapeoColumnas,
  ): ResultadoAnalisis & { filas: FilaTarifa[] } {
    const brutas = this.leerFilas(buffer, nombreArchivo);
    const columnas = Object.keys(brutas[0] ?? {});
    const mapeo = mapeoManual && Object.keys(mapeoManual).length ? mapeoManual : this.sugerirMapeo(columnas);

    const campoAColumna = new Map<CampoTarifa, string>();
    for (const [columna, campo] of Object.entries(mapeo)) {
      if (campo && campo !== 'ignorar') campoAColumna.set(campo, columna);
    }

    if (!campoAColumna.has('prefijo')) {
      throw new BadRequestException(
        'No se ha encontrado la columna de PREFIJO. Indícala manualmente en el paso de mapeo de columnas.',
      );
    }
    if (!campoAColumna.has('precioPorMinuto')) {
      throw new BadRequestException(
        'No se ha encontrado la columna de PRECIO por minuto. Indícala manualmente en el paso de mapeo de columnas.',
      );
    }

    const valor = (fila: Record<string, unknown>, campo: CampoTarifa): unknown => {
      const columna = campoAColumna.get(campo);
      return columna === undefined ? undefined : fila[columna];
    };

    const filas: FilaTarifa[] = [];
    const errores: ErrorFila[] = [];
    const vistos = new Map<string, number>();
    const duplicados: string[] = [];

    brutas.forEach((bruta, indice) => {
      // +2: la fila 1 del Excel es la cabecera y el índice empieza en 0.
      const numeroFila = indice + 2;

      const todoVacio = Object.values(bruta).every(
        (v) => v === '' || v === null || v === undefined,
      );
      if (todoVacio) return; // fila en blanco: se ignora sin ruido

      const prefijo = this.aPrefijo(valor(bruta, 'prefijo'));
      const precio = this.aNumero(valor(bruta, 'precioPorMinuto'));

      if (!prefijo) {
        errores.push({ fila: numeroFila, motivo: 'Prefijo vacío o no numérico' });
        return;
      }
      if (precio === undefined) {
        errores.push({ fila: numeroFila, motivo: 'Precio vacío o no numérico' });
        return;
      }
      if (precio < 0) {
        errores.push({ fila: numeroFila, motivo: 'El precio no puede ser negativo' });
        return;
      }

      if (vistos.has(prefijo)) {
        duplicados.push(`${prefijo} (filas ${vistos.get(prefijo)} y ${numeroFila})`);
      } else {
        vistos.set(prefijo, numeroFila);
      }

      let inicial = 1;
      let siguiente = 1;
      const combinado = this.aIncrementos(valor(bruta, 'incrementos'));
      if (combinado) {
        inicial = combinado.inicial;
        siguiente = combinado.siguiente;
      }
      const sueltoInicial = this.aNumero(valor(bruta, 'incrementoInicial'));
      const sueltoSiguiente = this.aNumero(valor(bruta, 'incrementoSiguiente'));
      if (sueltoInicial && sueltoInicial > 0) inicial = Math.round(sueltoInicial);
      if (sueltoSiguiente && sueltoSiguiente > 0) siguiente = Math.round(sueltoSiguiente);

      const descripcionBruta = valor(bruta, 'descripcion');
      const monedaBruta = valor(bruta, 'moneda');

      filas.push({
        prefijo,
        descripcion: descripcionBruta ? descripcionBruta.toString().trim() || undefined : undefined,
        precioPorMinuto: precio,
        tarifaConexion: this.aNumero(valor(bruta, 'tarifaConexion')) ?? 0,
        incrementoInicial: inicial,
        incrementoSiguiente: siguiente,
        moneda: monedaBruta ? monedaBruta.toString().trim().toUpperCase() || 'EUR' : 'EUR',
        vigenteDesde: this.aFecha(valor(bruta, 'vigenteDesde')),
      });
    });

    return {
      columnasDetectadas: columnas,
      mapeoSugerido: mapeo,
      totalFilas: brutas.length,
      validas: filas.length,
      errores: errores.slice(0, 200),
      muestra: filas.slice(0, 20),
      duplicadosEnFichero: duplicados.slice(0, 50),
      filas,
    };
  }

  // --- Guardado ----------------------------------------------------------

  /**
   * Guarda las tarifas de COMPRA de un proveedor. Si `reemplazar` es true se
   * borra primero todo el tarifario de ese proveedor (equivale a sustituir la
   * lista de precios cuando el proveedor manda una nueva).
   */
  async importarCompra(
    trunkId: string,
    filas: FilaTarifa[],
    reemplazar: boolean,
  ): Promise<{ creadas: number; actualizadas: number; eliminadas: number }> {
    const trunk = await this.trunkRepo.findOne({ where: { id: trunkId } });
    if (!trunk) throw new NotFoundException('Proveedor (troncal) no encontrado');

    let eliminadas = 0;
    if (reemplazar) {
      const previas = await this.buyRepo.count({ where: { trunkId } });
      await this.buyRepo.delete({ trunkId });
      eliminadas = previas;
    }

    const existentes = await this.buyRepo.find({ where: { trunkId } });
    const porPrefijo = new Map(existentes.map((t) => [t.prefijo, t]));

    let creadas = 0;
    let actualizadas = 0;
    const aGuardar: BuyRate[] = [];

    for (const fila of filas) {
      const previa = porPrefijo.get(fila.prefijo);
      if (previa) {
        Object.assign(previa, fila, { activo: true });
        aGuardar.push(previa);
        actualizadas++;
      } else {
        const nueva = this.buyRepo.create({ trunkId, ...fila, activo: true });
        aGuardar.push(nueva);
        porPrefijo.set(fila.prefijo, nueva);
        creadas++;
      }
    }

    // Por lotes, para no reventar la memoria ni el límite de parámetros de PG.
    for (let i = 0; i < aGuardar.length; i += 500) {
      await this.buyRepo.save(aGuardar.slice(i, i + 500));
    }
    return { creadas, actualizadas, eliminadas };
  }

  /** Igual que el anterior pero para tarifas de VENTA. tenantId nulo = tarifario global. */
  async importarVenta(
    tenantId: string | undefined,
    filas: FilaTarifa[],
    reemplazar: boolean,
  ): Promise<{ creadas: number; actualizadas: number; eliminadas: number }> {
    if (tenantId) {
      const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
      if (!tenant) throw new NotFoundException('Cliente (tenant) no encontrado');
    }

    const criterio = tenantId ? { tenantId } : {};
    const buscarGlobales = () =>
      this.sellRepo.createQueryBuilder('sr').where('sr.tenantId IS NULL').getMany();

    let eliminadas = 0;
    if (reemplazar) {
      const previas = tenantId ? await this.sellRepo.find({ where: criterio }) : await buscarGlobales();
      eliminadas = previas.length;
      if (previas.length) await this.sellRepo.remove(previas);
    }

    const existentes = tenantId ? await this.sellRepo.find({ where: criterio }) : await buscarGlobales();
    const porPrefijo = new Map(existentes.map((t) => [t.prefijo, t]));

    let creadas = 0;
    let actualizadas = 0;
    const aGuardar: SellRate[] = [];

    for (const fila of filas) {
      const previa = porPrefijo.get(fila.prefijo);
      if (previa) {
        Object.assign(previa, fila, { activo: true });
        aGuardar.push(previa);
        actualizadas++;
      } else {
        const nueva = this.sellRepo.create({ tenantId, ...fila, activo: true });
        aGuardar.push(nueva);
        porPrefijo.set(fila.prefijo, nueva);
        creadas++;
      }
    }

    for (let i = 0; i < aGuardar.length; i += 500) {
      await this.sellRepo.save(aGuardar.slice(i, i + 500));
    }
    return { creadas, actualizadas, eliminadas };
  }

  // --- Exportación / plantilla -------------------------------------------

  /** Genera una plantilla .xlsx de ejemplo para que el cliente sepa qué columnas usar. */
  generarPlantilla(): Buffer {
    const ejemplo = [
      {
        Prefijo: '34',
        Destino: 'España Fijo',
        'Precio por minuto': '0,00850',
        'Tarifa conexion': '0,00000',
        Incrementos: '60/60',
        Moneda: 'EUR',
        'Vigente desde': '',
      },
      {
        Prefijo: '346',
        Destino: 'España Móvil',
        'Precio por minuto': '0,02100',
        'Tarifa conexion': '0,00000',
        Incrementos: '1/1',
        Moneda: 'EUR',
        'Vigente desde': '',
      },
      {
        Prefijo: '3491',
        Destino: 'España Madrid',
        'Precio por minuto': '0,00700',
        'Tarifa conexion': '0,00000',
        Incrementos: '60/60',
        Moneda: 'EUR',
        'Vigente desde': '',
      },
    ];
    const hoja = XLSX.utils.json_to_sheet(ejemplo);
    const libro = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libro, hoja, 'Tarifas');
    return XLSX.write(libro, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
  }

  /** Exporta a Excel el tarifario actual, para revisarlo o reimportarlo modificado. */
  async exportar(tipo: 'compra' | 'venta', id?: string): Promise<Buffer> {
    const tarifas =
      tipo === 'compra'
        ? await this.buyRepo.find({ where: id ? { trunkId: id } : {}, order: { prefijo: 'ASC' } })
        : id
          ? await this.sellRepo.find({ where: { tenantId: id }, order: { prefijo: 'ASC' } })
          : await this.sellRepo
              .createQueryBuilder('sr')
              .where('sr.tenantId IS NULL')
              .orderBy('sr.prefijo', 'ASC')
              .getMany();

    const filas = tarifas.map((t) => ({
      Prefijo: t.prefijo,
      Destino: t.descripcion ?? '',
      'Precio por minuto': Number(t.precioPorMinuto),
      'Tarifa conexion': Number(t.tarifaConexion),
      Incrementos: `${t.incrementoInicial}/${t.incrementoSiguiente}`,
      Moneda: t.moneda,
      'Vigente desde': t.vigenteDesde ? t.vigenteDesde.toISOString().slice(0, 10) : '',
    }));

    const hoja = XLSX.utils.json_to_sheet(filas.length ? filas : [{ Prefijo: '', Destino: '' }]);
    const libro = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libro, hoja, 'Tarifas');
    return XLSX.write(libro, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
  }
}
