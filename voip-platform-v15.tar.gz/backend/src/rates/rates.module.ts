import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BuyRate } from '../common/entities/buy-rate.entity';
import { SellRate } from '../common/entities/sell-rate.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { Trunk } from '../common/entities/trunk.entity';
import { RateImportController } from './rate-import.controller';
import { RateImportService } from './rate-import.service';
import { BuyRatesController, SellRatesController } from './rates.controller';
import { RatesService } from './rates.service';

@Module({
  imports: [TypeOrmModule.forFeature([BuyRate, SellRate, Trunk, Tenant])],
  controllers: [BuyRatesController, SellRatesController, RateImportController],
  providers: [RatesService, RateImportService],
  exports: [RatesService],
})
export class RatesModule {}
