import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Post,
  Query,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiConsumes, ApiTags } from '@nestjs/swagger';
import type { Response } from 'express';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { MapeoColumnas, RateImportService } from './rate-import.service';

/** Límite de tamaño del fichero de tarifas subido (25 MB: sobra para tarifarios de decenas de miles de prefijos). */
const LIMITE_BYTES = 25 * 1024 * 1024;

/**
 * Importación/exportación masiva de tarifas desde Excel o CSV.
 *
 * El flujo es en dos pasos, igual que en Kolmisoft: primero se ANALIZA el
 * fichero (se detectan las columnas y se muestra lo que va a entrar, con los
 * errores marcados) y solo después se CONFIRMA. El fichero se envía en ambos
 * pasos, así el servidor no tiene que guardar estado entre peticiones.
 */
@ApiTags('rates')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('api/tarifas/importar')
export class RateImportController {
  constructor(private readonly service: RateImportService) {}

  private parsearMapeo(mapeoJson?: string): MapeoColumnas | undefined {
    if (!mapeoJson) return undefined;
    try {
      const parseado = JSON.parse(mapeoJson);
      if (parseado && typeof parseado === 'object') return parseado as MapeoColumnas;
      return undefined;
    } catch {
      throw new BadRequestException('El mapeo de columnas enviado no es un JSON válido.');
    }
  }

  private validarArchivo(archivo?: Express.Multer.File): Express.Multer.File {
    if (!archivo) throw new BadRequestException('No se ha recibido ningún fichero.');
    if (archivo.size > LIMITE_BYTES) {
      throw new BadRequestException('El fichero supera el límite de 25 MB.');
    }
    const nombre = (archivo.originalname || '').toLowerCase();
    if (!/\.(xlsx|xls|csv|txt)$/.test(nombre)) {
      throw new BadRequestException(
        'Formato no soportado. Sube un fichero .xlsx, .xls o .csv.',
      );
    }
    return archivo;
  }

  /** Paso 1: analizar y previsualizar sin guardar nada. */
  @Post('analizar')
  @Roles(Rol.SUPER_ADMIN)
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('archivo'))
  analizar(
    @UploadedFile() archivo: Express.Multer.File,
    @Body('mapeo') mapeoJson?: string,
  ) {
    const fichero = this.validarArchivo(archivo);
    const resultado = this.service.analizar(
      fichero.buffer,
      fichero.originalname,
      this.parsearMapeo(mapeoJson),
    );
    // No devolvemos `filas` entero (puede ser enorme); el cliente reenvía el
    // fichero al confirmar y el servidor lo vuelve a procesar.
    const { filas, ...resumen } = resultado;
    void filas;
    return resumen;
  }

  /** Paso 2: confirmar e insertar/actualizar en base de datos. */
  @Post('confirmar')
  @Roles(Rol.SUPER_ADMIN)
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('archivo'))
  async confirmar(
    @UploadedFile() archivo: Express.Multer.File,
    @Body('tipo') tipo: string,
    @Body('trunkId') trunkId?: string,
    @Body('tenantId') tenantId?: string,
    @Body('mapeo') mapeoJson?: string,
    @Body('reemplazar') reemplazar?: string,
  ) {
    const fichero = this.validarArchivo(archivo);
    if (tipo !== 'compra' && tipo !== 'venta') {
      throw new BadRequestException('El tipo debe ser "compra" o "venta".');
    }

    const { filas, errores, duplicadosEnFichero } = this.service.analizar(
      fichero.buffer,
      fichero.originalname,
      this.parsearMapeo(mapeoJson),
    );
    if (!filas.length) {
      throw new BadRequestException(
        'No hay ninguna fila válida que importar. Revisa el mapeo de columnas.',
      );
    }

    const sustituir = reemplazar === 'true' || reemplazar === '1';

    if (tipo === 'compra') {
      if (!trunkId) {
        throw new BadRequestException('Falta indicar el proveedor (trunkId) para tarifas de compra.');
      }
      const resultado = await this.service.importarCompra(trunkId, filas, sustituir);
      return { ...resultado, omitidas: errores.length, duplicadosEnFichero };
    }

    // En venta, tenantId vacío significa tarifario global de la plataforma.
    const resultado = await this.service.importarVenta(tenantId || undefined, filas, sustituir);
    return { ...resultado, omitidas: errores.length, duplicadosEnFichero };
  }

  /** Plantilla .xlsx de ejemplo con las columnas esperadas. */
  @Get('plantilla')
  @Roles(Rol.SUPER_ADMIN)
  plantilla(@Res() res: Response) {
    const buffer = this.service.generarPlantilla();
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    res.setHeader('Content-Disposition', 'attachment; filename="plantilla_tarifas.xlsx"');
    res.send(buffer);
  }

  /** Exporta el tarifario actual a Excel (útil para revisarlo o reimportarlo modificado). */
  @Get('exportar')
  @Roles(Rol.SUPER_ADMIN)
  async exportar(
    @Res() res: Response,
    @Query('tipo') tipo: string,
    @Query('id') id?: string,
  ) {
    if (tipo !== 'compra' && tipo !== 'venta') {
      throw new BadRequestException('El tipo debe ser "compra" o "venta".');
    }
    const buffer = await this.service.exportar(tipo, id || undefined);
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    res.setHeader('Content-Disposition', `attachment; filename="tarifas_${tipo}.xlsx"`);
    res.send(buffer);
  }
}
