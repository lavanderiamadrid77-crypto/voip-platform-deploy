import { IsBoolean, IsInt, IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class CrearBuyRateDto {
  @IsString()
  trunkId: string;

  @IsOptional()
  @IsString()
  prefijo?: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsNumber()
  @Min(0)
  precioPorMinuto: number;
}

export class CrearSellRateDto {
  @IsOptional()
  @IsString()
  tenantId?: string;

  @IsOptional()
  @IsString()
  prefijo?: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsNumber()
  @Min(0)
  precioPorMinuto: number;
}

/** Campos comunes editables de una tarifa (compra o venta). */
class ActualizarTarifaBaseDto {
  @IsOptional()
  @IsString()
  prefijo?: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  precioPorMinuto?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  tarifaConexion?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  incrementoInicial?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  incrementoSiguiente?: number;

  @IsOptional()
  @IsString()
  moneda?: string;

  @IsOptional()
  @IsBoolean()
  activo?: boolean;
}

export class ActualizarBuyRateDto extends ActualizarTarifaBaseDto {}
export class ActualizarSellRateDto extends ActualizarTarifaBaseDto {}
