import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BuyRate } from '../common/entities/buy-rate.entity';
import { SellRate } from '../common/entities/sell-rate.entity';
import { Trunk } from '../common/entities/trunk.entity';
import {
  ActualizarBuyRateDto,
  ActualizarSellRateDto,
  CrearBuyRateDto,
  CrearSellRateDto,
} from './dto/rate.dto';

/**
 * Motor de tarifas mínimo (estilo LCR): cada tarifa tiene un prefijo de
 * número destino ("" = por defecto/catch-all) y un precio por minuto. Al
 * valorar una llamada se busca, entre las tarifas del proveedor/tenant, la
 * que tenga el prefijo MÁS LARGO que sea inicio del número destino (ej.
 * "34911" gana a "34" para un número que empiece por 34911).
 */
@Injectable()
export class RatesService {
  constructor(
    @InjectRepository(BuyRate) private readonly buyRepo: Repository<BuyRate>,
    @InjectRepository(SellRate) private readonly sellRepo: Repository<SellRate>,
    @InjectRepository(Trunk) private readonly trunkRepo: Repository<Trunk>,
  ) {}

  // --- Tarifas de compra (por proveedor/trunk) ---------------------------

  listarCompra(trunkId?: string): Promise<BuyRate[]> {
    return this.buyRepo.find({
      where: trunkId ? { trunkId } : {},
      order: { prefijo: 'ASC' },
    });
  }

  async crearCompra(dto: CrearBuyRateDto): Promise<BuyRate> {
    const trunk = await this.trunkRepo.findOne({ where: { id: dto.trunkId } });
    if (!trunk) throw new NotFoundException('Proveedor (troncal) no encontrado');
    const tarifa = this.buyRepo.create({
      trunkId: dto.trunkId,
      prefijo: dto.prefijo ?? '',
      descripcion: dto.descripcion,
      precioPorMinuto: dto.precioPorMinuto,
    });
    return this.buyRepo.save(tarifa);
  }

  /** Edita una tarifa de compra existente. Solo cambia lo que llegue. */
  async actualizarCompra(id: string, dto: ActualizarBuyRateDto): Promise<BuyRate> {
    const tarifa = await this.buyRepo.findOne({ where: { id } });
    if (!tarifa) throw new NotFoundException('Tarifa de compra no encontrada');
    Object.assign(tarifa, this.soloDefinidos(dto));
    return this.buyRepo.save(tarifa);
  }

  async eliminarCompra(id: string): Promise<void> {
    await this.buyRepo.delete(id);
  }

  // --- Tarifas de venta (por tenant, o global si tenantId es nulo) -------

  listarVenta(tenantId?: string): Promise<SellRate[]> {
    if (tenantId) {
      return this.sellRepo.find({ where: { tenantId }, order: { prefijo: 'ASC' } });
    }
    return this.sellRepo
      .createQueryBuilder('sr')
      .where('sr.tenantId IS NULL')
      .orderBy('sr.prefijo', 'ASC')
      .getMany();
  }

  async crearVenta(dto: CrearSellRateDto): Promise<SellRate> {
    const tarifa = this.sellRepo.create({
      tenantId: dto.tenantId,
      prefijo: dto.prefijo ?? '',
      descripcion: dto.descripcion,
      precioPorMinuto: dto.precioPorMinuto,
    });
    return this.sellRepo.save(tarifa);
  }

  /** Edita una tarifa de venta existente. Solo cambia lo que llegue. */
  async actualizarVenta(id: string, dto: ActualizarSellRateDto): Promise<SellRate> {
    const tarifa = await this.sellRepo.findOne({ where: { id } });
    if (!tarifa) throw new NotFoundException('Tarifa de venta no encontrada');
    Object.assign(tarifa, this.soloDefinidos(dto));
    return this.sellRepo.save(tarifa);
  }

  async eliminarVenta(id: string): Promise<void> {
    await this.sellRepo.delete(id);
  }

  /**
   * Quita las claves `undefined` para que Object.assign no machaque campos
   * existentes con undefined cuando el DTO solo trae unos pocos valores.
   */
  private soloDefinidos<T extends object>(dto: T): Partial<T> {
    const limpio: Record<string, unknown> = {};
    for (const [clave, valor] of Object.entries(dto)) {
      if (valor !== undefined) limpio[clave] = valor;
    }
    return limpio as Partial<T>;
  }

  // --- Valoración de llamadas (usado al cerrar cada CDR) ------------------

  /** Precio por minuto de compra para un trunk (por su NOMBRE, tal como lo reporta FreeSWITCH) y un destino */
  async precioCompraPorMinuto(trunkNombre: string | undefined, destino: string): Promise<number> {
    if (!trunkNombre) return 0;
    const trunk = await this.trunkRepo.findOne({ where: { nombre: trunkNombre } });
    if (!trunk) return 0;
    const tarifas = await this.buyRepo.find({ where: { trunkId: trunk.id, activo: true } });
    return this.mejorCoincidencia(tarifas, destino);
  }

  /** Precio por minuto de venta para un tenant y un destino; si el tenant no tiene tarifa propia, usa la global */
  async precioVentaPorMinuto(tenantId: string | undefined, destino: string): Promise<number> {
    if (!tenantId) return 0;
    const propias = await this.sellRepo.find({ where: { tenantId, activo: true } });
    const propia = this.mejorCoincidencia(propias, destino);
    if (propia > 0) return propia;

    const globales = await this.sellRepo
      .createQueryBuilder('sr')
      .where('sr.tenantId IS NULL')
      .andWhere('sr.activo = true')
      .getMany();
    return this.mejorCoincidencia(globales, destino);
  }

  private mejorCoincidencia(tarifas: Array<{ prefijo: string; precioPorMinuto: number }>, destinoBruto: string): number {
    const tarifa = this.tarifaCoincidente(tarifas as TarifaAplicable[], destinoBruto);
    return tarifa ? Number(tarifa.precioPorMinuto) : 0;
  }

  // --- Importe real de la llamada (incrementos + cuota de conexión) -------

  /** Devuelve la tarifa completa de compra que aplica, no solo el precio. */
  async tarifaCompra(trunkNombre: string | undefined, destino: string): Promise<TarifaAplicable | undefined> {
    if (!trunkNombre) return undefined;
    const trunk = await this.trunkRepo.findOne({ where: { nombre: trunkNombre } });
    if (!trunk) return undefined;
    const tarifas = await this.buyRepo.find({ where: { trunkId: trunk.id, activo: true } });
    return this.tarifaCoincidente(tarifas, destino);
  }

  /** Devuelve la tarifa completa de venta que aplica (propia del tenant o, si no tiene, la global). */
  async tarifaVenta(tenantId: string | undefined, destino: string): Promise<TarifaAplicable | undefined> {
    if (!tenantId) return undefined;
    const propias = await this.sellRepo.find({ where: { tenantId, activo: true } });
    const propia = this.tarifaCoincidente(propias, destino);
    if (propia) return propia;

    const globales = await this.sellRepo
      .createQueryBuilder('sr')
      .where('sr.tenantId IS NULL')
      .andWhere('sr.activo = true')
      .getMany();
    return this.tarifaCoincidente(globales, destino);
  }

  /**
   * Calcula lo que cuesta realmente una llamada aplicando el modelo de
   * Kolmisoft: cuota fija de conexión + minutos facturados según los
   * incrementos. Con incrementos "60/60" una llamada de 10 segundos se cobra
   * como 60; una de 61 segundos, como 120.
   */
  calcularImporte(duracionSegundos: number, tarifa?: TarifaAplicable): number {
    if (!tarifa || duracionSegundos <= 0) return 0;

    const inicial = Math.max(1, Number(tarifa.incrementoInicial) || 1);
    const siguiente = Math.max(1, Number(tarifa.incrementoSiguiente) || 1);

    let segundosFacturados: number;
    if (duracionSegundos <= inicial) {
      segundosFacturados = inicial;
    } else {
      const sobrante = duracionSegundos - inicial;
      segundosFacturados = inicial + Math.ceil(sobrante / siguiente) * siguiente;
    }

    const porMinuto = Number(tarifa.precioPorMinuto) || 0;
    const conexion = Number(tarifa.tarifaConexion) || 0;
    const importe = conexion + (segundosFacturados / 60) * porMinuto;
    // 5 decimales, igual que la precisión con la que guardamos las tarifas.
    return Number(importe.toFixed(5));
  }

  /** Prefijo más largo que case con el destino (LCR clásico). */
  private tarifaCoincidente(tarifas: TarifaAplicable[], destinoBruto: string): TarifaAplicable | undefined {
    const destino = (destinoBruto || '').replace(/^\+/, '');
    const ahora = Date.now();
    let mejor: TarifaAplicable | undefined;
    for (const tarifa of tarifas) {
      // Una tarifa con fecha de vigencia futura todavía no se aplica.
      if (tarifa.vigenteDesde && new Date(tarifa.vigenteDesde).getTime() > ahora) continue;
      if (tarifa.prefijo === '' || destino.startsWith(tarifa.prefijo)) {
        if (!mejor || tarifa.prefijo.length > mejor.prefijo.length) {
          mejor = tarifa;
        }
      }
    }
    return mejor;
  }
}

/** Lo mínimo que necesita el motor para valorar una llamada. */
export interface TarifaAplicable {
  prefijo: string;
  precioPorMinuto: number;
  tarifaConexion?: number;
  incrementoInicial?: number;
  incrementoSiguiente?: number;
  vigenteDesde?: Date;
}
