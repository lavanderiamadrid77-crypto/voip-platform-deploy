import { IsBoolean, IsEnum, IsOptional, IsString } from 'class-validator';
import { DidDestinoTipo } from '../../common/entities/did.entity';

export class CrearDidDto {
  @IsString()
  numero: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsOptional()
  @IsString()
  trunkProveedorId?: string;
}

export class AsignarDidDto {
  @IsOptional()
  @IsString()
  tenantId?: string;
}

export class ConfigurarDestinoDidDto {
  @IsEnum(DidDestinoTipo)
  destinoTipo: DidDestinoTipo;

  @IsOptional()
  @IsString()
  destinoId?: string;
}

/** Edición de los datos del número (no de su destino). */
export class ActualizarDidDto {
  @IsOptional()
  @IsString()
  numero?: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsOptional()
  @IsString()
  trunkProveedorId?: string;

  @IsOptional()
  @IsBoolean()
  activo?: boolean;
}
