import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Did, DidDestinoTipo } from '../common/entities/did.entity';
import { Extension } from '../common/entities/extension.entity';
import { Horario } from '../common/entities/horario.entity';
import { Ivr } from '../common/entities/ivr.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { Trunk } from '../common/entities/trunk.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import {
  ActualizarDidDto,
  AsignarDidDto,
  ConfigurarDestinoDidDto,
  CrearDidDto,
} from './dto/did.dto';

@Injectable()
export class DidsService {
  constructor(
    @InjectRepository(Did) private readonly repo: Repository<Did>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
    @InjectRepository(Extension) private readonly extensionRepo: Repository<Extension>,
    @InjectRepository(Ivr) private readonly ivrRepo: Repository<Ivr>,
    @InjectRepository(Horario) private readonly horarioRepo: Repository<Horario>,
    @InjectRepository(Trunk) private readonly trunkRepo: Repository<Trunk>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  listarTodos(tenantId?: string): Promise<Did[]> {
    return this.repo.find({
      where: tenantId ? { tenantId } : {},
      order: { creadoEn: 'DESC' },
    });
  }

  listarPorTenant(tenantId: string): Promise<Did[]> {
    return this.repo.find({ where: { tenantId }, order: { numero: 'ASC' } });
  }

  async crear(dto: CrearDidDto): Promise<Did> {
    const existe = await this.repo.findOne({ where: { numero: dto.numero } });
    if (existe) throw new ConflictException('Ese número SIP ya existe');
    const did = this.repo.create({
      numero: dto.numero,
      descripcion: dto.descripcion,
      trunkProveedorId: dto.trunkProveedorId,
      destinoTipo: DidDestinoTipo.NINGUNO,
    });
    return this.repo.save(did);
  }

  /** Asigna (o libera, con tenantId=undefined) un número a un cliente. Al reasignar se limpia el destino previo. */
  async asignar(id: string, dto: AsignarDidDto): Promise<Did> {
    const did = await this.obtener(id);
    if (did.tenantId !== dto.tenantId) {
      await this.freeswitch.eliminarDidXml(did.numero).catch(() => undefined);
      did.destinoTipo = DidDestinoTipo.NINGUNO;
      did.destinoId = undefined;
    }
    did.tenantId = dto.tenantId;
    return this.repo.save(did);
  }

  /** Configura a dónde suena un número SIP ya asignado a un tenant (extensión o IVR) */
  async configurarDestino(tenantId: string, id: string, dto: ConfigurarDestinoDidDto): Promise<Did> {
    const did = await this.obtener(id);
    if (did.tenantId !== tenantId) {
      throw new BadRequestException('Ese número SIP no pertenece a este cliente');
    }
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Cliente no encontrado');

    const trunkProveedor = did.trunkProveedorId
      ? await this.trunkRepo.findOne({ where: { id: did.trunkProveedorId } })
      : undefined;

    did.destinoTipo = dto.destinoTipo;
    did.destinoId = dto.destinoId;

    if (dto.destinoTipo === DidDestinoTipo.NINGUNO || !dto.destinoId) {
      did.destinoTipo = DidDestinoTipo.NINGUNO;
      did.destinoId = undefined;
      await this.freeswitch.eliminarDidXml(did.numero).catch(() => undefined);
      return this.repo.save(did);
    }

    if (dto.destinoTipo === DidDestinoTipo.HORARIO) {
      const horario = await this.horarioRepo.findOne({ where: { id: dto.destinoId, tenantId } });
      if (!horario) throw new BadRequestException('Ese horario no pertenece a este cliente');
      await this.freeswitch.escribirDidXml({
        numero: did.numero,
        tenantId,
        subdominioTenant: tenant.subdominio,
        destinoTipo: 'horario',
        destinoHorarioId: horario.id,
        trunkProveedorNombre: trunkProveedor?.nombre,
      });
    } else if (dto.destinoTipo === DidDestinoTipo.EXTENSION) {
      const ext = await this.extensionRepo.findOne({ where: { id: dto.destinoId, tenantId } });
      if (!ext) throw new BadRequestException('Esa extensión no pertenece a este cliente');
      await this.freeswitch.escribirDidXml({
        numero: did.numero,
        tenantId,
        subdominioTenant: tenant.subdominio,
        destinoTipo: 'extension',
        destinoExtensionNumero: ext.numero,
        trunkProveedorNombre: trunkProveedor?.nombre,
      });
    } else if (dto.destinoTipo === DidDestinoTipo.IVR) {
      const ivr = await this.ivrRepo.findOne({ where: { id: dto.destinoId, tenantId } });
      if (!ivr) throw new BadRequestException('Ese IVR no pertenece a este cliente');
      await this.freeswitch.escribirDidXml({
        numero: did.numero,
        tenantId,
        subdominioTenant: tenant.subdominio,
        destinoTipo: 'ivr',
        destinoIvrId: ivr.id,
        trunkProveedorNombre: trunkProveedor?.nombre,
      });
    }

    return this.repo.save(did);
  }

  /**
   * Edita los datos del número en sí (no su destino): el número marcado, la
   * descripción o el proveedor por el que entra.
   *
   * Si cambia el número hay que reescribir su dialplan, porque el fichero y
   * la condición de destination_number van por número: si no, las llamadas
   * seguirían entrando por el viejo y el nuevo no sonaría en ningún sitio.
   */
  async actualizar(id: string, dto: ActualizarDidDto): Promise<Did> {
    const did = await this.obtener(id);
    const numeroAnterior = did.numero;

    if (dto.numero !== undefined && dto.numero !== did.numero) {
      const existe = await this.repo.findOne({ where: { numero: dto.numero } });
      if (existe) throw new ConflictException('Ese número SIP ya existe');
      did.numero = dto.numero;
    }
    if (dto.descripcion !== undefined) did.descripcion = dto.descripcion || undefined;
    if (dto.trunkProveedorId !== undefined) did.trunkProveedorId = dto.trunkProveedorId || undefined;
    if (dto.activo !== undefined) did.activo = dto.activo;

    const guardado = await this.repo.save(did);

    if (numeroAnterior !== guardado.numero) {
      await this.freeswitch.eliminarDidXml(numeroAnterior).catch(() => undefined);
    }

    // Se reescribe el dialplan con el destino que ya tuviera configurado.
    if (guardado.tenantId && guardado.destinoTipo !== DidDestinoTipo.NINGUNO && guardado.destinoId) {
      await this.configurarDestino(guardado.tenantId, guardado.id, {
        destinoTipo: guardado.destinoTipo,
        destinoId: guardado.destinoId,
      }).catch(() => undefined);
    }

    return this.obtener(guardado.id);
  }

  async eliminar(id: string): Promise<void> {
    const did = await this.obtener(id);
    await this.freeswitch.eliminarDidXml(did.numero).catch(() => undefined);
    await this.repo.remove(did);
  }

  private async obtener(id: string): Promise<Did> {
    const did = await this.repo.findOne({ where: { id } });
    if (!did) throw new NotFoundException('Número SIP no encontrado');
    return did;
  }
}
