import { useRef, useState } from 'react';
import { API_URL, api } from '../api/client';
import { AnalisisImportacion, CampoTarifa, ResultadoImportacion } from '../api/tipos';

/** Etiquetas legibles para cada campo al que se puede mapear una columna. */
const CAMPOS: Array<{ valor: CampoTarifa; etiqueta: string }> = [
  { valor: 'prefijo', etiqueta: 'Prefijo (obligatorio)' },
  { valor: 'descripcion', etiqueta: 'Destino / descripción' },
  { valor: 'precioPorMinuto', etiqueta: 'Precio por minuto (obligatorio)' },
  { valor: 'tarifaConexion', etiqueta: 'Tarifa de conexión' },
  { valor: 'incrementos', etiqueta: 'Incrementos (ej. 60/60)' },
  { valor: 'incrementoInicial', etiqueta: 'Incremento inicial (segundos)' },
  { valor: 'incrementoSiguiente', etiqueta: 'Incremento siguiente (segundos)' },
  { valor: 'moneda', etiqueta: 'Moneda' },
  { valor: 'vigenteDesde', etiqueta: 'Vigente desde (fecha)' },
  { valor: 'ignorar', etiqueta: '— No importar esta columna —' },
];

/**
 * Asistente de importación masiva de tarifas desde Excel o CSV.
 *
 * Funciona en dos pasos, como el importador de Kolmisoft: primero se analiza
 * el fichero y se muestra qué se ha detectado (columnas, filas válidas,
 * errores y duplicados) y solo cuando el usuario da el visto bueno se
 * escriben las tarifas. El fichero se reenvía en el segundo paso para que el
 * servidor no tenga que guardar nada entre medias.
 */
export function ImportadorTarifas({
  tipo,
  destinoId,
  nombreDestino,
  onImportado,
}: {
  tipo: 'compra' | 'venta';
  /** trunkId si es compra, tenantId si es venta (vacío = tarifario global). */
  destinoId: string;
  nombreDestino: string;
  onImportado: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [archivo, setArchivo] = useState<File | null>(null);
  const [analisis, setAnalisis] = useState<AnalisisImportacion | null>(null);
  const [mapeo, setMapeo] = useState<Record<string, CampoTarifa>>({});
  const [reemplazar, setReemplazar] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultado, setResultado] = useState<ResultadoImportacion | null>(null);
  const [arrastrando, setArrastrando] = useState(false);

  function reiniciar() {
    setArchivo(null);
    setAnalisis(null);
    setMapeo({});
    setError(null);
    setResultado(null);
    setReemplazar(false);
    if (inputRef.current) inputRef.current.value = '';
  }

  async function analizar(fichero: File, mapeoManual?: Record<string, CampoTarifa>) {
    setCargando(true);
    setError(null);
    setResultado(null);
    try {
      const form = new FormData();
      form.append('archivo', fichero);
      if (mapeoManual) form.append('mapeo', JSON.stringify(mapeoManual));
      const res = await api.postForm<AnalisisImportacion>('/api/tarifas/importar/analizar', form);
      setAnalisis(res);
      setMapeo(mapeoManual ?? res.mapeoSugerido);
      setArchivo(fichero);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo analizar el fichero');
      setAnalisis(null);
    } finally {
      setCargando(false);
    }
  }

  async function confirmar() {
    if (!archivo) return;
    setCargando(true);
    setError(null);
    try {
      const form = new FormData();
      form.append('archivo', archivo);
      form.append('tipo', tipo);
      form.append('mapeo', JSON.stringify(mapeo));
      form.append('reemplazar', reemplazar ? 'true' : 'false');
      if (tipo === 'compra') form.append('trunkId', destinoId);
      else form.append('tenantId', destinoId);

      const res = await api.postForm<ResultadoImportacion>('/api/tarifas/importar/confirmar', form);
      setResultado(res);
      setAnalisis(null);
      setArchivo(null);
      if (inputRef.current) inputRef.current.value = '';
      onImportado();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo importar el fichero');
    } finally {
      setCargando(false);
    }
  }

  async function descargar(ruta: string, nombre: string) {
    try {
      const url = await api.getBlobUrl(ruta);
      const a = document.createElement('a');
      a.href = url;
      a.download = nombre;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      setError('No se pudo descargar el fichero');
    }
  }

  const faltaDestino = tipo === 'compra' && !destinoId;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex flex-col gap-4">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h3 className="font-semibold">Importar tarifas desde Excel o CSV</h3>
          <p className="text-sm text-slate-500 mt-1 max-w-xl">
            Sube el fichero de precios tal cual te lo manda el proveedor. Se detectan las columnas
            automáticamente y verás una previsualización antes de guardar nada.
          </p>
        </div>
        <div className="flex gap-3 text-sm">
          <button
            type="button"
            className="text-marca hover:underline"
            onClick={() => descargar('/api/tarifas/importar/plantilla', 'plantilla_tarifas.xlsx')}
          >
            Descargar plantilla
          </button>
          <button
            type="button"
            className="text-marca hover:underline"
            onClick={() =>
              descargar(
                `/api/tarifas/importar/exportar?tipo=${tipo}&id=${encodeURIComponent(destinoId)}`,
                `tarifas_${tipo}.xlsx`,
              )
            }
          >
            Exportar las actuales
          </button>
        </div>
      </div>

      {faltaDestino && (
        <p className="text-sm text-amber-700 bg-amber-50 dark:bg-amber-950 dark:text-amber-300 rounded-md px-3 py-2">
          Elige primero un proveedor para poder importar sus tarifas.
        </p>
      )}

      {/* Paso 1: elegir fichero */}
      {!analisis && !resultado && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setArrastrando(true);
          }}
          onDragLeave={() => setArrastrando(false)}
          onDrop={(e) => {
            e.preventDefault();
            setArrastrando(false);
            if (faltaDestino) return;
            const f = e.dataTransfer.files?.[0];
            if (f) analizar(f);
          }}
          className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
            arrastrando
              ? 'border-marca bg-marca/5'
              : 'border-slate-300 dark:border-slate-600'
          } ${faltaDestino ? 'opacity-50 pointer-events-none' : ''}`}
        >
          <p className="text-sm text-slate-500">
            Arrastra aquí el fichero .xlsx, .xls o .csv
          </p>
          <p className="text-xs text-slate-400 my-2">o</p>
          <input
            ref={inputRef}
            type="file"
            accept=".xlsx,.xls,.csv,.txt"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) analizar(f);
            }}
          />
          <button
            type="button"
            className="bg-marca text-white rounded-md px-4 py-2 text-sm"
            onClick={() => inputRef.current?.click()}
            disabled={cargando}
          >
            {cargando ? 'Analizando…' : 'Elegir fichero'}
          </button>
        </div>
      )}

      {error && (
        <p className="text-sm text-red-600 bg-red-50 dark:bg-red-950 rounded-md px-3 py-2">{error}</p>
      )}

      {/* Resultado final */}
      {resultado && (
        <div className="text-sm bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-md px-4 py-3">
          <p className="font-medium">Importación completada</p>
          <ul className="mt-1 space-y-0.5">
            <li>Tarifas nuevas creadas: {resultado.creadas}</li>
            <li>Tarifas actualizadas: {resultado.actualizadas}</li>
            {resultado.eliminadas > 0 && <li>Tarifas anteriores eliminadas: {resultado.eliminadas}</li>}
            {resultado.omitidas > 0 && <li>Filas omitidas por errores: {resultado.omitidas}</li>}
          </ul>
          <button type="button" className="mt-2 text-marca hover:underline" onClick={reiniciar}>
            Importar otro fichero
          </button>
        </div>
      )}

      {/* Paso 2: mapeo + previsualización */}
      {analisis && (
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap gap-4 text-sm">
            <span className="rounded-md bg-slate-100 dark:bg-slate-700 px-3 py-1">
              Filas leídas: <strong>{analisis.totalFilas}</strong>
            </span>
            <span className="rounded-md bg-emerald-100 dark:bg-emerald-900 px-3 py-1">
              Válidas: <strong>{analisis.validas}</strong>
            </span>
            {analisis.errores.length > 0 && (
              <span className="rounded-md bg-red-100 dark:bg-red-900 px-3 py-1">
                Con error: <strong>{analisis.errores.length}</strong>
              </span>
            )}
          </div>

          <div>
            <h4 className="text-sm font-medium mb-2">
              Comprueba a qué corresponde cada columna del fichero
            </h4>
            <div className="grid gap-2 sm:grid-cols-2">
              {analisis.columnasDetectadas.map((columna) => (
                <label key={columna} className="text-sm flex items-center gap-2">
                  <span className="font-mono text-xs bg-slate-100 dark:bg-slate-700 rounded px-2 py-1 truncate max-w-[45%]">
                    {columna}
                  </span>
                  <span className="text-slate-400">→</span>
                  <select
                    className="flex-1 rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                    value={mapeo[columna] ?? 'ignorar'}
                    onChange={(e) =>
                      setMapeo({ ...mapeo, [columna]: e.target.value as CampoTarifa })
                    }
                  >
                    {CAMPOS.map((c) => (
                      <option key={c.valor} value={c.valor}>
                        {c.etiqueta}
                      </option>
                    ))}
                  </select>
                </label>
              ))}
            </div>
            <button
              type="button"
              className="mt-2 text-sm text-marca hover:underline"
              onClick={() => archivo && analizar(archivo, mapeo)}
              disabled={cargando}
            >
              Volver a analizar con este mapeo
            </button>
          </div>

          {analisis.muestra.length > 0 && (
            <div>
              <h4 className="text-sm font-medium mb-2">
                Previsualización (primeras {analisis.muestra.length} filas)
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-100 dark:bg-slate-700 text-left">
                    <tr>
                      <th className="p-2">Prefijo</th>
                      <th className="p-2">Destino</th>
                      <th className="p-2">Precio/min</th>
                      <th className="p-2">Conexión</th>
                      <th className="p-2">Incrementos</th>
                      <th className="p-2">Moneda</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analisis.muestra.map((f, i) => (
                      <tr key={i} className="border-t border-slate-100 dark:border-slate-700">
                        <td className="p-2 font-mono">{f.prefijo}</td>
                        <td className="p-2">{f.descripcion ?? '—'}</td>
                        <td className="p-2">{Number(f.precioPorMinuto).toFixed(5)}</td>
                        <td className="p-2">{Number(f.tarifaConexion).toFixed(5)}</td>
                        <td className="p-2">
                          {f.incrementoInicial}/{f.incrementoSiguiente}
                        </td>
                        <td className="p-2">{f.moneda}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {analisis.errores.length > 0 && (
            <details className="text-sm">
              <summary className="cursor-pointer text-red-600">
                Ver las {analisis.errores.length} filas que se van a omitir
              </summary>
              <ul className="mt-2 space-y-1 max-h-40 overflow-y-auto">
                {analisis.errores.map((e, i) => (
                  <li key={i} className="text-slate-600 dark:text-slate-400">
                    Fila {e.fila}: {e.motivo}
                  </li>
                ))}
              </ul>
            </details>
          )}

          {analisis.duplicadosEnFichero.length > 0 && (
            <details className="text-sm">
              <summary className="cursor-pointer text-amber-600">
                Hay prefijos repetidos dentro del fichero ({analisis.duplicadosEnFichero.length})
              </summary>
              <p className="text-xs text-slate-500 mt-1">
                Si un prefijo aparece varias veces, se guardará el valor de la última fila.
              </p>
              <ul className="mt-2 space-y-1 max-h-40 overflow-y-auto">
                {analisis.duplicadosEnFichero.map((d, i) => (
                  <li key={i} className="text-slate-600 dark:text-slate-400 font-mono text-xs">
                    {d}
                  </li>
                ))}
              </ul>
            </details>
          )}

          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              className="mt-1"
              checked={reemplazar}
              onChange={(e) => setReemplazar(e.target.checked)}
            />
            <span>
              <strong>Sustituir el tarifario completo</strong> de {nombreDestino}. Se borrarán antes
              todas sus tarifas actuales. Déjalo sin marcar para solo añadir y actualizar las del
              fichero.
            </span>
          </label>

          <div className="flex gap-3">
            <button
              type="button"
              className="bg-marca text-white rounded-md px-4 py-2 text-sm disabled:opacity-50"
              onClick={confirmar}
              disabled={cargando || analisis.validas === 0}
            >
              {cargando ? 'Importando…' : `Importar ${analisis.validas} tarifas`}
            </button>
            <button
              type="button"
              className="text-sm text-slate-500 hover:underline"
              onClick={reiniciar}
              disabled={cargando}
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Pista de depuración para el administrador: a qué API está apuntando el panel. */}
      <p className="sr-only">{API_URL}</p>
    </div>
  );
}
