export type Rol = 'super_admin' | 'admin' | 'reseller' | 'usuario';

export interface UsuarioSesion {
  id: string;
  email: string;
  rol: Rol;
  tenantId?: string;
  idiomaPreferido: string;
}

export interface Tenant {
  id: string;
  nombre: string;
  subdominio: string;
  colorPrimario: string;
  canalesMax: number;
  extensionesMax: number;
  retencionGrabacionesDias: number;
  activo: boolean;
  creadoEn: string;
}

export type TipoExtension =
  | 'escritorio'
  | 'softphone'
  | 'movil'
  | 'ring_group'
  | 'cola'
  | 'ivr'
  | 'buzon'
  | 'conferencia';

export interface Extension {
  id: string;
  tenantId: string;
  numero: string;
  nombre: string;
  tipo: TipoExtension;
  codecs: string;
  webrtcHabilitado: boolean;
  activo: boolean;
  creadoEn: string;
}

export interface Trunk {
  id: string;
  tenantId?: string;
  nombre: string;
  proveedor: string;
  host: string;
  puerto: number;
  usuario?: string;
  prioridad: number;
  costoPorMinuto: number;
  activo: boolean;
  creadoEn: string;
}

export interface Cdr {
  id: string;
  tenantId: string;
  origen: string;
  destino: string;
  fechaHoraInicio: string;
  duracionSegundos: number;
  estado: string;
  costo: number;
  venta?: number;
  trunkUsado?: string;
  direccion?: 'entrante' | 'saliente' | 'interna';
}

export type DidDestinoTipo = 'extension' | 'ivr' | 'horario' | 'ninguno';

export interface Did {
  id: string;
  numero: string;
  descripcion?: string;
  tenantId?: string;
  trunkProveedorId?: string;
  destinoTipo: DidDestinoTipo;
  destinoId?: string;
  activo: boolean;
  creadoEn: string;
}

export interface AudioPrompt {
  id: string;
  tenantId: string;
  nombre: string;
  archivoRelativo: string;
  duracionSegundos?: number;
  creadoEn: string;
}

export type IvrOpcionDestinoTipo = 'extension' | 'ivr';

export interface IvrOption {
  id: string;
  ivrId: string;
  digito: string;
  destinoTipo: IvrOpcionDestinoTipo;
  destinoId: string;
  etiqueta?: string;
}

export interface Ivr {
  id: string;
  tenantId: string;
  nombre: string;
  promptBienvenidaId?: string;
  timeoutSegundos: number;
  opciones: IvrOption[];
  activo: boolean;
  creadoEn: string;
}

export interface BuyRate {
  id: string;
  trunkId: string;
  prefijo: string;
  descripcion?: string;
  precioPorMinuto: number;
  tarifaConexion: number;
  incrementoInicial: number;
  incrementoSiguiente: number;
  moneda: string;
  vigenteDesde?: string;
  activo: boolean;
  creadoEn: string;
}

export interface SellRate {
  id: string;
  tenantId?: string;
  prefijo: string;
  descripcion?: string;
  precioPorMinuto: number;
  tarifaConexion: number;
  incrementoInicial: number;
  incrementoSiguiente: number;
  moneda: string;
  vigenteDesde?: string;
  activo: boolean;
  creadoEn: string;
}

/** Campos lógicos a los que se puede mapear una columna del fichero importado. */
export type CampoTarifa =
  | 'prefijo'
  | 'descripcion'
  | 'precioPorMinuto'
  | 'tarifaConexion'
  | 'incrementos'
  | 'incrementoInicial'
  | 'incrementoSiguiente'
  | 'moneda'
  | 'vigenteDesde'
  | 'ignorar';

export interface FilaTarifaImportada {
  prefijo: string;
  descripcion?: string;
  precioPorMinuto: number;
  tarifaConexion: number;
  incrementoInicial: number;
  incrementoSiguiente: number;
  moneda: string;
  vigenteDesde?: string;
}

export interface AnalisisImportacion {
  columnasDetectadas: string[];
  mapeoSugerido: Record<string, CampoTarifa>;
  totalFilas: number;
  validas: number;
  errores: Array<{ fila: number; motivo: string }>;
  muestra: FilaTarifaImportada[];
  duplicadosEnFichero: string[];
}

export interface ResultadoImportacion {
  creadas: number;
  actualizadas: number;
  eliminadas: number;
  omitidas: number;
  duplicadosEnFichero: string[];
}

// --- Horarios de oficina -------------------------------------------------

export type HorarioDestinoTipo = 'extension' | 'ivr' | 'anuncio' | 'buzon' | 'colgar';

/** Una franja: días 1=lunes ... 7=domingo, horas en HH:MM. */
export interface HorarioFranja {
  id?: string;
  diaInicio: number;
  diaFin: number;
  horaInicio: string;
  horaFin: string;
}

export interface Horario {
  id: string;
  tenantId: string;
  nombre: string;
  franjas: HorarioFranja[];
  destinoDentroTipo: HorarioDestinoTipo;
  destinoDentroId?: string;
  promptDentroId?: string;
  destinoFueraTipo: HorarioDestinoTipo;
  destinoFueraId?: string;
  promptFueraId?: string;
  activo: boolean;
  creadoEn: string;
}
