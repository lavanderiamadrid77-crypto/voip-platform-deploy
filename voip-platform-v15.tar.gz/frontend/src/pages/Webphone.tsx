import { useEffect, useMemo, useRef, useState } from 'react';
import * as JsSIP from 'jssip';
import { api } from '../api/client';
import { useI18n } from '../i18n';

/**
 * Softphone WebRTC embebido, para probar llamadas desde el navegador sin
 * necesitar un teléfono IP. Se conecta por WSS al perfil "internal" de
 * FreeSWITCH (puerto 7443).
 *
 * Los datos ya no se teclean a mano: se eligen el cliente y la extensión de
 * unas listas, y el dominio SIP se compone igual que lo hace el backend
 * (<subdominio>.<dominio base>). Antes había que adivinarlo y bastaba una
 * letra de diferencia para que el registro fallara sin decir por qué.
 */

type Tenant = { id: string; nombre: string; subdominio: string };
type Extension = { id: string; numero: string; nombre: string };

const DOMINIO_BASE = import.meta.env.VITE_SIP_DOMAIN ?? 'plataforma.local';

export function Webphone() {
  const { t } = useI18n();
  const [wsUrl, setWsUrl] = useState(
    import.meta.env.VITE_FREESWITCH_WSS_URL ?? 'wss://localhost:7443',
  );
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [tenantId, setTenantId] = useState('');
  const [extensiones, setExtensiones] = useState<Extension[]>([]);
  const [extension, setExtension] = useState('');
  const [password, setPassword] = useState('');
  const [destino, setDestino] = useState('');
  const [estado, setEstado] = useState<
    'desconectado' | 'conectando' | 'registrado' | 'en_llamada'
  >('desconectado');
  const [avisoCertificado, setAvisoCertificado] = useState(false);
  const [log, setLog] = useState<string[]>([]);

  const uaRef = useRef<JsSIP.UA | null>(null);
  const sesionRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  const tenant = tenants.find((tn) => tn.id === tenantId);
  const dominio = tenant ? `${tenant.subdominio}.${DOMINIO_BASE}` : '';

  // El certificado del WSS es autofirmado, así que el navegador rechaza la
  // conexión en silencio hasta que se visita esa URL una vez y se acepta.
  // Es, con diferencia, el motivo más habitual de "el teléfono web no va".
  const urlCertificado = useMemo(() => wsUrl.replace(/^wss:/i, 'https:'), [wsUrl]);

  function agregarLog(linea: string) {
    const hora = new Date().toLocaleTimeString();
    setLog((prev) => [...prev.slice(-40), `${hora}  ${linea}`]);
  }

  useEffect(() => {
    api
      .get<Tenant[]>('/api/tenants')
      .then((lista) => {
        setTenants(lista);
        if (lista.length && !tenantId) setTenantId(lista[0].id);
      })
      .catch((e: Error) => agregarLog(`No se pudo cargar la lista de clientes: ${e.message}`));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!tenantId) return;
    api
      .get<Extension[]>(`/api/tenants/${tenantId}/extensions`)
      .then((lista) => {
        setExtensiones(lista);
        setExtension(lista[0]?.numero ?? '');
        setDestino(lista[1]?.numero ?? '');
      })
      .catch(() => setExtensiones([]));
  }, [tenantId]);

  function registrar() {
    if (!dominio || !extension) {
      agregarLog('Elige primero un cliente y una extensión.');
      return;
    }
    uaRef.current?.stop();
    setAvisoCertificado(false);
    setEstado('conectando');
    agregarLog(`Conectando a ${wsUrl} como ${extension}@${dominio}`);

    const socket = new JsSIP.WebSocketInterface(wsUrl);
    const ua = new JsSIP.UA({
      sockets: [socket],
      uri: `sip:${extension}@${dominio}`,
      password,
      register: true,
      // FreeSWITCH no necesita los session timers para estas llamadas y, si
      // el navegador y la centralita no se ponen de acuerdo en el intervalo,
      // la llamada se cae sola a los pocos minutos.
      session_timers: false,
    });

    ua.on('connected', () => agregarLog('WebSocket abierto'));
    ua.on('registered', () => {
      setEstado('registrado');
      agregarLog('Registrado correctamente en la centralita');
    });
    ua.on('registrationFailed', (e: any) => {
      setEstado('desconectado');
      agregarLog(`Fallo de registro: ${e?.cause ?? 'desconocido'} (revisa la contraseña SIP)`);
    });
    ua.on('disconnected', (e: any) => {
      setEstado('desconectado');
      // Un cierre sin haber llegado a registrarse casi siempre significa que
      // el navegador ha rechazado el certificado autofirmado.
      if (!e?.socket?.via_transport || e?.error) {
        setAvisoCertificado(true);
        agregarLog('No se pudo abrir el WebSocket seguro. Ver el aviso del certificado.');
      } else {
        agregarLog('Desconectado del servidor WSS');
      }
    });

    ua.on('newRTCSession', (data: any) => {
      const session = data.session;
      sesionRef.current = session;
      if (session.direction === 'incoming') agregarLog('Llamada entrante');
      session.on('accepted', () => setEstado('en_llamada'));
      session.on('ended', () => {
        setEstado('registrado');
        agregarLog('Llamada finalizada');
      });
      session.on('failed', (e: any) => {
        setEstado('registrado');
        agregarLog(`Llamada fallida: ${e?.cause ?? 'desconocido'}`);
      });
      session.connection?.addEventListener('track', (event: RTCTrackEvent) => {
        if (audioRef.current) audioRef.current.srcObject = event.streams[0];
      });
    });

    ua.start();
    uaRef.current = ua;
  }

  function llamar() {
    if (!uaRef.current || !destino) return;
    const session = uaRef.current.call(`sip:${destino}@${dominio}`, {
      mediaConstraints: { audio: true, video: false },
      pcConfig: { iceServers: [{ urls: ['stun:stun.l.google.com:19302'] }] },
    });
    sesionRef.current = session;
    agregarLog(`Llamando a ${destino}...`);
  }

  function colgar() {
    sesionRef.current?.terminate();
  }

  useEffect(() => () => uaRef.current?.stop(), []);

  return (
    <div className="flex flex-col gap-6 max-w-2xl">
      <h1 className="text-2xl font-semibold">{t('webphone')}</h1>

      <div className="rounded-xl border border-amber-300 bg-amber-50 dark:bg-amber-900/20 p-4 text-sm">
        <p className="font-medium mb-1">Antes de la primera llamada</p>
        <p>
          La centralita usa un certificado propio (autofirmado). El navegador lo rechaza sin avisar
          hasta que lo aceptas una vez:{' '}
          <a
            href={urlCertificado}
            target="_blank"
            rel="noreferrer"
            className="text-marca underline font-medium"
          >
            abre {urlCertificado}
          </a>{' '}
          y pulsa «Avanzado» → «Continuar». Hay que hacerlo una sola vez en cada navegador y
          ordenador.
        </p>
      </div>

      {avisoCertificado && (
        <div className="rounded-xl border border-red-300 bg-red-50 dark:bg-red-900/20 p-4 text-sm">
          El navegador ha cerrado la conexión segura sin llegar a hablar con la centralita. Casi
          siempre es el certificado: abre <span className="font-mono">{urlCertificado}</span>,
          acéptalo y vuelve a pulsar Registrar.
        </div>
      )}

      <p className="text-sm text-slate-500">
        Estado: <span className="font-medium">{estado}</span>
        {dominio && (
          <>
            {' · '}Dominio SIP: <span className="font-mono">{dominio}</span>
          </>
        )}
      </p>

      <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex flex-col gap-3">
        <Campo etiqueta="URL WSS de la centralita" valor={wsUrl} onChange={setWsUrl} />

        <label className="flex flex-col text-sm gap-1">
          Cliente
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={tenantId}
            onChange={(e) => setTenantId(e.target.value)}
          >
            {tenants.length === 0 && <option value="">(no hay clientes creados)</option>}
            {tenants.map((tn) => (
              <option key={tn.id} value={tn.id}>
                {tn.nombre} ({tn.subdominio})
              </option>
            ))}
          </select>
        </label>

        <label className="flex flex-col text-sm gap-1">
          Extensión con la que registrarse
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={extension}
            onChange={(e) => setExtension(e.target.value)}
          >
            {extensiones.length === 0 && <option value="">(este cliente no tiene extensiones)</option>}
            {extensiones.map((ex) => (
              <option key={ex.id} value={ex.numero}>
                {ex.numero} — {ex.nombre}
              </option>
            ))}
          </select>
        </label>

        <Campo
          etiqueta="Contraseña SIP de esa extensión"
          valor={password}
          onChange={setPassword}
          tipo="password"
        />
        <p className="text-xs text-slate-500 -mt-2">
          Es la que se muestra al crear la extensión, en la pantalla de Extensiones.
        </p>

        <button onClick={registrar} className="bg-marca text-white rounded-md px-4 py-2 w-fit">
          Registrar
        </button>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex flex-col gap-3">
        <Campo etiqueta="Número destino" valor={destino} onChange={setDestino} />
        <div className="flex gap-2">
          <button
            onClick={llamar}
            disabled={estado !== 'registrado'}
            className="bg-green-600 text-white rounded-md px-4 py-2 disabled:opacity-50"
          >
            Llamar
          </button>
          <button
            onClick={colgar}
            disabled={estado !== 'en_llamada'}
            className="bg-red-600 text-white rounded-md px-4 py-2 disabled:opacity-50"
          >
            Colgar
          </button>
        </div>
      </div>

      <audio ref={audioRef} autoPlay />

      <div className="bg-slate-900 text-slate-100 rounded-xl p-4 text-xs font-mono h-48 overflow-y-auto">
        {log.length === 0 && <div className="text-slate-400">Sin actividad todavía.</div>}
        {log.map((l, i) => (
          <div key={i}>{l}</div>
        ))}
      </div>
    </div>
  );
}

function Campo({
  etiqueta,
  valor,
  onChange,
  tipo = 'text',
}: {
  etiqueta: string;
  valor: string;
  onChange: (v: string) => void;
  tipo?: string;
}) {
  return (
    <label className="flex flex-col text-sm gap-1">
      {etiqueta}
      <input
        type={tipo}
        className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
        value={valor}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}
