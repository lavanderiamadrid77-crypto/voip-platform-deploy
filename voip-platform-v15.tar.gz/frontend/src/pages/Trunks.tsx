import { FormEvent, useEffect, useState } from 'react';
import { api } from '../api/client';
import { Trunk } from '../api/tipos';
import { useI18n } from '../i18n';

export function Trunks() {
  const { t } = useI18n();
  const [trunks, setTrunks] = useState<Trunk[]>([]);
  const [nombre, setNombre] = useState('');
  const [proveedor, setProveedor] = useState('');
  const [host, setHost] = useState('');
  const [puerto, setPuerto] = useState(5060);
  const [usuario, setUsuario] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function cargar() {
    setTrunks(await api.get<Trunk[]>('/api/trunks'));
  }

  useEffect(() => {
    cargar().catch((e) => setError(e.message));
  }, []);

  async function crear(e: FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api.post('/api/trunks', { nombre, proveedor, host, puerto, usuario, password });
      setNombre('');
      setProveedor('');
      setHost('');
      setUsuario('');
      setPassword('');
      await cargar();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creando el troncal');
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/trunks/${id}`);
    await cargar();
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">{t('trunks')}</h1>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">{t('trunks_subtitulo')}</p>
      </div>

      <form onSubmit={crear} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex gap-3 items-end flex-wrap">
        <Campo etiqueta="Nombre" valor={nombre} onChange={setNombre} />
        <Campo etiqueta="Proveedor" valor={proveedor} onChange={setProveedor} />
        <Campo etiqueta="Host" valor={host} onChange={setHost} />
        <label className="flex flex-col text-sm gap-1">
          Puerto
          <input
            type="number"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 w-24"
            value={puerto}
            onChange={(e) => setPuerto(Number(e.target.value))}
          />
        </label>
        <Campo etiqueta="Usuario" valor={usuario} onChange={setUsuario} opcional />
        <label className="flex flex-col text-sm gap-1">
          Password
          <input
            type="password"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <button className="bg-marca text-white rounded-md px-4 py-2 h-fit">{t('nuevo_trunk')}</button>
      </form>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Nombre</th>
            <th className="p-2">Proveedor</th>
            <th className="p-2">Host</th>
            <th className="p-2">Puerto</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody>
          {trunks.map((tk) => (
            <FilaTrunk
              key={tk.id}
              trunk={tk}
              onEliminar={eliminar}
              onGuardado={() => cargar().catch((e) => setError(e.message))}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Campo({
  etiqueta,
  valor,
  onChange,
  opcional,
}: {
  etiqueta: string;
  valor: string;
  onChange: (v: string) => void;
  opcional?: boolean;
}) {
  return (
    <label className="flex flex-col text-sm gap-1">
      {etiqueta}
      <input
        required={!opcional}
        className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
        value={valor}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

/**
 * Fila de un proveedor, con edición en línea. Se edita en la propia tabla
 * para no perder de vista el resto de proveedores mientras se toca uno.
 *
 * La contraseña se deja en blanco a propósito: no se puede recuperar la que
 * hay guardada, y enviarla vacía significa "no la cambies".
 */
function FilaTrunk({
  trunk,
  onEliminar,
  onGuardado,
}: {
  trunk: Trunk;
  onEliminar: (id: string) => void;
  onGuardado: () => void;
}) {
  const [editando, setEditando] = useState(false);
  const [nombre, setNombre] = useState(trunk.nombre);
  const [proveedor, setProveedor] = useState(trunk.proveedor);
  const [host, setHost] = useState(trunk.host);
  const [puerto, setPuerto] = useState(trunk.puerto);
  const [usuario, setUsuario] = useState(trunk.usuario ?? '');
  const [password, setPassword] = useState('');
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function cancelar() {
    setNombre(trunk.nombre);
    setProveedor(trunk.proveedor);
    setHost(trunk.host);
    setPuerto(trunk.puerto);
    setUsuario(trunk.usuario ?? '');
    setPassword('');
    setError(null);
    setEditando(false);
  }

  async function guardar() {
    setGuardando(true);
    setError(null);
    try {
      await api.patch(`/api/trunks/${trunk.id}`, {
        nombre,
        proveedor,
        host,
        puerto: Number(puerto),
        usuario: usuario || undefined,
        password: password || undefined,
      });
      setEditando(false);
      setPassword('');
      onGuardado();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo guardar');
    } finally {
      setGuardando(false);
    }
  }

  const inputClase =
    'rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1 w-full';

  if (!editando) {
    return (
      <tr className="border-t border-slate-100 dark:border-slate-700">
        <td className="p-2">{trunk.nombre}</td>
        <td className="p-2">{trunk.proveedor}</td>
        <td className="p-2">{trunk.host}</td>
        <td className="p-2">{trunk.puerto}</td>
        <td className="p-2">
          <div className="flex gap-3">
            <button className="text-marca hover:underline" onClick={() => setEditando(true)}>
              Editar
            </button>
            <button className="text-red-600 hover:underline" onClick={() => onEliminar(trunk.id)}>
              Eliminar
            </button>
          </div>
        </td>
      </tr>
    );
  }

  return (
    <tr className="border-t border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900">
      <td className="p-2">
        <input className={inputClase} value={nombre} onChange={(e) => setNombre(e.target.value)} />
      </td>
      <td className="p-2">
        <input className={inputClase} value={proveedor} onChange={(e) => setProveedor(e.target.value)} />
      </td>
      <td className="p-2">
        <input className={inputClase} value={host} onChange={(e) => setHost(e.target.value)} />
        <input
          className={`${inputClase} mt-1`}
          placeholder="Usuario SIP"
          value={usuario}
          onChange={(e) => setUsuario(e.target.value)}
        />
        <input
          className={`${inputClase} mt-1`}
          type="password"
          placeholder="Contraseña (vacío = no cambiar)"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <p className="text-red-600 text-xs mt-1">{error}</p>}
      </td>
      <td className="p-2">
        <input
          className={inputClase}
          type="number"
          value={puerto}
          onChange={(e) => setPuerto(Number(e.target.value))}
        />
      </td>
      <td className="p-2">
        <div className="flex gap-3">
          <button
            className="text-marca hover:underline disabled:opacity-50"
            onClick={guardar}
            disabled={guardando}
          >
            {guardando ? 'Guardando…' : 'Guardar'}
          </button>
          <button className="text-slate-500 hover:underline" onClick={cancelar}>
            Cancelar
          </button>
        </div>
      </td>
    </tr>
  );
}
