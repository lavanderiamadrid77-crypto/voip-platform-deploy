import { FormEvent, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api/client';
import { Did, DidDestinoTipo, Extension, Horario, Ivr, Tenant, Trunk } from '../api/tipos';

/**
 * Números SIP (DIDs): el "pool" de números de teléfono de la plataforma.
 * Un número se da de alta suelto (opcionalmente con el proveedor por el que
 * se espera que llegue, para poder calcular su tarifa de compra), luego se
 * asigna a un cliente, y por último se configura a dónde debe sonar cuando
 * llega una llamada (una extensión concreta o un IVR).
 */
export function Dids() {
  const [params] = useSearchParams();
  const tenantIdFiltroInicial = params.get('tenantId') ?? '';

  const [dids, setDids] = useState<Did[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [trunks, setTrunks] = useState<Trunk[]>([]);
  const [extensionesPorTenant, setExtensionesPorTenant] = useState<Record<string, Extension[]>>({});
  const [ivrsPorTenant, setIvrsPorTenant] = useState<Record<string, Ivr[]>>({});
  const [horariosPorTenant, setHorariosPorTenant] = useState<Record<string, Horario[]>>({});

  const [filtroTenant, setFiltroTenant] = useState(tenantIdFiltroInicial);
  const [numero, setNumero] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [trunkProveedorId, setTrunkProveedorId] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [guardando, setGuardando] = useState(false);

  async function cargarBase() {
    const [ds, ts, tk] = await Promise.all([
      api.get<Did[]>('/api/dids'),
      api.get<Tenant[]>('/api/tenants'),
      api.get<Trunk[]>('/api/trunks'),
    ]);
    setDids(ds);
    setTenants(ts);
    setTrunks(tk);
  }

  useEffect(() => {
    cargarBase().catch((e) => setError(e.message));
  }, []);

  async function asegurarDestinosTenant(tenantId: string) {
    if (!tenantId || extensionesPorTenant[tenantId]) return;
    const [exts, ivrs, horarios] = await Promise.all([
      api.get<Extension[]>(`/api/tenants/${tenantId}/extensions`).catch(() => []),
      api.get<Ivr[]>(`/api/tenants/${tenantId}/ivrs`).catch(() => []),
      api.get<Horario[]>(`/api/tenants/${tenantId}/horarios`).catch(() => []),
    ]);
    setExtensionesPorTenant((prev) => ({ ...prev, [tenantId]: exts }));
    setIvrsPorTenant((prev) => ({ ...prev, [tenantId]: ivrs }));
    setHorariosPorTenant((prev) => ({ ...prev, [tenantId]: horarios }));
  }

  useEffect(() => {
    // Precarga extensiones/IVRs de los clientes que ya tienen números asignados,
    // para poder mostrar el selector de destino sin esperas.
    const tenantIds = new Set(dids.map((d) => d.tenantId).filter(Boolean) as string[]);
    tenantIds.forEach((id) => asegurarDestinosTenant(id).catch(() => undefined));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dids]);

  async function crear(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setGuardando(true);
    try {
      await api.post('/api/dids', {
        numero,
        descripcion: descripcion || undefined,
        trunkProveedorId: trunkProveedorId || undefined,
      });
      setNumero('');
      setDescripcion('');
      setTrunkProveedorId('');
      await cargarBase();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creando el número SIP');
    } finally {
      setGuardando(false);
    }
  }

  async function asignar(did: Did, tenantId: string) {
    setError(null);
    try {
      await api.patch(`/api/dids/${did.id}/asignar`, { tenantId: tenantId || undefined });
      if (tenantId) await asegurarDestinosTenant(tenantId);
      await cargarBase();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error asignando el número');
    }
  }

  async function configurarDestino(did: Did, destinoTipo: DidDestinoTipo, destinoId: string) {
    if (!did.tenantId) return;
    setError(null);
    try {
      await api.patch(`/api/tenants/${did.tenantId}/dids/${did.id}/destino`, {
        destinoTipo,
        destinoId: destinoTipo === 'ninguno' ? undefined : destinoId,
      });
      await cargarBase();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error configurando el destino');
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/dids/${id}`);
    await cargarBase();
  }

  const didsVisibles = filtroTenant ? dids.filter((d) => d.tenantId === filtroTenant) : dids;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">Números SIP</h1>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">
          Da de alta los números que llegan de tus proveedores, asígnalos a un cliente y configura a qué extensión o
          IVR deben sonar. Un número sin cliente asignado se queda "en el pool" y las llamadas entrantes se rechazan.
        </p>
      </div>

      <form onSubmit={crear} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex gap-3 items-end flex-wrap">
        <label className="flex flex-col text-sm gap-1">
          Número
          <input
            required
            placeholder="34911234567"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={numero}
            onChange={(e) => setNumero(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          Descripción
          <input
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={descripcion}
            onChange={(e) => setDescripcion(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          Proveedor de origen
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={trunkProveedorId}
            onChange={(e) => setTrunkProveedorId(e.target.value)}
          >
            <option value="">(sin especificar)</option>
            {trunks.map((tk) => (
              <option key={tk.id} value={tk.id}>
                {tk.nombre}
              </option>
            ))}
          </select>
        </label>
        <button disabled={guardando} className="bg-marca text-white rounded-md px-4 py-2 h-fit">
          Añadir número
        </button>
      </form>

      <label className="text-sm flex flex-col gap-1 max-w-xs">
        Filtrar por cliente
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
          value={filtroTenant}
          onChange={(e) => setFiltroTenant(e.target.value)}
        >
          <option value="">Todos (incluye números sin asignar)</option>
          {tenants.map((tn) => (
            <option key={tn.id} value={tn.id}>
              {tn.nombre}
            </option>
          ))}
        </select>
      </label>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Número</th>
            <th className="p-2">Descripción</th>
            <th className="p-2">Cliente</th>
            <th className="p-2">Destino de la llamada entrante</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody>
          {didsVisibles.map((did) => (
            <FilaDid
              key={did.id}
              did={did}
              tenants={tenants}
              extensiones={did.tenantId ? extensionesPorTenant[did.tenantId] ?? [] : []}
              ivrs={did.tenantId ? ivrsPorTenant[did.tenantId] ?? [] : []}
              horarios={did.tenantId ? horariosPorTenant[did.tenantId] ?? [] : []}
              onAsignar={asignar}
              onConfigurarDestino={configurarDestino}
              onEliminar={eliminar}
            />
          ))}
          {didsVisibles.length === 0 && (
            <tr>
              <td colSpan={5} className="p-4 text-center text-slate-500">
                No hay números SIP {filtroTenant ? 'para este cliente' : 'todavía'}.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

function FilaDid({
  did,
  tenants,
  extensiones,
  ivrs,
  horarios,
  onAsignar,
  onConfigurarDestino,
  onEliminar,
}: {
  did: Did;
  tenants: Tenant[];
  extensiones: Extension[];
  ivrs: Ivr[];
  horarios: Horario[];
  onAsignar: (did: Did, tenantId: string) => void;
  onConfigurarDestino: (did: Did, destinoTipo: DidDestinoTipo, destinoId: string) => void;
  onEliminar: (id: string) => void;
}) {
  const [destinoTipo, setDestinoTipo] = useState<DidDestinoTipo>(did.destinoTipo);
  const [destinoId, setDestinoId] = useState(did.destinoId ?? '');

  useEffect(() => {
    setDestinoTipo(did.destinoTipo);
    setDestinoId(did.destinoId ?? '');
  }, [did.destinoTipo, did.destinoId]);

  return (
    <tr className="border-t border-slate-100 dark:border-slate-700 align-top">
      <td className="p-2 font-mono">{did.numero}</td>
      <td className="p-2">{did.descripcion ?? '—'}</td>
      <td className="p-2">
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
          value={did.tenantId ?? ''}
          onChange={(e) => onAsignar(did, e.target.value)}
        >
          <option value="">(sin asignar / pool)</option>
          {tenants.map((tn) => (
            <option key={tn.id} value={tn.id}>
              {tn.nombre}
            </option>
          ))}
        </select>
      </td>
      <td className="p-2">
        {!did.tenantId ? (
          <span className="text-slate-400">Asigna primero un cliente</span>
        ) : (
          <div className="flex gap-2 flex-wrap items-center">
            <select
              className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
              value={destinoTipo}
              onChange={(e) => {
                const nuevo = e.target.value as DidDestinoTipo;
                setDestinoTipo(nuevo);
                setDestinoId('');
                if (nuevo === 'ninguno') onConfigurarDestino(did, 'ninguno', '');
              }}
            >
              <option value="ninguno">Sin configurar</option>
              <option value="extension">Extensión</option>
              <option value="ivr">IVR / respuesta automática</option>
            </select>
            {destinoTipo === 'extension' && (
              <select
                className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                value={destinoId}
                onChange={(e) => {
                  setDestinoId(e.target.value);
                  onConfigurarDestino(did, 'extension', e.target.value);
                }}
              >
                <option value="">Elegir extensión…</option>
                {extensiones.map((ext) => (
                  <option key={ext.id} value={ext.id}>
                    {ext.numero} — {ext.nombre}
                  </option>
                ))}
              </select>
            )}
            {destinoTipo === 'horario' && (
              <select
                className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                value={destinoId}
                onChange={(e) => {
                  setDestinoId(e.target.value);
                  onConfigurarDestino(did, 'horario', e.target.value);
                }}
              >
                <option value="">Elegir horario…</option>
                {horarios.map((h) => (
                  <option key={h.id} value={h.id}>
                    {h.nombre}
                  </option>
                ))}
              </select>
            )}
            {destinoTipo === 'ivr' && (
              <select
                className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                value={destinoId}
                onChange={(e) => {
                  setDestinoId(e.target.value);
                  onConfigurarDestino(did, 'ivr', e.target.value);
                }}
              >
                <option value="">Elegir IVR…</option>
                {ivrs.map((ivr) => (
                  <option key={ivr.id} value={ivr.id}>
                    {ivr.nombre}
                  </option>
                ))}
              </select>
            )}
          </div>
        )}
      </td>
      <td className="p-2">
        <button className="text-red-600 hover:underline" onClick={() => onEliminar(did.id)}>
          Eliminar
        </button>
      </td>
    </tr>
  );
}
