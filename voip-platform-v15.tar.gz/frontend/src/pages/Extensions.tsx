import { FormEvent, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api } from '../api/client';
import { Extension, Tenant, TipoExtension } from '../api/tipos';
import { useI18n } from '../i18n';

const tipos: TipoExtension[] = [
  'softphone',
  'escritorio',
  'movil',
  'ring_group',
  'cola',
  'ivr',
  'buzon',
  'conferencia',
];

export function Extensions() {
  const { t } = useI18n();
  const [params] = useSearchParams();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [tenantId, setTenantId] = useState('');
  const [extensiones, setExtensiones] = useState<Extension[]>([]);
  const [numero, setNumero] = useState('');
  const [nombre, setNombre] = useState('');
  const [tipo, setTipo] = useState<TipoExtension>('softphone');
  const [passwordGenerada, setPasswordGenerada] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.get<Tenant[]>('/api/tenants').then((t) => {
      setTenants(t);
      const inicial = params.get('tenantId');
      if (inicial && t.some((tn) => tn.id === inicial)) setTenantId(inicial);
      else if (t[0]) setTenantId(t[0].id);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function cargarExtensiones(id: string) {
    if (!id) return;
    setExtensiones(await api.get<Extension[]>(`/api/tenants/${id}/extensions`));
  }

  useEffect(() => {
    cargarExtensiones(tenantId).catch((e) => setError(e.message));
  }, [tenantId]);

  async function crear(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setPasswordGenerada(null);
    try {
      const resp = await api.post<{ extension: Extension; passwordSip: string }>(
        `/api/tenants/${tenantId}/extensions`,
        { numero, nombre, tipo },
      );
      setPasswordGenerada(resp.passwordSip);
      setNumero('');
      setNombre('');
      await cargarExtensiones(tenantId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creando la extensión');
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/tenants/${tenantId}/extensions/${id}`);
    await cargarExtensiones(tenantId);
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">{t('extensiones')}</h1>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">
          Cada extensión es un teléfono (físico, softphone o app móvil) dentro de la centralita del cliente. Para que
          suene al recibir una llamada externa, asigna un número SIP a esta extensión en "Números SIP".
        </p>
      </div>

      <label className="text-sm flex flex-col gap-1 max-w-xs">
        Cliente
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
          value={tenantId}
          onChange={(e) => setTenantId(e.target.value)}
        >
          {tenants.map((tn) => (
            <option key={tn.id} value={tn.id}>
              {tn.nombre}
            </option>
          ))}
        </select>
      </label>

      {tenantId && (
        <div className="flex gap-4 text-sm">
          <Link className="text-marca hover:underline" to={`/dids?tenantId=${tenantId}`}>
            → Asignar números SIP a las extensiones de este cliente
          </Link>
          <Link className="text-marca hover:underline" to={`/ivr?tenantId=${tenantId}`}>
            → Configurar IVR / locuciones
          </Link>
        </div>
      )}

      <form onSubmit={crear} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex gap-3 items-end flex-wrap">
        <label className="flex flex-col text-sm gap-1">
          Número
          <input
            required
            pattern="[0-9]{3,6}"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 w-28"
            value={numero}
            onChange={(e) => setNumero(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          Nombre
          <input
            required
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          Tipo
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={tipo}
            onChange={(e) => setTipo(e.target.value as TipoExtension)}
          >
            {tipos.map((tp) => (
              <option key={tp} value={tp}>
                {tp}
              </option>
            ))}
          </select>
        </label>
        <button disabled={!tenantId} className="bg-marca text-white rounded-md px-4 py-2 h-fit">
          {t('nueva_extension')}
        </button>
      </form>

      {error && <p className="text-red-600 text-sm">{error}</p>}
      {passwordGenerada && (
        <div className="text-sm bg-amber-50 dark:bg-amber-950 border border-amber-300 dark:border-amber-700 rounded-md px-3 py-2">
          Contraseña SIP generada (guárdala, no se volverá a mostrar):{' '}
          <code className="font-mono font-semibold">{passwordGenerada}</code>
        </div>
      )}

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Número</th>
            <th className="p-2">Nombre</th>
            <th className="p-2">Tipo</th>
            <th className="p-2">WebRTC</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody>
          {extensiones.map((ext) => (
            <FilaExtension
              key={ext.id}
              extension={ext}
              tenantId={tenantId}
              onEliminar={eliminar}
              onGuardado={(nuevaPassword) => {
                if (nuevaPassword) setPasswordGenerada(nuevaPassword);
                cargarExtensiones(tenantId).catch((e) => setError(e.message));
              }}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Fila de extensión con edición en línea: número, nombre y tipo.
 *
 * La contraseña SIP no se puede consultar (se guarda cifrada), así que en
 * vez de mostrarla se ofrece regenerarla. Al hacerlo hay que reconfigurar
 * el teléfono, por eso se avisa antes.
 */
function FilaExtension({
  extension,
  tenantId,
  onEliminar,
  onGuardado,
}: {
  extension: Extension;
  tenantId: string;
  onEliminar: (id: string) => void;
  onGuardado: (nuevaPassword?: string) => void;
}) {
  const [editando, setEditando] = useState(false);
  const [numero, setNumero] = useState(extension.numero);
  const [nombre, setNombre] = useState(extension.nombre);
  const [tipo, setTipo] = useState<TipoExtension>(extension.tipo);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function guardar(regenerarPassword = false) {
    setGuardando(true);
    setError(null);
    try {
      const resp = await api.patch<{ extension: Extension; passwordSip?: string }>(
        `/api/tenants/${tenantId}/extensions/${extension.id}`,
        { numero, nombre, tipo, regenerarPassword },
      );
      setEditando(false);
      onGuardado(resp?.passwordSip);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo guardar');
    } finally {
      setGuardando(false);
    }
  }

  const clase = 'rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1 w-full';

  if (!editando) {
    return (
      <tr className="border-t border-slate-100 dark:border-slate-700">
        <td className="p-2">{extension.numero}</td>
        <td className="p-2">{extension.nombre}</td>
        <td className="p-2">{extension.tipo}</td>
        <td className="p-2">{extension.webrtcHabilitado ? 'Sí' : 'No'}</td>
        <td className="p-2">
          <div className="flex gap-3">
            <button className="text-marca hover:underline" onClick={() => setEditando(true)}>
              Editar
            </button>
            <button className="text-red-600 hover:underline" onClick={() => onEliminar(extension.id)}>
              Eliminar
            </button>
          </div>
        </td>
      </tr>
    );
  }

  return (
    <tr className="border-t border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900">
      <td className="p-2">
        <input className={clase} value={numero} onChange={(e) => setNumero(e.target.value)} />
      </td>
      <td className="p-2">
        <input className={clase} value={nombre} onChange={(e) => setNombre(e.target.value)} />
        {error && <p className="text-red-600 text-xs mt-1">{error}</p>}
      </td>
      <td className="p-2">
        <select className={clase} value={tipo} onChange={(e) => setTipo(e.target.value as TipoExtension)}>
          {tipos.map((tp) => (
            <option key={tp} value={tp}>
              {tp}
            </option>
          ))}
        </select>
      </td>
      <td className="p-2 text-xs text-slate-500">
        <button
          type="button"
          className="text-amber-600 hover:underline"
          onClick={() => {
            if (
              confirm(
                'Se generará una contraseña SIP nueva. El teléfono dejará de registrarse hasta que lo reconfigures con la nueva. ¿Continuar?',
              )
            ) {
              guardar(true);
            }
          }}
        >
          Regenerar contraseña
        </button>
      </td>
      <td className="p-2">
        <div className="flex gap-3">
          <button
            className="text-marca hover:underline disabled:opacity-50"
            onClick={() => guardar(false)}
            disabled={guardando}
          >
            {guardando ? 'Guardando…' : 'Guardar'}
          </button>
          <button className="text-slate-500 hover:underline" onClick={() => setEditando(false)}>
            Cancelar
          </button>
        </div>
      </td>
    </tr>
  );
}
