import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api/client';
import {
  AudioPrompt,
  Extension,
  Horario,
  HorarioDestinoTipo,
  HorarioFranja,
  Ivr,
  Tenant,
} from '../api/tipos';

const DIAS = [
  { valor: 1, corto: 'L', largo: 'Lunes' },
  { valor: 2, corto: 'M', largo: 'Martes' },
  { valor: 3, corto: 'X', largo: 'Miércoles' },
  { valor: 4, corto: 'J', largo: 'Jueves' },
  { valor: 5, corto: 'V', largo: 'Viernes' },
  { valor: 6, corto: 'S', largo: 'Sábado' },
  { valor: 7, corto: 'D', largo: 'Domingo' },
];

const TIPOS_DESTINO: Array<{ valor: HorarioDestinoTipo; etiqueta: string; ayuda: string }> = [
  { valor: 'extension', etiqueta: 'Sonar en una extensión', ayuda: 'Suena el teléfono elegido. Si no contestan, salta su buzón.' },
  { valor: 'ivr', etiqueta: 'Menú de opciones (IVR)', ayuda: '"Pulse 1 para ventas, 2 para soporte…"' },
  { valor: 'anuncio', etiqueta: 'Locución y colgar', ayuda: 'Se reproduce un mensaje y se cuelga.' },
  { valor: 'buzon', etiqueta: 'Locución y buzón de voz', ayuda: 'Mensaje y luego puede dejar un recado.' },
  { valor: 'colgar', etiqueta: 'Colgar sin más', ayuda: 'No se atiende la llamada.' },
];

const FRANJA_POR_DEFECTO: HorarioFranja = {
  diaInicio: 1,
  diaFin: 5,
  horaInicio: '09:00',
  horaFin: '18:00',
};

/**
 * Horarios de oficina: deciden qué pasa con una llamada según el día y la
 * hora a la que entra. Es la pieza que faltaba para que un número SIP no
 * suene igual a las 11 de la mañana que a las 3 de la madrugada.
 */
export function HorariosPage() {
  const [params] = useSearchParams();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [tenantId, setTenantId] = useState(params.get('tenantId') ?? '');
  const [horarios, setHorarios] = useState<Horario[]>([]);
  const [extensiones, setExtensiones] = useState<Extension[]>([]);
  const [ivrs, setIvrs] = useState<Ivr[]>([]);
  const [locuciones, setLocuciones] = useState<AudioPrompt[]>([]);
  const [editando, setEditando] = useState<Horario | 'nuevo' | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .get<Tenant[]>('/api/tenants')
      .then((t) => {
        setTenants(t);
        if (!tenantId && t[0]) setTenantId(t[0].id);
      })
      .catch((e) => setError(e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function cargar() {
    if (!tenantId) return;
    const [hs, exts, ivs, locs] = await Promise.all([
      api.get<Horario[]>(`/api/tenants/${tenantId}/horarios`),
      api.get<Extension[]>(`/api/tenants/${tenantId}/extensions`).catch(() => []),
      api.get<Ivr[]>(`/api/tenants/${tenantId}/ivrs`).catch(() => []),
      api.get<AudioPrompt[]>(`/api/tenants/${tenantId}/locuciones`).catch(() => []),
    ]);
    setHorarios(hs);
    setExtensiones(exts);
    setIvrs(ivs);
    setLocuciones(locs);
  }

  useEffect(() => {
    cargar().catch((e) => setError(e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenantId]);

  async function eliminar(id: string) {
    await api.delete(`/api/tenants/${tenantId}/horarios/${id}`);
    await cargar();
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">Horarios de oficina</h1>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">
          Define de qué hora a qué hora se atienden las llamadas. Dentro del horario la llamada va a
          un sitio (la centralita, un menú de opciones…) y fuera de él a otro (una locución de
          "estamos cerrados", un buzón de voz…). Luego solo tienes que apuntar un número SIP a este
          horario desde <strong>Números SIP</strong>.
        </p>
      </div>

      <label className="text-sm flex flex-col gap-1 max-w-xs">
        Cliente
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
          value={tenantId}
          onChange={(e) => {
            setTenantId(e.target.value);
            setEditando(null);
          }}
        >
          {tenants.map((t) => (
            <option key={t.id} value={t.id}>
              {t.nombre}
            </option>
          ))}
        </select>
      </label>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      {editando ? (
        <EditorHorario
          tenantId={tenantId}
          horario={editando === 'nuevo' ? null : editando}
          extensiones={extensiones}
          ivrs={ivrs}
          locuciones={locuciones}
          onCancelar={() => setEditando(null)}
          onGuardado={async () => {
            setEditando(null);
            await cargar();
          }}
        />
      ) : (
        <>
          <div>
            <button
              className="bg-marca text-white rounded-md px-4 py-2 text-sm"
              onClick={() => setEditando('nuevo')}
              disabled={!tenantId}
            >
              Crear horario
            </button>
          </div>

          <div className="flex flex-col gap-3">
            {horarios.map((h) => (
              <div key={h.id} className="bg-white dark:bg-slate-800 rounded-xl shadow p-4">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div>
                    <h3 className="font-semibold">{h.nombre}</h3>
                    <p className="text-sm text-slate-500 mt-1">{resumenFranjas(h.franjas)}</p>
                    <p className="text-sm mt-2">
                      <span className="text-slate-500">Dentro de horario:</span>{' '}
                      {describirDestino(h.destinoDentroTipo, h.destinoDentroId, extensiones, ivrs, locuciones)}
                    </p>
                    <p className="text-sm">
                      <span className="text-slate-500">Fuera de horario:</span>{' '}
                      {describirDestino(h.destinoFueraTipo, h.destinoFueraId, extensiones, ivrs, locuciones, h.promptFueraId)}
                    </p>
                  </div>
                  <div className="flex gap-3 text-sm">
                    <button className="text-marca hover:underline" onClick={() => setEditando(h)}>
                      Editar
                    </button>
                    <button className="text-red-600 hover:underline" onClick={() => eliminar(h.id)}>
                      Eliminar
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {horarios.length === 0 && (
              <p className="text-slate-500 text-sm">
                Este cliente todavía no tiene ningún horario. Crea uno para poder distinguir las
                llamadas dentro y fuera de la jornada.
              </p>
            )}
          </div>
        </>
      )}
    </div>
  );
}

/** "L-V 09:00-14:00 · L-V 16:00-19:00 · S 10:00-13:00" */
function resumenFranjas(franjas: HorarioFranja[]): string {
  if (!franjas?.length) return 'Sin franjas definidas';
  return franjas
    .map((f) => {
      const ini = DIAS.find((d) => d.valor === f.diaInicio)?.corto ?? '?';
      const fin = DIAS.find((d) => d.valor === f.diaFin)?.corto ?? '?';
      const dias = f.diaInicio === f.diaFin ? ini : `${ini}-${fin}`;
      return `${dias} ${f.horaInicio}-${f.horaFin}`;
    })
    .join(' · ');
}

function describirDestino(
  tipo: HorarioDestinoTipo,
  destinoId: string | undefined,
  extensiones: Extension[],
  ivrs: Ivr[],
  locuciones: AudioPrompt[],
  promptId?: string,
): string {
  const nombreLocucion = (id?: string) => locuciones.find((l) => l.id === id)?.nombre;
  switch (tipo) {
    case 'extension': {
      const ext = extensiones.find((e) => e.id === destinoId);
      return ext ? `suena la extensión ${ext.numero} (${ext.nombre})` : 'extensión sin elegir';
    }
    case 'ivr': {
      const ivr = ivrs.find((i) => i.id === destinoId);
      return ivr ? `menú de opciones "${ivr.nombre}"` : 'IVR sin elegir';
    }
    case 'anuncio': {
      const loc = nombreLocucion(promptId) ?? nombreLocucion(destinoId);
      return loc ? `locución "${loc}" y colgar` : 'locución sin elegir';
    }
    case 'buzon': {
      const ext = extensiones.find((e) => e.id === destinoId);
      const loc = nombreLocucion(promptId);
      const base = ext ? `buzón de la extensión ${ext.numero}` : 'buzón sin extensión elegida';
      return loc ? `locución "${loc}" y ${base}` : base;
    }
    case 'colgar':
      return 'colgar sin atender';
    default:
      return '—';
  }
}

function EditorHorario({
  tenantId,
  horario,
  extensiones,
  ivrs,
  locuciones,
  onCancelar,
  onGuardado,
}: {
  tenantId: string;
  horario: Horario | null;
  extensiones: Extension[];
  ivrs: Ivr[];
  locuciones: AudioPrompt[];
  onCancelar: () => void;
  onGuardado: () => void;
}) {
  const [nombre, setNombre] = useState(horario?.nombre ?? 'Horario de oficina');
  const [franjas, setFranjas] = useState<HorarioFranja[]>(
    horario?.franjas?.length ? horario.franjas : [{ ...FRANJA_POR_DEFECTO }],
  );
  const [dentroTipo, setDentroTipo] = useState<HorarioDestinoTipo>(horario?.destinoDentroTipo ?? 'extension');
  const [dentroId, setDentroId] = useState(horario?.destinoDentroId ?? '');
  const [fueraTipo, setFueraTipo] = useState<HorarioDestinoTipo>(horario?.destinoFueraTipo ?? 'anuncio');
  const [fueraId, setFueraId] = useState(horario?.destinoFueraId ?? '');
  const [promptFueraId, setPromptFueraId] = useState(horario?.promptFueraId ?? '');
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function cambiarFranja(indice: number, cambios: Partial<HorarioFranja>) {
    setFranjas(franjas.map((f, i) => (i === indice ? { ...f, ...cambios } : f)));
  }

  async function guardar() {
    setGuardando(true);
    setError(null);
    try {
      const cuerpo = {
        nombre,
        franjas: franjas.map((f) => ({
          diaInicio: Number(f.diaInicio),
          diaFin: Number(f.diaFin),
          horaInicio: f.horaInicio,
          horaFin: f.horaFin,
        })),
        destinoDentroTipo: dentroTipo,
        destinoDentroId: dentroId || undefined,
        destinoFueraTipo: fueraTipo,
        destinoFueraId: fueraId || undefined,
        promptFueraId: promptFueraId || undefined,
      };
      if (horario) {
        await api.patch(`/api/tenants/${tenantId}/horarios/${horario.id}`, cuerpo);
      } else {
        await api.post(`/api/tenants/${tenantId}/horarios`, cuerpo);
      }
      onGuardado();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo guardar el horario');
    } finally {
      setGuardando(false);
    }
  }

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex flex-col gap-5">
      <h2 className="font-semibold text-lg">{horario ? 'Editar horario' : 'Nuevo horario'}</h2>

      <label className="text-sm flex flex-col gap-1 max-w-sm">
        Nombre
        <input
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />
      </label>

      <div>
        <h3 className="text-sm font-medium mb-2">Franjas de atención</h3>
        <p className="text-xs text-slate-500 mb-3">
          Añade una franja por cada tramo. Ejemplo típico: de lunes a viernes 09:00–14:00 y otra de
          16:00–19:00.
        </p>
        <div className="flex flex-col gap-2">
          {franjas.map((f, i) => (
            <div key={i} className="flex gap-2 items-end flex-wrap">
              <label className="text-xs flex flex-col gap-1">
                Desde
                <select
                  className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                  value={f.diaInicio}
                  onChange={(e) => cambiarFranja(i, { diaInicio: Number(e.target.value) })}
                >
                  {DIAS.map((d) => (
                    <option key={d.valor} value={d.valor}>
                      {d.largo}
                    </option>
                  ))}
                </select>
              </label>
              <label className="text-xs flex flex-col gap-1">
                Hasta
                <select
                  className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                  value={f.diaFin}
                  onChange={(e) => cambiarFranja(i, { diaFin: Number(e.target.value) })}
                >
                  {DIAS.map((d) => (
                    <option key={d.valor} value={d.valor}>
                      {d.largo}
                    </option>
                  ))}
                </select>
              </label>
              <label className="text-xs flex flex-col gap-1">
                De
                <input
                  type="time"
                  className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                  value={f.horaInicio}
                  onChange={(e) => cambiarFranja(i, { horaInicio: e.target.value })}
                />
              </label>
              <label className="text-xs flex flex-col gap-1">
                A
                <input
                  type="time"
                  className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                  value={f.horaFin}
                  onChange={(e) => cambiarFranja(i, { horaFin: e.target.value })}
                />
              </label>
              {franjas.length > 1 && (
                <button
                  type="button"
                  className="text-red-600 text-xs hover:underline pb-2"
                  onClick={() => setFranjas(franjas.filter((_, j) => j !== i))}
                >
                  Quitar
                </button>
              )}
            </div>
          ))}
        </div>
        <button
          type="button"
          className="text-sm text-marca hover:underline mt-2"
          onClick={() => setFranjas([...franjas, { ...FRANJA_POR_DEFECTO }])}
        >
          + Añadir otra franja
        </button>
      </div>

      <SelectorDestino
        titulo="Dentro del horario, la llamada…"
        tipo={dentroTipo}
        destinoId={dentroId}
        onTipo={(t) => {
          setDentroTipo(t);
          setDentroId('');
        }}
        onDestino={setDentroId}
        extensiones={extensiones}
        ivrs={ivrs}
        locuciones={locuciones}
      />

      <SelectorDestino
        titulo="Fuera del horario, la llamada…"
        tipo={fueraTipo}
        destinoId={fueraId}
        onTipo={(t) => {
          setFueraTipo(t);
          setFueraId('');
        }}
        onDestino={setFueraId}
        extensiones={extensiones}
        ivrs={ivrs}
        locuciones={locuciones}
        promptId={promptFueraId}
        onPrompt={setPromptFueraId}
      />

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <div className="flex gap-3">
        <button
          className="bg-marca text-white rounded-md px-4 py-2 text-sm disabled:opacity-50"
          onClick={guardar}
          disabled={guardando}
        >
          {guardando ? 'Guardando…' : 'Guardar horario'}
        </button>
        <button className="text-sm text-slate-500 hover:underline" onClick={onCancelar}>
          Cancelar
        </button>
      </div>
    </div>
  );
}

function SelectorDestino({
  titulo,
  tipo,
  destinoId,
  onTipo,
  onDestino,
  extensiones,
  ivrs,
  locuciones,
  promptId,
  onPrompt,
}: {
  titulo: string;
  tipo: HorarioDestinoTipo;
  destinoId: string;
  onTipo: (t: HorarioDestinoTipo) => void;
  onDestino: (id: string) => void;
  extensiones: Extension[];
  ivrs: Ivr[];
  locuciones: AudioPrompt[];
  promptId?: string;
  onPrompt?: (id: string) => void;
}) {
  const ayuda = TIPOS_DESTINO.find((t) => t.valor === tipo)?.ayuda;

  return (
    <div className="border-t border-slate-100 dark:border-slate-700 pt-4">
      <h3 className="text-sm font-medium mb-2">{titulo}</h3>
      <div className="flex gap-2 flex-wrap items-end">
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 text-sm"
          value={tipo}
          onChange={(e) => onTipo(e.target.value as HorarioDestinoTipo)}
        >
          {TIPOS_DESTINO.map((t) => (
            <option key={t.valor} value={t.valor}>
              {t.etiqueta}
            </option>
          ))}
        </select>

        {(tipo === 'extension' || tipo === 'buzon') && (
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 text-sm"
            value={destinoId}
            onChange={(e) => onDestino(e.target.value)}
          >
            <option value="">Elegir extensión…</option>
            {extensiones.map((e) => (
              <option key={e.id} value={e.id}>
                {e.numero} — {e.nombre}
              </option>
            ))}
          </select>
        )}

        {tipo === 'ivr' && (
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 text-sm"
            value={destinoId}
            onChange={(e) => onDestino(e.target.value)}
          >
            <option value="">Elegir menú…</option>
            {ivrs.map((i) => (
              <option key={i.id} value={i.id}>
                {i.nombre}
              </option>
            ))}
          </select>
        )}

        {tipo === 'anuncio' && (
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 text-sm"
            value={destinoId}
            onChange={(e) => onDestino(e.target.value)}
          >
            <option value="">Elegir locución…</option>
            {locuciones.map((l) => (
              <option key={l.id} value={l.id}>
                {l.nombre}
              </option>
            ))}
          </select>
        )}

        {tipo === 'buzon' && onPrompt && (
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 text-sm"
            value={promptId ?? ''}
            onChange={(e) => onPrompt(e.target.value)}
          >
            <option value="">Locución previa (opcional)…</option>
            {locuciones.map((l) => (
              <option key={l.id} value={l.id}>
                {l.nombre}
              </option>
            ))}
          </select>
        )}
      </div>
      {ayuda && <p className="text-xs text-slate-500 mt-2">{ayuda}</p>}
      {(tipo === 'ivr' && ivrs.length === 0) && (
        <p className="text-xs text-amber-600 mt-1">
          Este cliente no tiene ningún menú creado todavía (se crean en la pantalla de IVR).
        </p>
      )}
      {(tipo === 'anuncio' || tipo === 'buzon') && locuciones.length === 0 && (
        <p className="text-xs text-amber-600 mt-1">
          Este cliente no tiene locuciones grabadas todavía (se graban o suben en la pantalla de IVR).
        </p>
      )}
    </div>
  );
}
