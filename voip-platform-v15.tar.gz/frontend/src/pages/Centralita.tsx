import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import type {
  AudioPrompt,
  Did,
  Extension,
  Horario,
  HorarioDestinoTipo,
  Ivr,
  Tenant,
  Trunk,
} from '../api/tipos';

/**
 * La centralita de un cliente, vista de una sola vez.
 *
 * Hasta ahora, para saber qué le pasaba a una llamada había que ir saltando
 * entre cinco pantallas —Números, Horarios, IVR, Extensiones, Proveedores— y
 * reconstruir el recorrido de memoria. Aquí se ve entero y de un vistazo:
 * por dónde entra la llamada, qué decide el horario, qué ofrece el IVR y en
 * qué teléfono acaba sonando.
 *
 * También señala lo que está a medias (un número sin destino, un horario que
 * apunta a una extensión borrada), que es justo lo que nadie ve hasta que un
 * cliente llama para decir que su teléfono no suena.
 */

const DIAS = ['', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

const SERVIDOR_SIP = (() => {
  const wss = import.meta.env.VITE_FREESWITCH_WSS_URL ?? '';
  const host = wss.replace(/^[a-zA-Z][\w+.-]*:\/\//, '').replace(/[:/].*$/, '');
  return host || 'la IP del servidor';
})();
const DOMINIO_BASE = import.meta.env.VITE_SIP_DOMAIN ?? 'plataforma.local';

type Aviso = { texto: string; enlace?: string };

export function CentralitaPage() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [tenantId, setTenantId] = useState('');
  const [extensiones, setExtensiones] = useState<Extension[]>([]);
  const [dids, setDids] = useState<Did[]>([]);
  const [horarios, setHorarios] = useState<Horario[]>([]);
  const [ivrs, setIvrs] = useState<Ivr[]>([]);
  const [prompts, setPrompts] = useState<AudioPrompt[]>([]);
  const [trunks, setTrunks] = useState<Trunk[]>([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .get<Tenant[]>('/api/tenants')
      .then((lista) => {
        setTenants(lista);
        setTenantId((actual) => actual || lista[0]?.id || '');
        if (lista.length === 0) setCargando(false);
      })
      .catch((e: Error) => {
        setError(e.message);
        setCargando(false);
      });
  }, []);

  useEffect(() => {
    if (!tenantId) return;
    setCargando(true);
    setError(null);
    Promise.all([
      api.get<Extension[]>(`/api/tenants/${tenantId}/extensions`).catch(() => []),
      api.get<Did[]>('/api/dids').catch(() => []),
      api.get<Horario[]>(`/api/tenants/${tenantId}/horarios`).catch(() => []),
      api.get<Ivr[]>(`/api/tenants/${tenantId}/ivrs`).catch(() => []),
      api.get<AudioPrompt[]>(`/api/tenants/${tenantId}/locuciones`).catch(() => []),
      api.get<Trunk[]>('/api/trunks').catch(() => []),
    ])
      .then(([ext, todosDids, hor, iv, pr, tr]) => {
        setExtensiones(ext);
        setDids(todosDids.filter((d) => d.tenantId === tenantId));
        setHorarios(hor);
        setIvrs(iv);
        setPrompts(pr);
        setTrunks(tr);
      })
      .catch((e: Error) => setError(e.message))
      .finally(() => setCargando(false));
  }, [tenantId]);

  const tenant = tenants.find((t) => t.id === tenantId);
  const dominioSip = tenant ? `${tenant.subdominio}.${DOMINIO_BASE}` : '';

  // --- Resolutores de nombres -------------------------------------------
  const nombreExtension = (id?: string) => {
    if (!id) return null;
    const e = extensiones.find((x) => x.id === id || x.numero === id);
    return e ? `${e.numero} · ${e.nombre}` : null;
  };
  const nombreIvr = (id?: string) => ivrs.find((i) => i.id === id)?.nombre ?? null;
  const nombreHorario = (id?: string) => horarios.find((h) => h.id === id)?.nombre ?? null;
  const nombrePrompt = (id?: string) => prompts.find((p) => p.id === id)?.nombre ?? null;

  function describirDestino(
    tipo: HorarioDestinoTipo,
    destinoId?: string,
    promptId?: string,
  ): { texto: string; roto: boolean } {
    switch (tipo) {
      case 'extension': {
        const n = nombreExtension(destinoId);
        return n
          ? { texto: `Suena la extensión ${n}`, roto: false }
          : { texto: 'Extensión que ya no existe', roto: true };
      }
      case 'ivr': {
        const n = nombreIvr(destinoId);
        return n
          ? { texto: `Entra en el menú «${n}»`, roto: false }
          : { texto: 'Menú IVR que ya no existe', roto: true };
      }
      case 'anuncio': {
        const n = nombrePrompt(promptId);
        return n
          ? { texto: `Se oye la locución «${n}» y se cuelga`, roto: false }
          : { texto: 'Locución sin asignar', roto: true };
      }
      case 'buzon':
        return { texto: 'Salta el contestador y puede dejar mensaje', roto: false };
      case 'colgar':
        return { texto: 'Se cuelga sin más', roto: false };
      default:
        return { texto: 'Sin configurar', roto: true };
    }
  }

  const resumenFranjas = (h: Horario) =>
    h.franjas.length === 0
      ? 'sin franjas definidas'
      : h.franjas
          .map((f) =>
            f.diaInicio === f.diaFin
              ? `${DIAS[f.diaInicio]} ${f.horaInicio}-${f.horaFin}`
              : `${DIAS[f.diaInicio]}-${DIAS[f.diaFin]} ${f.horaInicio}-${f.horaFin}`,
          )
          .join(' · ');

  // Proveedores por los que saldrían las llamadas de este cliente: los suyos
  // propios si los tiene, y si no los generales de la plataforma.
  const trunksDelCliente = useMemo(() => {
    const activos = trunks.filter((t) => t.activo);
    const propios = activos.filter((t) => t.tenantId === tenantId);
    return (propios.length ? propios : activos.filter((t) => !t.tenantId)).sort(
      (a, b) => a.prioridad - b.prioridad,
    );
  }, [trunks, tenantId]);

  // --- Lo que está a medias ---------------------------------------------
  const avisos = useMemo<Aviso[]>(() => {
    if (!tenant) return [];
    const lista: Aviso[] = [];

    if (extensiones.length === 0)
      lista.push({
        texto: 'Este cliente no tiene ninguna extensión: no hay dónde hacer sonar una llamada.',
        enlace: '/extensiones',
      });

    if (dids.length === 0)
      lista.push({
        texto: 'No tiene ningún número asignado, así que nadie puede llamarle desde fuera.',
        enlace: '/dids',
      });

    for (const d of dids) {
      if (d.destinoTipo === 'ninguno' || !d.destinoId)
        lista.push({
          texto: `El número ${d.numero} no tiene destino: las llamadas se rechazan.`,
          enlace: '/dids',
        });
      if (!d.activo)
        lista.push({ texto: `El número ${d.numero} está desactivado.`, enlace: '/dids' });
    }

    for (const h of horarios) {
      if (h.franjas.length === 0)
        lista.push({
          texto: `El horario «${h.nombre}» no tiene franjas: todo cae siempre en «fuera de horario».`,
          enlace: '/horarios',
        });
      if (describirDestino(h.destinoDentroTipo, h.destinoDentroId, h.promptDentroId).roto)
        lista.push({
          texto: `El horario «${h.nombre}» apunta, dentro de horario, a algo que ya no existe.`,
          enlace: '/horarios',
        });
      if (describirDestino(h.destinoFueraTipo, h.destinoFueraId, h.promptFueraId).roto)
        lista.push({
          texto: `El horario «${h.nombre}» apunta, fuera de horario, a algo que ya no existe.`,
          enlace: '/horarios',
        });
    }

    for (const i of ivrs) {
      if (i.opciones.length === 0)
        lista.push({
          texto: `El menú «${i.nombre}» no tiene ninguna opción: quien llame no podrá elegir nada.`,
          enlace: '/ivr',
        });
      for (const o of i.opciones) {
        const existe =
          o.destinoTipo === 'extension' ? nombreExtension(o.destinoId) : nombreIvr(o.destinoId);
        if (!existe)
          lista.push({
            texto: `En el menú «${i.nombre}», la tecla ${o.digito} lleva a algo que ya no existe.`,
            enlace: '/ivr',
          });
      }
    }

    if (trunksDelCliente.length === 0)
      lista.push({
        texto: 'No hay ningún proveedor activo: este cliente no puede llamar hacia fuera.',
        enlace: '/trunks',
      });

    return lista;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenant, extensiones, dids, horarios, ivrs, prompts, trunks]);

  return (
    <div className="flex flex-col gap-6 max-w-5xl">
        <header className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold">Centralita del cliente</h1>
            <p className="text-sm text-slate-500 mt-1">
              Todo el recorrido de una llamada en una sola pantalla: por dónde entra, qué decide el
              horario, qué ofrece el menú y en qué teléfono acaba sonando.
            </p>
          </div>
          <label className="flex flex-col text-sm gap-1">
            Cliente
            <select
              className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 min-w-56"
              value={tenantId}
              onChange={(e) => setTenantId(e.target.value)}
            >
              {tenants.length === 0 && <option value="">(no hay clientes)</option>}
              {tenants.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.nombre}
                </option>
              ))}
            </select>
          </label>
        </header>

        {error && (
          <div className="rounded-lg border border-red-300 bg-red-50 dark:bg-red-900/20 p-3 text-sm">
            {error}
          </div>
        )}

        {cargando && <p className="text-sm text-slate-500">Cargando…</p>}

        {!cargando && tenant && (
          <>
            <section className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <Tarjeta etiqueta="Números" valor={dids.length} a="/dids" />
              <Tarjeta etiqueta="Extensiones" valor={extensiones.length} a="/extensiones" />
              <Tarjeta etiqueta="Horarios" valor={horarios.length} a="/horarios" />
              <Tarjeta etiqueta="Menús IVR" valor={ivrs.length} a="/ivr" />
              <Tarjeta etiqueta="Locuciones" valor={prompts.length} a="/ivr" />
            </section>

            {avisos.length > 0 && (
              <section className="rounded-xl border border-amber-300 bg-amber-50 dark:bg-amber-900/20 p-4">
                <h2 className="font-medium mb-2">Cosas a medias ({avisos.length})</h2>
                <ul className="flex flex-col gap-1 text-sm">
                  {avisos.map((a, i) => (
                    <li key={i}>
                      {a.texto}{' '}
                      {a.enlace && (
                        <Link to={a.enlace} className="text-marca underline">
                          arreglar
                        </Link>
                      )}
                    </li>
                  ))}
                </ul>
              </section>
            )}

            <section className="flex flex-col gap-3">
              <h2 className="text-lg font-medium">Llamadas que entran</h2>
              {dids.length === 0 && (
                <p className="text-sm text-slate-500">
                  Este cliente todavía no tiene números asignados.
                </p>
              )}
              {dids.map((did) => (
                <RecorridoDid
                  key={did.id}
                  did={did}
                  horario={horarios.find((h) => h.id === did.destinoId)}
                  ivr={ivrs.find((i) => i.id === did.destinoId)}
                  nombreExtension={nombreExtension}
                  nombreIvr={nombreIvr}
                  nombreHorario={nombreHorario}
                  describirDestino={describirDestino}
                  resumenFranjas={resumenFranjas}
                />
              ))}
            </section>

            <section className="flex flex-col gap-2">
              <h2 className="text-lg font-medium">Llamadas que salen</h2>
              {trunksDelCliente.length === 0 ? (
                <p className="text-sm text-slate-500">
                  Sin proveedores activos: este cliente no puede llamar hacia fuera.{' '}
                  <Link to="/trunks" className="text-marca underline">
                    Configurar
                  </Link>
                </p>
              ) : (
                <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4 text-sm">
                  <p className="mb-2 text-slate-500">
                    Se intenta en este orden; si el primero no coge la llamada, se prueba el
                    siguiente.
                  </p>
                  <ol className="flex flex-col gap-1">
                    {trunksDelCliente.map((t, i) => (
                      <li key={t.id}>
                        <span className="text-slate-400 mr-2">{i + 1}.</span>
                        <span className="font-medium">{t.nombre}</span>{' '}
                        <span className="text-slate-500">
                          — {t.proveedor} ({t.host}:{t.puerto})
                        </span>
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </section>

            <section className="flex flex-col gap-2">
              <h2 className="text-lg font-medium">Datos para configurar los teléfonos</h2>
              <p className="text-sm text-slate-500">
                Esto es lo que hay que escribir en un teléfono IP o un softphone para que la
                extensión se registre. La contraseña se muestra al crear la extensión.
              </p>
              <div className="bg-white dark:bg-slate-800 rounded-xl shadow overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-left text-slate-500 border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="p-3">Extensión</th>
                      <th className="p-3">Usuario SIP</th>
                      <th className="p-3">Dominio</th>
                      <th className="p-3">Servidor</th>
                    </tr>
                  </thead>
                  <tbody>
                    {extensiones.length === 0 && (
                      <tr>
                        <td className="p-3 text-slate-500" colSpan={4}>
                          Sin extensiones.{' '}
                          <Link to="/extensiones" className="text-marca underline">
                            Crear la primera
                          </Link>
                        </td>
                      </tr>
                    )}
                    {extensiones.map((e) => (
                      <tr key={e.id} className="border-b border-slate-100 dark:border-slate-700/50">
                        <td className="p-3">
                          {e.numero} · {e.nombre}
                          {!e.activo && (
                            <span className="ml-2 text-xs text-amber-600">(desactivada)</span>
                          )}
                        </td>
                        <td className="p-3 font-mono">{e.numero}</td>
                        <td className="p-3 font-mono">{dominioSip}</td>
                        <td className="p-3 font-mono">{SERVIDOR_SIP}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </>
        )}
    </div>
  );
}

function Tarjeta({ etiqueta, valor, a }: { etiqueta: string; valor: number; a: string }) {
  return (
    <Link
      to={a}
      className="bg-white dark:bg-slate-800 rounded-xl shadow p-4 hover:ring-2 hover:ring-marca/40"
    >
      <div className="text-2xl font-semibold">{valor}</div>
      <div className="text-xs text-slate-500">{etiqueta}</div>
    </Link>
  );
}

function Flecha() {
  return <div className="text-slate-400 px-2 select-none">→</div>;
}

function Paso({
  titulo,
  detalle,
  roto,
}: {
  titulo: string;
  detalle?: string;
  roto?: boolean;
}) {
  return (
    <div
      className={`rounded-lg px-3 py-2 border ${
        roto
          ? 'border-red-300 bg-red-50 dark:bg-red-900/20'
          : 'border-slate-200 dark:border-slate-700'
      }`}
    >
      <div className="font-medium text-sm">{titulo}</div>
      {detalle && <div className="text-xs text-slate-500 mt-0.5">{detalle}</div>}
    </div>
  );
}

function RecorridoDid({
  did,
  horario,
  ivr,
  nombreExtension,
  nombreIvr,
  nombreHorario,
  describirDestino,
  resumenFranjas,
}: {
  did: Did;
  horario?: Horario;
  ivr?: Ivr;
  nombreExtension: (id?: string) => string | null;
  nombreIvr: (id?: string) => string | null;
  nombreHorario: (id?: string) => string | null;
  describirDestino: (
    tipo: HorarioDestinoTipo,
    destinoId?: string,
    promptId?: string,
  ) => { texto: string; roto: boolean };
  resumenFranjas: (h: Horario) => string;
}) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4">
      <div className="flex items-start gap-2 flex-wrap">
        <Paso
          titulo={did.numero}
          detalle={did.descripcion || 'Número entrante'}
          roto={!did.activo}
        />
        <Flecha />

        {did.destinoTipo === 'horario' && horario && (
          <div className="flex-1 min-w-64">
            <Paso titulo={`Horario «${horario.nombre}»`} detalle={resumenFranjas(horario)} />
            <div className="mt-2 ml-4 flex flex-col gap-2 border-l border-slate-200 dark:border-slate-700 pl-4">
              <RamaHorario
                etiqueta="Dentro del horario"
                {...describirDestino(
                  horario.destinoDentroTipo,
                  horario.destinoDentroId,
                  horario.promptDentroId,
                )}
              />
              <RamaHorario
                etiqueta="Fuera del horario"
                {...describirDestino(
                  horario.destinoFueraTipo,
                  horario.destinoFueraId,
                  horario.promptFueraId,
                )}
              />
            </div>
          </div>
        )}

        {did.destinoTipo === 'ivr' && ivr && (
          <div className="flex-1 min-w-64">
            <Paso
              titulo={`Menú «${ivr.nombre}»`}
              detalle={`Espera ${ivr.timeoutSegundos}s a que marquen una opción`}
            />
            <div className="mt-2 ml-4 flex flex-col gap-1 border-l border-slate-200 dark:border-slate-700 pl-4 text-sm">
              {ivr.opciones.length === 0 && (
                <span className="text-red-600 text-xs">Sin opciones configuradas</span>
              )}
              {ivr.opciones.map((o) => {
                const destino =
                  o.destinoTipo === 'extension'
                    ? nombreExtension(o.destinoId)
                    : nombreIvr(o.destinoId);
                return (
                  <div key={o.id}>
                    <span className="font-mono bg-slate-100 dark:bg-slate-700 rounded px-1.5 py-0.5 text-xs">
                      {o.digito}
                    </span>{' '}
                    <span className="text-slate-400">→</span>{' '}
                    {destino ? (
                      <span>
                        {o.destinoTipo === 'extension' ? 'extensión' : 'menú'} {destino}
                      </span>
                    ) : (
                      <span className="text-red-600">destino que ya no existe</span>
                    )}
                    {o.etiqueta && <span className="text-slate-500 text-xs"> · {o.etiqueta}</span>}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {did.destinoTipo === 'extension' && (
          <Paso
            titulo={nombreExtension(did.destinoId) ?? 'Extensión que ya no existe'}
            detalle="Suena directamente, sin menú ni horario"
            roto={!nombreExtension(did.destinoId)}
          />
        )}

        {(did.destinoTipo === 'ninguno' ||
          (did.destinoTipo === 'horario' && !horario) ||
          (did.destinoTipo === 'ivr' && !ivr)) && (
          <Paso
            titulo="Sin destino"
            detalle="La llamada se rechaza con un 404. Nadie la oye."
            roto
          />
        )}
      </div>

      <div className="mt-3 text-xs">
        <Link to="/dids" className="text-marca underline">
          Cambiar a dónde va este número
        </Link>
        {did.destinoTipo === 'horario' && nombreHorario(did.destinoId) && (
          <>
            {' · '}
            <Link to="/horarios" className="text-marca underline">
              Editar el horario
            </Link>
          </>
        )}
        {did.destinoTipo === 'ivr' && (
          <>
            {' · '}
            <Link to="/ivr" className="text-marca underline">
              Editar el menú
            </Link>
          </>
        )}
      </div>
    </div>
  );
}

function RamaHorario({
  etiqueta,
  texto,
  roto,
}: {
  etiqueta: string;
  texto: string;
  roto: boolean;
}) {
  return (
    <div className="text-sm">
      <span className="text-xs uppercase tracking-wide text-slate-400">{etiqueta}</span>
      <div className={roto ? 'text-red-600' : ''}>{texto}</div>
    </div>
  );
}
