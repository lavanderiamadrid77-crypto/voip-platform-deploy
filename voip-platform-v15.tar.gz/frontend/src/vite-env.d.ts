/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_URL?: string;
  readonly VITE_FREESWITCH_WSS_URL?: string;
  /** Dominio SIP base; el de cada cliente es <subdominio>.<este valor> */
  readonly VITE_SIP_DOMAIN?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
