import { useState } from 'react';

type Idioma = 'es' | 'en';

const textos: Record<Idioma, Record<string, string>> = {
  es: {
    dashboard: 'Panel',
    tenants: 'Clientes',
    tenants_subtitulo: 'Cada Cliente es una centralita virtual independiente (su propio dominio SIP, extensiones y números)',
    extensiones: 'Extensiones',
    trunks: 'Proveedores (troncales SIP)',
    trunks_subtitulo: 'Los Proveedores son las líneas mayoristas por las que entra y sale el tráfico de llamadas hacia la red telefónica. No son clientes: aquí solo se conectan operadores de VoIP.',
    dids: 'Números SIP',
    horarios: 'Horarios',
    ivr: 'IVR y locuciones',
    tarifas: 'Tarifas',
    cdr: 'Llamadas (CDR)',
    webphone: 'Teléfono web',
    cerrar_sesion: 'Cerrar sesión',
    modo_oscuro: 'Modo oscuro',
    email: 'Correo electrónico',
    password: 'Contraseña',
    entrar: 'Entrar',
    nuevo_tenant: 'Nuevo cliente',
    nueva_extension: 'Nueva extensión',
    nuevo_trunk: 'Nuevo proveedor',
    seccion_centralita: 'Centralita virtual',
    seccion_red: 'Red y facturación',
  },
  en: {
    dashboard: 'Dashboard',
    tenants: 'Clients',
    tenants_subtitulo: 'Each Client is an independent virtual PBX (its own SIP domain, extensions and numbers)',
    extensiones: 'Extensions',
    trunks: 'Providers (SIP trunks)',
    trunks_subtitulo: 'Providers are the wholesale lines that carry call traffic in and out to the phone network. They are not clients: only VoIP carriers connect here.',
    dids: 'SIP numbers',
    horarios: 'Business hours',
    ivr: 'IVR & voice prompts',
    tarifas: 'Rates',
    cdr: 'Calls (CDR)',
    webphone: 'Web phone',
    cerrar_sesion: 'Log out',
    modo_oscuro: 'Dark mode',
    email: 'Email',
    password: 'Password',
    entrar: 'Sign in',
    nuevo_tenant: 'New client',
    nueva_extension: 'New extension',
    nuevo_trunk: 'New provider',
    seccion_centralita: 'Virtual PBX',
    seccion_red: 'Network & billing',
  },
};

export function useI18n() {
  const [idioma, setIdioma] = useState<Idioma>(
    (localStorage.getItem('voip_idioma') as Idioma) || 'es',
  );

  function cambiarIdioma(nuevo: Idioma) {
    localStorage.setItem('voip_idioma', nuevo);
    setIdioma(nuevo);
  }

  function t(clave: string): string {
    return textos[idioma][clave] ?? clave;
  }

  return { idioma, cambiarIdioma, t };
}
