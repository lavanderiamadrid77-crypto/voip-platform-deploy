import { Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './auth/AuthContext';
import { RutaProtegida } from './components/RutaProtegida';
import { CdrPage } from './pages/CdrPage';
import { Dashboard } from './pages/Dashboard';
import { Dids } from './pages/Dids';
import { Extensions } from './pages/Extensions';
import { HorariosPage } from './pages/Horarios';
import { IvrPage } from './pages/Ivr';
import { Login } from './pages/Login';
import { RatesPage } from './pages/Rates';
import { Tenants } from './pages/Tenants';
import { Trunks } from './pages/Trunks';
import { Webphone } from './pages/Webphone';

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <RutaProtegida>
              <Dashboard />
            </RutaProtegida>
          }
        />
        <Route
          path="/tenants"
          element={
            <RutaProtegida>
              <Tenants />
            </RutaProtegida>
          }
        />
        <Route
          path="/extensiones"
          element={
            <RutaProtegida>
              <Extensions />
            </RutaProtegida>
          }
        />
        <Route
          path="/trunks"
          element={
            <RutaProtegida>
              <Trunks />
            </RutaProtegida>
          }
        />
        <Route
          path="/dids"
          element={
            <RutaProtegida>
              <Dids />
            </RutaProtegida>
          }
        />
        <Route
          path="/ivr"
          element={
            <RutaProtegida>
              <IvrPage />
            </RutaProtegida>
          }
        />
        <Route
          path="/horarios"
          element={
            <RutaProtegida>
              <HorariosPage />
            </RutaProtegida>
          }
        />
        <Route
          path="/tarifas"
          element={
            <RutaProtegida>
              <RatesPage />
            </RutaProtegida>
          }
        />
        <Route
          path="/cdr"
          element={
            <RutaProtegida>
              <CdrPage />
            </RutaProtegida>
          }
        />
        <Route
          path="/webphone"
          element={
            <RutaProtegida>
              <Webphone />
            </RutaProtegida>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  );
}
