/**
 * Restablece la contraseña del administrador.
 *
 * Existe por un motivo concreto: el script de datos iniciales (seed.ts) sólo
 * CREA el administrador si no existe; si ya está, lo deja intacto y escribe
 * "Super admin ya existía". Eso es lo correcto para no pisar datos, pero deja
 * una trampa: cambiar SEED_ADMIN_PASSWORD en el .env y volver a lanzar el seed
 * NO cambia nada, y uno se queda fuera del panel sin entender por qué.
 *
 * Este script hace lo otro: coge el correo y la contraseña del .env y los
 * IMPONE sobre el usuario existente (o lo crea si no está). Es deliberado y
 * explícito, para que nadie lo ejecute sin querer.
 *
 * Uso, desde la carpeta del proyecto en el servidor:
 *
 *   docker compose exec backend npm run admin:reset
 *
 * La contraseña sale de SEED_ADMIN_PASSWORD del .env; no se teclea aquí ni se
 * escribe en pantalla.
 */
import { DataSource } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import { Tenant } from './common/entities/tenant.entity';
import { User, Rol } from './common/entities/user.entity';
import { Extension } from './common/entities/extension.entity';
import { Trunk } from './common/entities/trunk.entity';
import { Cdr } from './common/entities/cdr.entity';

async function main() {
  const email = process.env.SEED_ADMIN_EMAIL ?? 'admin@plataforma.local';
  const password = process.env.SEED_ADMIN_PASSWORD;

  if (!password) {
    console.error('ERROR: no hay SEED_ADMIN_PASSWORD definida en el entorno.');
    console.error('Ponla en el fichero .env del servidor y vuelve a ejecutar esto.');
    process.exit(1);
  }
  if (password.length < 8) {
    console.error('ERROR: SEED_ADMIN_PASSWORD es demasiado corta (mínimo 8 caracteres).');
    process.exit(1);
  }

  const dataSource = new DataSource({
    type: 'postgres',
    host: process.env.DB_HOST ?? 'localhost',
    port: Number(process.env.DB_PORT ?? 5432),
    username: process.env.DB_USER ?? 'voip',
    password: process.env.DB_PASSWORD ?? 'voip',
    database: process.env.DB_NAME ?? 'voip_platform',
    entities: [Tenant, User, Extension, Trunk, Cdr],
  });
  await dataSource.initialize();

  const repo = dataSource.getRepository(User);
  const hash = await bcrypt.hash(password, 10);

  let admin = await repo.findOne({ where: { email } });
  if (admin) {
    admin.passwordHash = hash;
    admin.activo = true;
    admin.rol = Rol.SUPER_ADMIN;
    await repo.save(admin);
    console.log(`Contraseña restablecida para ${email}.`);
  } else {
    admin = repo.create({ email, passwordHash: hash, rol: Rol.SUPER_ADMIN, activo: true });
    await repo.save(admin);
    console.log(`No existía: se ha creado el administrador ${email}.`);
  }

  // Útil para diagnosticar el caso "no puedo entrar y no sé con qué usuario":
  // dice QUÉ cuentas hay, sin revelar ninguna contraseña.
  const todos = await repo.find({ select: ['email', 'rol', 'activo'] });
  console.log('\nCuentas existentes:');
  for (const u of todos) {
    console.log(`  ${u.email}  rol=${u.rol}  activo=${u.activo}`);
  }
  console.log('\nLa contraseña es la que hay en SEED_ADMIN_PASSWORD dentro del .env.');

  await dataSource.destroy();
}

main().catch((e) => {
  console.error('Ha fallado el restablecimiento:', e.message);
  process.exit(1);
});
