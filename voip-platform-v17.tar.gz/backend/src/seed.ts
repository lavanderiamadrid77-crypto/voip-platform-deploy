/**
 * Script de datos iniciales (seed). Crea:
 *  - Un usuario super_admin para poder entrar al panel por primera vez.
 *  - Un tenant "demo" con una extensión de ejemplo, para probar el flujo
 *    completo (login -> tenant -> extensión -> registrar un softphone).
 *
 * Uso: npm run build && npm run seed
 */
import { DataSource } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import { Tenant } from './common/entities/tenant.entity';
import { User, Rol } from './common/entities/user.entity';
import { Extension, TipoExtension } from './common/entities/extension.entity';
import { Trunk } from './common/entities/trunk.entity';
import { Cdr } from './common/entities/cdr.entity';
import { cifrar } from './common/crypto.util';

async function main() {
  const dataSource = new DataSource({
    type: 'postgres',
    host: process.env.DB_HOST ?? 'localhost',
    port: Number(process.env.DB_PORT ?? 5432),
    username: process.env.DB_USER ?? 'voip',
    password: process.env.DB_PASSWORD ?? 'voip',
    database: process.env.DB_NAME ?? 'voip_platform',
    entities: [Tenant, User, Extension, Trunk, Cdr],
    synchronize: true,
  });
  await dataSource.initialize();

  const userRepo = dataSource.getRepository(User);
  const tenantRepo = dataSource.getRepository(Tenant);
  const extRepo = dataSource.getRepository(Extension);

  const emailAdmin = process.env.SEED_ADMIN_EMAIL ?? 'admin@plataforma.local';
  const passwordAdmin = process.env.SEED_ADMIN_PASSWORD ?? 'CambiaEsto123!';

  let admin = await userRepo.findOne({ where: { email: emailAdmin } });
  if (!admin) {
    admin = userRepo.create({
      email: emailAdmin,
      passwordHash: await bcrypt.hash(passwordAdmin, 10),
      rol: Rol.SUPER_ADMIN,
    });
    await userRepo.save(admin);
    console.log(`Super admin creado: ${emailAdmin} / ${passwordAdmin} (cámbiala tras el primer login)`);
  } else {
    // Aviso importante: el seed NO toca la contraseña de un usuario que ya
    // existe. Cambiar SEED_ADMIN_PASSWORD en el .env y relanzar esto no
    // sirve de nada, y es una forma muy fácil de quedarse fuera del panel
    // creyendo que la contraseña nueva ya está puesta.
    console.log(`Super admin ya existía: ${emailAdmin} (NO se ha tocado su contraseña).`);
    console.log('Para imponer la del .env: docker compose exec backend npm run admin:reset');
  }

  let tenant = await tenantRepo.findOne({ where: { subdominio: 'demo' } });
  if (!tenant) {
    tenant = tenantRepo.create({
      nombre: 'Tenant de Demostración',
      subdominio: 'demo',
      canalesMax: 10,
      extensionesMax: 20,
    });
    await tenantRepo.save(tenant);
    console.log('Tenant "demo" creado');
  }

  const existeExt = await extRepo.findOne({ where: { tenantId: tenant.id, numero: '1000' } });
  if (!existeExt) {
    const passwordSip = 'Demo12345Sip!';
    await extRepo.save(
      extRepo.create({
        tenantId: tenant.id,
        numero: '1000',
        nombre: 'Extensión de prueba',
        tipo: TipoExtension.SOFTPHONE,
        passwordCifrada: cifrar(passwordSip),
        codecs: 'OPUS,G722,PCMU,PCMA',
        webrtcHabilitado: true,
      }),
    );
    console.log(
      `Extensión 1000 creada en tenant "demo" (contraseña SIP: ${passwordSip}). ` +
        'Recuerda ejecutar también el aprovisionamiento en FreeSWITCH si el backend no estaba levantado al crearla ' +
        '(vía la API, no este script, para que se genere el XML correcto).',
    );
  }

  await dataSource.destroy();
}

main().catch((err) => {
  console.error('Error en el seed:', err);
  process.exit(1);
});
