import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs/promises';
import * as path from 'path';

// `modesl` no trae tipos oficiales; se declara mínimamente aquí para no
// depender de @types/modesl (no existe en npm).
// eslint-disable-next-line @typescript-eslint/no-var-requires
const esl = require('modesl');

/**
 * Encapsula toda la comunicación con FreeSWITCH:
 *  - Conexión ESL (Event Socket Library) para comandos y eventos en vivo.
 *  - Generación de los ficheros XML de directory/dialplan/gateways que
 *    FreeSWITCH lee desde disco (montados como volumen compartido).
 *
 * Nota: FreeSWITCH normalmente usa mod_xml_curl para configuración 100%
 * dinámica vía HTTP. Para el MVP se usa el enfoque más simple de escribir
 * ficheros XML a un volumen compartido + "reloadxml" por ESL, que es más
 * fácil de depurar y no requiere levantar un servidor XML-RPC aparte.
 * Migrar a mod_xml_curl queda documentado como mejora de Fase 2.
 */
@Injectable()
export class FreeswitchService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(FreeswitchService.name);
  private connection: any;
  private reconectando = false;

  constructor(private readonly config: ConfigService) {}

  onModuleInit() {
    // NO se espera aquí a que la conexión tenga éxito, y es deliberado.
    //
    // Antes esto era `await this.conectar()`, y `conectar()` sólo resolvía su
    // promesa cuando el ESL conectaba bien. Si FreeSWITCH todavía estaba
    // arrancando —cosa habitual, porque los dos contenedores se levantan a la
    // vez y FreeSWITCH tarda más—, la primera conexión daba ECONNREFUSED, la
    // promesa se quedaba pendiente PARA SIEMPRE, y con ella el arranque de
    // Nest: nunca se llegaba a ejecutar app.listen(), así que el backend no se
    // ponía a escuchar en el puerto 3000. El contenedor parecía sano ("Up"),
    // el proceso vivía, los reintentos acababan conectando con FreeSWITCH...
    // y aun así toda la API respondía con "connection reset". Un fallo
    // desconcertante que sólo aparecía cuando el orden de arranque no
    // acompañaba, y que dejaba el panel entero inservible.
    //
    // La centralita es una dependencia opcional para arrancar: sin ella no se
    // pueden mandar órdenes a FreeSWITCH, pero el panel, el login y toda la
    // configuración deben seguir funcionando.
    void this.conectar();
  }

  onModuleDestroy() {
    this.connection?.disconnect?.();
  }

  /**
   * Abre la conexión ESL. La promesa se resuelve SIEMPRE —conecte o no— para
   * que ningún flujo que la espere pueda quedarse colgado; el resultado se
   * consulta con `estaConectado()`.
   */
  private conectar(): Promise<void> {
    return new Promise((resolve) => {
      const host = this.config.get<string>('FREESWITCH_ESL_HOST', 'freeswitch');
      const port = this.config.get<number>('FREESWITCH_ESL_PORT', 8021);
      const password = this.config.get<string>('FREESWITCH_ESL_PASSWORD', 'ClueCon');

      // Un intento puede terminar de varias formas (conecta, da error, se
      // cierra) y alguna puede repetirse. Se resuelve una sola vez.
      let terminado = false;
      const terminar = () => {
        if (terminado) return;
        terminado = true;
        resolve();
      };

      this.connection = new esl.Connection(host, port, password, () => {
        this.logger.log(`Conectado a FreeSWITCH ESL en ${host}:${port}`);
        terminar();
      });

      this.connection.on('error', (err: Error) => {
        this.logger.error(`Error de conexión ESL: ${err.message}`);
        terminar();
        this.reintentar();
      });

      this.connection.on('esl::end', () => {
        this.logger.warn('Conexión ESL cerrada, reintentando...');
        terminar();
        this.reintentar();
      });
    });
  }

  /** ¿Hay ahora mismo una conexión viva con FreeSWITCH? */
  estaConectado(): boolean {
    return Boolean(this.connection?.connected?.());
  }

  private reintentar() {
    if (this.reconectando) return;
    this.reconectando = true;
    setTimeout(() => {
      this.reconectando = false;
      this.conectar().catch(() => undefined);
    }, 5000);
  }

  /** Ejecuta un comando de la consola de FreeSWITCH (fs_cli) vía ESL */
  async ejecutarComando(comando: string): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.connection || !this.connection.connected?.()) {
        return reject(new Error('Sin conexión activa a FreeSWITCH ESL'));
      }
      this.connection.api(comando, (res: any) => {
        resolve(res?.getBody?.() ?? '');
      });
    });
  }

  /** Recarga toda la configuración XML (directory, dialplan, sip_profiles includes) */
  async recargarXml(): Promise<void> {
    await this.ejecutarComando('reloadxml');
  }

  /** Fuerza a un perfil Sofia a releer sus gateways sin reiniciar el perfil entero */
  async recargarGateways(perfil = 'external'): Promise<void> {
    await this.ejecutarComando(`sofia profile ${perfil} rescan reloadxml`);
  }

  /**
   * Declara el dominio SIP de un tenant: conf/directory/<subdominio>.xml
   * Este fichero es lo que hace que cada tenant sea un dominio SIP
   * independiente dentro de FreeSWITCH (aislamiento real, no solo lógico),
   * incluyendo a su vez todos los usuarios/extensiones que viven en
   * conf/directory/<subdominio>/*.xml
   */
  async escribirDominioTenantXml(params: { subdominio: string; canalesMax: number }): Promise<void> {
    const dir = path.join(this.confPath(), 'directory');
    await fs.mkdir(dir, { recursive: true });
    await fs.mkdir(path.join(dir, params.subdominio), { recursive: true });
    const xml = `<include>
  <domain name="${this.dominioSipTenant(params.subdominio)}">
    <params>
      <param name="dial-string" value="\${sofia_contact(*/\${dialed_user}@\${dialed_domain})}"/>
    </params>
    <variables>
      <variable name="tenant_subdominio" value="${params.subdominio}"/>
      <variable name="max_channels" value="${params.canalesMax}"/>
    </variables>
    <groups>
      <group name="default">
        <users>
          <X-PRE-PROCESS cmd="include" data="${params.subdominio}/*.xml"/>
        </users>
      </group>
    </groups>
  </domain>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.subdominio}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarDominioTenantXml(subdominio: string): Promise<void> {
    await fs.rm(path.join(this.confPath(), 'directory', `${subdominio}.xml`), { force: true });
    await fs.rm(path.join(this.confPath(), 'directory', subdominio), { recursive: true, force: true });
    await this.recargarXml();
  }

  /**
   * Escribe el XML de <directory> para una extensión dentro de
   * conf/directory/<subdominio>/<numero>.xml
   */
  async escribirExtensionXml(params: {
    tenantId: string;
    subdominioTenant: string;
    numero: string;
    nombre: string;
    passwordPlano: string;
    codecs: string;
  }): Promise<void> {
    const dir = path.join(this.confPath(), 'directory', params.subdominioTenant);
    await fs.mkdir(dir, { recursive: true });
    const xml = `<include>
  <user id="${params.numero}">
    <params>
      <param name="password" value="${params.passwordPlano}"/>
    </params>
    <variables>
      <variable name="toll_allow" value="domestic,international,local"/>
      <!-- accountcode = UUID del tenant (no el subdominio): es lo que
           freeswitch-events.service.ts usa para atribuir cada CDR al
           tenant correcto en la tabla 'cdr' (cuya columna tenantId es un
           UUID, igual que en extensions/trunks). El subdominio sigue
           disponible aparte en tenant_subdominio para todo lo demás
           (dominio SIP, rutas de dialplan, etc.) -->
      <variable name="accountcode" value="${params.tenantId}"/>
      <variable name="tenant_subdominio" value="${params.subdominioTenant}"/>
      <!--
           user_context DEBE ser un contexto de dialplan que exista de verdad.
           Antes ponía "tenant_<subdominio>", un contexto que no genera nadie:
           en cuanto una extensión registrada descolgaba, FreeSWITCH buscaba
           ese contexto, no lo encontraba y tiraba la llamada. Ninguna llamada
           saliente ni interna podía funcionar.
           El aislamiento entre clientes NO depende de esto: lo garantizan la
           variable tenant_subdominio (que filtra la ruta saliente de cada
           cliente) y el bridge a user/<ext>@<dominio del propio tenant>. -->
      <variable name="user_context" value="default"/>
      <variable name="effective_caller_id_name" value="${params.nombre}"/>
      <variable name="effective_caller_id_number" value="${params.numero}"/>
      <variable name="codec_string" value="${params.codecs}"/>
    </variables>
  </user>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.numero}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarExtensionXml(subdominioTenant: string, numero: string): Promise<void> {
    const file = path.join(this.confPath(), 'directory', subdominioTenant, `${numero}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  /**
   * Escribe el XML de <gateway> de un trunk saliente/entrante dentro de
   * conf/sip_profiles/external/<nombre>.xml
   */
  async escribirTrunkXml(params: {
    nombre: string;
    host: string;
    puerto: number;
    usuario?: string;
    passwordPlano?: string;
  }): Promise<void> {
    const dir = path.join(this.confPath(), 'sip_profiles', 'external');
    await fs.mkdir(dir, { recursive: true });
    const xml = `<include>
  <gateway name="${params.nombre}">
    <param name="username" value="${params.usuario ?? params.nombre}"/>
    <param name="password" value="${params.passwordPlano ?? ''}"/>
    <param name="realm" value="${params.host}"/>
    <param name="proxy" value="${params.host}:${params.puerto}"/>
    <param name="register" value="${params.usuario ? 'true' : 'false'}"/>
    <param name="caller-id-in-from" value="true"/>
  </gateway>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.nombre}.xml`), xml, 'utf-8');
    await this.recargarGateways('external');
  }

  async eliminarTrunkXml(nombre: string): Promise<void> {
    const file = path.join(this.confPath(), 'sip_profiles', 'external', `${nombre}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarGateways('external');
  }

  // ---------------------------------------------------------------------
  // Helpers de nombres/escapado
  // ---------------------------------------------------------------------

  /**
   * Dominio SIP completo de un cliente: "acme" -> "acme.plataforma.local".
   *
   * Es el nombre con el que un teléfono se registra y con el que FreeSWITCH
   * separa a unos clientes de otros. Antes se usaba el subdominio a secas
   * ("acme") como dominio SIP, mientras la entidad Tenant, el panel y el
   * teléfono web documentaban y rellenaban el nombre completo: registrarse
   * como acme.plataforma.local fallaba siempre porque ese dominio no existía
   * dentro de FreeSWITCH. Ahora hay un único sitio que decide el formato.
   */
  dominioSipTenant(subdominio: string): string {
    const base = this.config.get<string>('FREESWITCH_DOMAIN', 'plataforma.local');
    return `${subdominio}.${base}`;
  }

  /** Escapa caracteres especiales de regex para poder usar un valor arbitrario dentro de un expression="^...$" */
  private escapeRegex(valor: string): string {
    return valor.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /**
   * Expresión regular tolerante para reconocer un DID entrante.
   *
   * Motivo: el mismo número llega escrito de formas distintas según el
   * proveedor. Un DID dado de alta como "34912345678" puede entrar como
   * "+34912345678", "0034912345678" o simplemente "912345678". Con una
   * comparación exacta, la llamada no casaba con ninguna ruta y se rechazaba
   * con un 404, que es de los fallos más desconcertantes de diagnosticar
   * porque el número "está dado de alta" y aun así no entra.
   *
   * Se aceptan sólo variantes predecibles (con/sin prefijo internacional y
   * con/sin "+" o "00"), no un comodín: dos DID distintos nunca deben poder
   * capturar la llamada del otro.
   */
  private expresionDidTolerante(numero: string): string {
    const digitos = numero.replace(/\D/g, '');
    if (!digitos) return `^${this.escapeRegex(numero)}$`;

    const pais = this.config.get<string>('FREESWITCH_PREFIJO_PAIS', '34');
    const variantes = new Set<string>([digitos]);

    if (pais && digitos.startsWith(pais) && digitos.length > pais.length) {
      variantes.add(digitos.slice(pais.length)); // forma nacional
    } else if (pais) {
      variantes.add(`${pais}${digitos}`); // forma internacional
    }

    const alternativas = [...variantes].map((v) => this.escapeRegex(v)).join('|');
    return `^\\+?(?:00)?(?:${alternativas})$`;
  }

  /** Nombre único (como destination_number interno) del menú de un IVR, usado para transfer/bridge internos */
  private nombreMenuIvr(ivrId: string): string {
    return `ivr_menu_${ivrId}`;
  }

  /** Nombre (solo informativo, para el atributo name="" de <extension>) de una opción de un IVR */
  private nombreOpcionIvr(ivrId: string, digito: string): string {
    return `ivr_opcion_${ivrId}_${digito}`;
  }

  /** Nombre de la variable de canal donde se guarda el dígito pulsado en un IVR concreto (evita colisiones entre IVRs) */
  private variableDigitoIvr(ivrId: string): string {
    return `ivr_digito_${ivrId.replace(/-/g, '')}`;
  }

  /** Nombre interno (destination_number) al que se transfiere para evaluar un horario */
  nombreHorario(horarioId: string): string {
    return `horario_${horarioId.replace(/-/g, '')}`;
  }

  // ---------------------------------------------------------------------
  // Horarios de oficina — traducción a condiciones de tiempo de FreeSWITCH
  // ---------------------------------------------------------------------

  /**
   * Convierte un rango de días en numeración ISO (1=lunes ... 7=domingo) a
   * los rangos CONTIGUOS que entiende FreeSWITCH (1=domingo ... 7=sábado).
   *
   * Hay dos trampas aquí:
   *  - La numeración no coincide, hay que desplazarla.
   *  - El rango puede dar la vuelta a la semana (ej. sábado a domingo, o
   *    viernes a lunes). FreeSWITCH no entiende un rango que envuelve, así
   *    que se devuelven varios trozos y se emite una condición por trozo.
   */
  private rangosWdayFreeswitch(diaInicioIso: number, diaFinIso: number): string[] {
    const aFs = (iso: number) => (iso % 7) + 1; // ISO 1(lun)->2 ... 7(dom)->1

    // Se expande el rango ISO día a día, dando la vuelta si hace falta.
    const diasIso: number[] = [];
    let dia = diaInicioIso;
    for (let i = 0; i < 7; i++) {
      diasIso.push(dia);
      if (dia === diaFinIso) break;
      dia = dia === 7 ? 1 : dia + 1;
    }

    const diasFs = [...new Set(diasIso.map(aFs))].sort((a, b) => a - b);

    // Se agrupan los días consecutivos en rangos "n-m" (o "n" si va solo).
    const rangos: string[] = [];
    let inicio = diasFs[0];
    let anterior = diasFs[0];
    for (const actual of diasFs.slice(1)) {
      if (actual === anterior + 1) {
        anterior = actual;
        continue;
      }
      rangos.push(inicio === anterior ? `${inicio}` : `${inicio}-${anterior}`);
      inicio = actual;
      anterior = actual;
    }
    rangos.push(inicio === anterior ? `${inicio}` : `${inicio}-${anterior}`);
    return rangos;
  }

  /**
   * Convierte "09:00"-"18:00" al formato time-of-day de FreeSWITCH.
   *
   * Si la franja cruza la medianoche (ej. de 22:00 a 06:00) se parte en dos,
   * porque FreeSWITCH tampoco admite un rango horario que dé la vuelta.
   */
  private rangosHoraFreeswitch(horaInicio: string, horaFin: string): string[] {
    const normalizar = (hora: string) => {
      const [h, m] = (hora || '00:00').split(':');
      const hh = String(Math.min(23, Math.max(0, Number(h) || 0))).padStart(2, '0');
      const mm = String(Math.min(59, Math.max(0, Number(m) || 0))).padStart(2, '0');
      return `${hh}:${mm}`;
    };

    const inicio = normalizar(horaInicio);
    const fin = normalizar(horaFin);

    if (inicio <= fin) return [`${inicio}:00-${fin}:59`];
    return [`${inicio}:00-23:59:59`, `00:00:00-${fin}:59`];
  }

  /**
   * Acciones de dialplan para un destino de centralita. Se comparte entre
   * horarios y números SIP para que todos los caminos de la llamada se
   * comporten igual.
   */
  private accionesDestino(params: {
    tipo: 'extension' | 'ivr' | 'anuncio' | 'buzon' | 'colgar';
    subdominioTenant: string;
    extensionNumero?: string;
    ivrId?: string;
    promptAbsoluto?: string;
  }): string {
    const { tipo, subdominioTenant, extensionNumero, ivrId, promptAbsoluto } = params;

    switch (tipo) {
      case 'ivr':
        if (!ivrId) break;
        return `      <action application="answer"/>
      <action application="transfer" data="${this.nombreMenuIvr(ivrId)} XML public"/>`;

      case 'extension':
        if (!extensionNumero) break;
        return `      <action application="set" data="hangup_after_bridge=true"/>
      <action application="bridge" data="user/${extensionNumero}@${this.dominioSipTenant(subdominioTenant)}"/>
      <action application="answer"/>
      <action application="sleep" data="1000"/>
      <action application="voicemail" data="default ${this.dominioSipTenant(subdominioTenant)} ${extensionNumero}"/>`;

      case 'anuncio':
        // Locución y colgar: el caso típico de "estamos cerrados".
        return `      <action application="answer"/>
      <action application="sleep" data="500"/>${
        promptAbsoluto ? `\n      <action application="playback" data="${promptAbsoluto}"/>` : ''
      }
      <action application="sleep" data="500"/>
      <action application="hangup" data="NORMAL_CLEARING"/>`;

      case 'buzon':
        // Locución (si la hay) y buzón de voz de la extensión indicada.
        if (!extensionNumero) break;
        return `      <action application="answer"/>
      <action application="sleep" data="500"/>${
        promptAbsoluto ? `\n      <action application="playback" data="${promptAbsoluto}"/>` : ''
      }
      <action application="voicemail" data="default ${this.dominioSipTenant(subdominioTenant)} ${extensionNumero}"/>`;

      case 'colgar':
        return `      <action application="answer"/>
      <action application="sleep" data="300"/>
      <action application="hangup" data="NORMAL_CLEARING"/>`;
    }

    // Destino incompleto o mal configurado: se deja constancia en el log en
    // vez de fallar en silencio, y se rechaza la llamada.
    return `      <action application="log" data="WARNING destino de centralita sin configurar (tipo=${tipo})"/>
      <action application="respond" data="404"/>`;
  }

  /**
   * Escribe el dialplan de un horario de oficina.
   *
   * Se genera una extensión por cada trozo de franja (días + horas). Si
   * ninguna casa con el momento en que entra la llamada, cae en la última,
   * que es la de "fuera de horario". FreeSWITCH evalúa las extensiones en
   * orden y salta a la siguiente cuando una condición no se cumple: por eso
   * el orden importa y la de fuera de horario va SIEMPRE la última.
   */
  async escribirHorarioXml(params: {
    horarioId: string;
    tenantId: string;
    subdominioTenant: string;
    franjas: Array<{ diaInicio: number; diaFin: number; horaInicio: string; horaFin: string }>;
    dentro: {
      tipo: 'extension' | 'ivr' | 'anuncio' | 'buzon' | 'colgar';
      extensionNumero?: string;
      ivrId?: string;
      promptAbsoluto?: string;
    };
    fuera: {
      tipo: 'extension' | 'ivr' | 'anuncio' | 'buzon' | 'colgar';
      extensionNumero?: string;
      ivrId?: string;
      promptAbsoluto?: string;
    };
  }): Promise<void> {
    const dir = this.dirDialplanPublicoDinamico();
    await fs.mkdir(dir, { recursive: true });

    const nombre = this.nombreHorario(params.horarioId);
    const accionesComunes = `      <action application="set" data="accountcode=${params.tenantId}"/>
      <action application="set" data="tenant_subdominio=${params.subdominioTenant}"/>`;

    const accionesDentro = this.accionesDestino({
      ...params.dentro,
      subdominioTenant: params.subdominioTenant,
    });
    const accionesFuera = this.accionesDestino({
      ...params.fuera,
      subdominioTenant: params.subdominioTenant,
    });

    const bloques: string[] = [];
    let indice = 0;
    for (const franja of params.franjas) {
      for (const wday of this.rangosWdayFreeswitch(franja.diaInicio, franja.diaFin)) {
        for (const horas of this.rangosHoraFreeswitch(franja.horaInicio, franja.horaFin)) {
          bloques.push(`  <extension name="${nombre}_dentro_${indice}">
    <condition field="destination_number" expression="^${nombre}$"/>
    <condition wday="${wday}" time-of-day="${horas}">
${accionesComunes}
${accionesDentro}
    </condition>
  </extension>`);
          indice++;
        }
      }
    }

    const xml = `<include>
  <!-- Horario de oficina. Las extensiones "_dentro_" se evalúan en orden;
       si ninguna coincide con el día y la hora de la llamada, esta cae en
       "_fuera", que no lleva condición de tiempo y por eso casa siempre. -->
${bloques.join('\n')}
  <extension name="${nombre}_fuera">
    <condition field="destination_number" expression="^${nombre}$">
${accionesComunes}
${accionesFuera}
    </condition>
  </extension>
</include>
`;
    await fs.writeFile(path.join(dir, `horario_${params.horarioId}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarHorarioXml(horarioId: string): Promise<void> {
    const fichero = path.join(this.dirDialplanPublicoDinamico(), `horario_${horarioId}.xml`);
    await fs.unlink(fichero).catch(() => undefined);
    await this.recargarXml();
  }

  // ---------------------------------------------------------------------
  // Números SIP (DIDs) — enrutamiento de llamadas entrantes
  // ---------------------------------------------------------------------

  private dirDialplanPublicoDinamico(): string {
    return path.join(this.confPath(), 'dialplan', 'public', 'dinamico');
  }

  /**
   * Escribe el dialplan dinámico para un número SIP (DID): al recibir una
   * llamada con ese destination_number en el contexto "public" (llamadas
   * entrantes desde trunks), la enruta a una extensión o a un IVR del
   * tenant al que está asignado el número.
   */
  async escribirDidXml(params: {
    numero: string;
    tenantId: string;
    subdominioTenant: string;
    destinoTipo: 'extension' | 'ivr' | 'horario';
    destinoExtensionNumero?: string;
    destinoIvrId?: string;
    destinoHorarioId?: string;
    trunkProveedorNombre?: string;
  }): Promise<void> {
    const dir = this.dirDialplanPublicoDinamico();
    await fs.mkdir(dir, { recursive: true });

    // Identificador legible para el atributo name="" (sólo informativo, es lo
    // que aparece en los logs). No se usa la versión escapada para regex
    // porque metía barras invertidas en el nombre: did_\+34912345678.
    const numeroId = params.numero.replace(/[^a-zA-Z0-9]/g, '_');
    const expresionDid = this.expresionDidTolerante(params.numero);
    // trunk_entrante: nombre del proveedor por el que llegó este número, usado
    // por freeswitch-events.service.ts para calcular el costo de compra de
    // llamadas entrantes (además del sip_gateway_name, que en llamadas
    // entrantes no siempre queda disponible de forma fiable).
    const accionesComunes = `      <action application="set" data="accountcode=${params.tenantId}"/>
      <action application="set" data="tenant_subdominio=${params.subdominioTenant}"/>
      <action application="set" data="call_direccion=entrante"/>${
        params.trunkProveedorNombre
          ? `\n      <action application="set" data="trunk_entrante=${params.trunkProveedorNombre}"/>`
          : ''
      }`;

    let accionDestino: string;
    if (params.destinoTipo === 'horario' && params.destinoHorarioId) {
      // El número entra por el horario de oficina: es él quien decide, según
      // el día y la hora, si suena la centralita o salta la locución.
      accionDestino = `      <action application="transfer" data="${this.nombreHorario(params.destinoHorarioId)} XML public"/>`;
    } else if (params.destinoTipo === 'ivr' && params.destinoIvrId) {
      accionDestino = `      <action application="answer"/>
      <action application="transfer" data="${this.nombreMenuIvr(params.destinoIvrId)} XML public"/>`;
    } else if (params.destinoTipo === 'extension' && params.destinoExtensionNumero) {
      accionDestino = `      <action application="set" data="hangup_after_bridge=true"/>
      <action application="bridge" data="user/${params.destinoExtensionNumero}@${this.dominioSipTenant(params.subdominioTenant)}"/>
      <action application="answer"/>
      <action application="sleep" data="1000"/>
      <action application="voicemail" data="default ${this.dominioSipTenant(params.subdominioTenant)} ${params.destinoExtensionNumero}"/>`;
    } else {
      accionDestino = `      <action application="log" data="WARNING DID ${params.numero} sin destino configurado"/>
      <action application="respond" data="404"/>`;
    }

    const xml = `<include>
  <extension name="did_${numeroId}">
    <condition field="destination_number" expression="${expresionDid}">
${accionesComunes}
${accionDestino}
    </condition>
  </extension>
</include>
`;
    await fs.writeFile(path.join(dir, `did_${params.numero.replace(/[^a-zA-Z0-9]/g, '_')}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarDidXml(numero: string): Promise<void> {
    const file = path.join(
      this.dirDialplanPublicoDinamico(),
      `did_${numero.replace(/[^a-zA-Z0-9]/g, '_')}.xml`,
    );
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  // ---------------------------------------------------------------------
  // IVR / respuestas automáticas
  // ---------------------------------------------------------------------

  /**
   * Escribe el dialplan dinámico de un IVR: una extensión "menú" que
   * contesta, reproduce la locución de bienvenida y pide un dígito
   * (play_and_get_digits), guardándolo en una variable de canal única para
   * este IVR; seguida de una extensión por cada opción configurada (a
   * extensión o a otro IVR = submenú) que compara esa variable, más una de
   * respaldo para dígitos no válidos que repite el menú.
   */
  async escribirIvrXml(params: {
    ivrId: string;
    tenantId: string;
    subdominioTenant: string;
    timeoutSegundos: number;
    promptAbsoluto?: string;
    opciones: Array<{
      digito: string;
      destinoTipo: 'extension' | 'ivr';
      destinoExtensionNumero?: string;
      destinoIvrId?: string;
    }>;
  }): Promise<void> {
    const dir = this.dirDialplanPublicoDinamico();
    await fs.mkdir(dir, { recursive: true });

    const prompt = params.promptAbsoluto ?? 'silence_stream://1000';
    const nombreMenu = this.nombreMenuIvr(params.ivrId);
    const varDigito = this.variableDigitoIvr(params.ivrId);
    const timeoutMs = Math.max(1, params.timeoutSegundos) * 1000;
    const accionesComunes = `      <action application="set" data="accountcode=${params.tenantId}"/>
      <action application="set" data="tenant_subdominio=${params.subdominioTenant}"/>`;

    const bloqueMenu = `  <extension name="${nombreMenu}" continue="true">
    <condition field="destination_number" expression="^${nombreMenu}$">
${accionesComunes}
      <action application="answer"/>
      <action application="play_and_get_digits" data="1 1 3 ${timeoutMs} # ${prompt} ${prompt} ${varDigito} \\d ${timeoutMs}"/>
    </condition>
  </extension>
`;

    const bloquesOpciones = params.opciones
      .map((op) => {
        const nombreOpcion = this.nombreOpcionIvr(params.ivrId, op.digito);
        let accion: string;
        if (op.destinoTipo === 'ivr' && op.destinoIvrId) {
          accion = `      <action application="transfer" data="${this.nombreMenuIvr(op.destinoIvrId)} XML public"/>`;
        } else if (op.destinoTipo === 'extension' && op.destinoExtensionNumero) {
          accion = `      <action application="set" data="hangup_after_bridge=true"/>
      <action application="bridge" data="user/${op.destinoExtensionNumero}@${this.dominioSipTenant(params.subdominioTenant)}"/>
      <action application="answer"/>
      <action application="sleep" data="1000"/>
      <action application="voicemail" data="default ${this.dominioSipTenant(params.subdominioTenant)} ${op.destinoExtensionNumero}"/>`;
        } else {
          accion = `      <action application="respond" data="404"/>`;
        }
        return `  <extension name="${nombreOpcion}">
    <condition field="\${${varDigito}}" expression="^${op.digito}$">
${accionesComunes}
${accion}
    </condition>
  </extension>
`;
      })
      .join('\n');

    // Respaldo: si no se pulsó ningún dígito válido (o se agotaron los
    // intentos de play_and_get_digits y la variable quedó vacía), se repite
    // el menú desde el principio. Esta extensión va SIEMPRE al final, tras
    // las opciones configuradas, para que actúe solo como último recurso.
    const xml = `<include>
${bloqueMenu}
${bloquesOpciones}
  <extension name="${nombreMenu}_repetir">
    <condition field="\${${varDigito}}" expression=".*">
${accionesComunes}
      <action application="transfer" data="${nombreMenu} XML public"/>
    </condition>
  </extension>
</include>
`;
    await fs.writeFile(path.join(dir, `ivr_${params.ivrId}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarIvrXml(ivrId: string): Promise<void> {
    const file = path.join(this.dirDialplanPublicoDinamico(), `ivr_${ivrId}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  // ---------------------------------------------------------------------
  // Enrutamiento saliente por tenant (LCR simple por prioridad de trunk)
  // ---------------------------------------------------------------------

  private dirDialplanDefaultDinamico(): string {
    return path.join(this.confPath(), 'dialplan', 'default', 'dinamico');
  }

  /**
   * Escribe/actualiza la ruta de salida de un tenant: al marcar un número
   * (contexto "default", el de las extensiones internas) se intenta cada
   * trunk activo disponible para ese tenant (propios primero, luego
   * compartidos), en orden de prioridad, uno tras otro (failover) hasta que
   * alguno complete la llamada.
   */
  async escribirRutaSalienteTenantXml(params: {
    tenantId: string;
    subdominioTenant: string;
    nombresTrunksOrdenados: string[];
  }): Promise<void> {
    const dir = this.dirDialplanDefaultDinamico();
    await fs.mkdir(dir, { recursive: true });

    if (params.nombresTrunksOrdenados.length === 0) {
      // Sin trunks disponibles: se elimina la ruta (si existía) para que la
      // llamada caiga en el manejo por defecto (normalmente "no route").
      await this.eliminarRutaSalienteTenantXml(params.subdominioTenant);
      return;
    }

    const bridgeString = params.nombresTrunksOrdenados
      .map((nombre) => `sofia/gateway/${nombre}/\${destination_number}`)
      .join('|');

    const xml = `<include>
  <extension name="saliente_${params.subdominioTenant}">
    <condition field="\${tenant_subdominio}" expression="^${params.subdominioTenant}$">
      <!--
           Numeración saliente. Se acepta cualquier número de 6 a 15 dígitos
           (nacional, móvil e internacional) MÁS los números cortos de
           emergencia, que son de 3 dígitos y por tanto chocarían con el
           rango de extensiones internas si no se listaran aquí. Como este
           fichero se evalúa ANTES que el de llamadas internas (00_ antes que
           01_), marcar 112 sale al exterior y no busca una extensión 112. -->
      <condition field="destination_number" expression="^(112|06[0-2]|08[0-5]|09[1-2]|\\d{6,15})$">
        <action application="set" data="accountcode=${params.tenantId}"/>
        <action application="set" data="call_direccion=saliente"/>
        <action application="set" data="hangup_after_bridge=true"/>
        <action application="bridge" data="${bridgeString}"/>
      </condition>
    </condition>
  </extension>
</include>
`;
    await fs.writeFile(path.join(dir, `saliente_${params.subdominioTenant}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarRutaSalienteTenantXml(subdominioTenant: string): Promise<void> {
    const file = path.join(this.dirDialplanDefaultDinamico(), `saliente_${subdominioTenant}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  // ---------------------------------------------------------------------
  // Locuciones (prompts de audio)
  // ---------------------------------------------------------------------

  /** Ruta (lado backend) a la carpeta de locuciones de un tenant, dentro del volumen compartido de prompts */
  rutaPromptsTenantBackend(subdominioTenant: string): string {
    const base = this.config.get<string>('FREESWITCH_PROMPTS_PATH_BACKEND', '/freeswitch-conf/prompts');
    return path.join(base, subdominioTenant);
  }

  /** Ruta absoluta (lado FreeSWITCH) a un fichero de locución concreto, para usar en <action application="playback"/> o similar */
  rutaPromptsTenantFreeswitch(subdominioTenant: string, archivoRelativo: string): string {
    const base = this.config.get<string>('FREESWITCH_PROMPTS_PATH_FS', '/etc/freeswitch/prompts');
    return path.join(base, subdominioTenant, archivoRelativo);
  }

  /** Ruta al volumen compartido de configuración de FreeSWITCH (montado en docker-compose) */
  private confPath(): string {
    return this.config.get<string>('FREESWITCH_CONF_PATH', '/freeswitch-conf');
  }
}
