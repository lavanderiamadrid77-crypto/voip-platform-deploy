#!/usr/bin/env bash
#
# Instala (o actualiza) el auto-despliegue. Se ejecuta una sola vez, desde la
# carpeta del proyecto:
#
#   bash scripts/instalar-autodespliegue.sh
#
# A partir de ahi, para publicar una version nueva basta con subir el paquete
# al repositorio y poner su nombre en despliegue.txt. El servidor la instala
# solo en menos de dos minutos.
set -euo pipefail

AQUI="$(cd "$(dirname "$0")" && pwd)"

# --- Memoria de intercambio -------------------------------------------------
# Este servidor tiene 4 GB y ningun swap. En reposo sobra, pero reconstruir los
# contenedores (npm install + tsc + vite, con FreeSWITCH y PostgreSQL en
# marcha) dispara el consumo, y sin swap el nucleo no ralentiza: mata procesos.
# Ya paso una vez, y el log del sistema lo dejo por escrito:
#   "Out of memory: Killed process (freeswitch)"
# Un fichero de intercambio convierte ese fallo brusco en algo que solo va mas
# lento. Es idempotente: si ya existe, no se toca.
if [ "$(swapon --show --noheadings | wc -l)" -eq 0 ]; then
  if [ ! -f /swapfile ]; then
    echo "Creando 2 GB de memoria de intercambio..."
    fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
    chmod 600 /swapfile
    mkswap /swapfile >/dev/null
  fi
  swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || printf '/swapfile none swap sw 0 0\n' >> /etc/fstab
  echo "Memoria de intercambio activada."
else
  echo "Ya hay memoria de intercambio configurada."
fi

install -m 755 "$AQUI/autodespliegue.sh" /usr/local/bin/autodespliegue.sh
install -m 644 "$AQUI/voip-autodespliegue.service" /etc/systemd/system/voip-autodespliegue.service
install -m 644 "$AQUI/voip-autodespliegue.timer" /etc/systemd/system/voip-autodespliegue.timer

systemctl daemon-reload
systemctl enable --now voip-autodespliegue.timer

echo
echo "Auto-despliegue instalado. Estado del temporizador:"
systemctl list-timers voip-autodespliegue.timer --no-pager || true
echo
echo "Registro del ultimo despliegue: http://$(curl -fsS --max-time 8 https://ifconfig.me 2>/dev/null || echo IP-DEL-SERVIDOR):8090/despliegue.log"
