// Cliente API mínimo. La URL base se toma de una variable de entorno de
// Vite (VITE_API_URL) para que el mismo build sirva tanto en desarrollo
// como apuntando al backend real desplegado en la VM.
const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000';

export { API_URL };

function token(): string | null {
  return localStorage.getItem('voip_token');
}

export function guardarToken(t: string) {
  localStorage.setItem('voip_token', t);
}

export function borrarToken() {
  localStorage.removeItem('voip_token');
}

export function hayToken(): boolean {
  return !!token();
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  };
  const t = token();
  if (t) headers.Authorization = `Bearer ${t}`;

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });
  if (res.status === 401) {
    borrarToken();
    window.location.href = '/login';
    throw new Error('Sesión expirada');
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message ?? `Error ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

/** Sube un FormData (ej. un audio) sin fijar Content-Type manualmente, para que el navegador ponga el boundary correcto. */
async function postForm<T>(path: string, form: FormData): Promise<T> {
  const headers: Record<string, string> = {};
  const t = token();
  if (t) headers.Authorization = `Bearer ${t}`;
  const res = await fetch(`${API_URL}${path}`, { method: 'POST', headers, body: form });
  if (res.status === 401) {
    borrarToken();
    window.location.href = '/login';
    throw new Error('Sesión expirada');
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message ?? `Error ${res.status}`);
  }
  return res.json() as Promise<T>;
}

/** Descarga un recurso protegido (ej. un audio) como blob URL, adjuntando el token manualmente (los <audio>/<a> no lo hacen). */
async function getBlobUrl(path: string): Promise<string> {
  const headers: Record<string, string> = {};
  const t = token();
  if (t) headers.Authorization = `Bearer ${t}`;
  const res = await fetch(`${API_URL}${path}`, { headers });
  if (!res.ok) throw new Error(`Error ${res.status}`);
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined }),
  postForm,
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'PATCH', body: body ? JSON.stringify(body) : undefined }),
  delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
  getBlobUrl,
};
