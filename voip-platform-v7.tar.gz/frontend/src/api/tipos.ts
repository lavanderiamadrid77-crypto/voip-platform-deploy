export type Rol = 'super_admin' | 'admin' | 'reseller' | 'usuario';

export interface UsuarioSesion {
  id: string;
  email: string;
  rol: Rol;
  tenantId?: string;
  idiomaPreferido: string;
}

export interface Tenant {
  id: string;
  nombre: string;
  subdominio: string;
  colorPrimario: string;
  canalesMax: number;
  extensionesMax: number;
  retencionGrabacionesDias: number;
  activo: boolean;
  creadoEn: string;
}

export type TipoExtension =
  | 'escritorio'
  | 'softphone'
  | 'movil'
  | 'ring_group'
  | 'cola'
  | 'ivr'
  | 'buzon'
  | 'conferencia';

export interface Extension {
  id: string;
  tenantId: string;
  numero: string;
  nombre: string;
  tipo: TipoExtension;
  codecs: string;
  webrtcHabilitado: boolean;
  activo: boolean;
  creadoEn: string;
}

export interface Trunk {
  id: string;
  tenantId?: string;
  nombre: string;
  proveedor: string;
  host: string;
  puerto: number;
  usuario?: string;
  prioridad: number;
  costoPorMinuto: number;
  activo: boolean;
  creadoEn: string;
}

export interface Cdr {
  id: string;
  tenantId: string;
  origen: string;
  destino: string;
  fechaHoraInicio: string;
  duracionSegundos: number;
  estado: string;
  costo: number;
  venta?: number;
  trunkUsado?: string;
  direccion?: 'entrante' | 'saliente' | 'interna';
}

export type DidDestinoTipo = 'extension' | 'ivr' | 'ninguno';

export interface Did {
  id: string;
  numero: string;
  descripcion?: string;
  tenantId?: string;
  trunkProveedorId?: string;
  destinoTipo: DidDestinoTipo;
  destinoId?: string;
  activo: boolean;
  creadoEn: string;
}

export interface AudioPrompt {
  id: string;
  tenantId: string;
  nombre: string;
  archivoRelativo: string;
  duracionSegundos?: number;
  creadoEn: string;
}

export type IvrOpcionDestinoTipo = 'extension' | 'ivr';

export interface IvrOption {
  id: string;
  ivrId: string;
  digito: string;
  destinoTipo: IvrOpcionDestinoTipo;
  destinoId: string;
  etiqueta?: string;
}

export interface Ivr {
  id: string;
  tenantId: string;
  nombre: string;
  promptBienvenidaId?: string;
  timeoutSegundos: number;
  opciones: IvrOption[];
  activo: boolean;
  creadoEn: string;
}

export interface BuyRate {
  id: string;
  trunkId: string;
  prefijo: string;
  descripcion?: string;
  precioPorMinuto: number;
  activo: boolean;
  creadoEn: string;
}

export interface SellRate {
  id: string;
  tenantId?: string;
  prefijo: string;
  descripcion?: string;
  precioPorMinuto: number;
  activo: boolean;
  creadoEn: string;
}
