import { FormEvent, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api/client';
import { BuyRate, SellRate, Tenant, Trunk } from '../api/tipos';

/**
 * Tarifas: lo que pagamos a cada proveedor por minuto (compra) y lo que le
 * cobramos a cada cliente (venta). La coincidencia es por prefijo del
 * número destino (estilo LCR): "34" es más genérico que "34911", y gana
 * siempre el prefijo más largo que coincida. Un prefijo vacío es la
 * tarifa "por defecto" (catch-all) para ese proveedor o cliente.
 */
export function RatesPage() {
  const [params] = useSearchParams();
  const [tab, setTab] = useState<'compra' | 'venta'>('compra');
  const [trunks, setTrunks] = useState<Trunk[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);

  useEffect(() => {
    api.get<Trunk[]>('/api/trunks').then(setTrunks);
    api.get<Tenant[]>('/api/tenants').then(setTenants);
  }, []);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">Tarifas</h1>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">
          Las tarifas de <strong>compra</strong> son lo que te cobra cada proveedor por minuto. Las de{' '}
          <strong>venta</strong> son lo que le cobras tú a cada cliente. El margen es la diferencia entre ambas.
        </p>
      </div>

      <div className="flex gap-2 border-b border-slate-200 dark:border-slate-700">
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 ${
            tab === 'compra' ? 'border-marca text-marca' : 'border-transparent text-slate-500'
          }`}
          onClick={() => setTab('compra')}
        >
          Tarifas de compra (proveedores)
        </button>
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 ${
            tab === 'venta' ? 'border-marca text-marca' : 'border-transparent text-slate-500'
          }`}
          onClick={() => setTab('venta')}
        >
          Tarifas de venta (clientes)
        </button>
      </div>

      {tab === 'compra' ? (
        <SeccionCompra trunks={trunks} />
      ) : (
        <SeccionVenta tenants={tenants} tenantIdInicial={params.get('tenantId') ?? ''} />
      )}
    </div>
  );
}

function SeccionCompra({ trunks }: { trunks: Trunk[] }) {
  const [tarifas, setTarifas] = useState<BuyRate[]>([]);
  const [filtroTrunk, setFiltroTrunk] = useState('');
  const [trunkId, setTrunkId] = useState('');
  const [prefijo, setPrefijo] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [precio, setPrecio] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function cargar() {
    const qs = filtroTrunk ? `?trunkId=${filtroTrunk}` : '';
    setTarifas(await api.get<BuyRate[]>(`/api/tarifas/compra${qs}`));
  }

  useEffect(() => {
    cargar().catch((e) => setError(e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtroTrunk]);

  async function crear(e: FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api.post('/api/tarifas/compra', {
        trunkId,
        prefijo: prefijo || undefined,
        descripcion: descripcion || undefined,
        precioPorMinuto: Number(precio),
      });
      setPrefijo('');
      setDescripcion('');
      setPrecio('');
      await cargar();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creando la tarifa');
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/tarifas/compra/${id}`);
    await cargar();
  }

  function nombreTrunk(id: string) {
    return trunks.find((t) => t.id === id)?.nombre ?? id;
  }

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={crear} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex gap-3 items-end flex-wrap">
        <label className="flex flex-col text-sm gap-1">
          Proveedor
          <select
            required
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={trunkId}
            onChange={(e) => setTrunkId(e.target.value)}
          >
            <option value="">Elegir…</option>
            {trunks.map((tk) => (
              <option key={tk.id} value={tk.id}>
                {tk.nombre}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col text-sm gap-1">
          Prefijo destino
          <input
            placeholder="34 (vacío = todos)"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 w-40"
            value={prefijo}
            onChange={(e) => setPrefijo(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          Descripción
          <input
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={descripcion}
            onChange={(e) => setDescripcion(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          €/minuto
          <input
            required
            type="number"
            step="0.00001"
            min="0"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 w-32"
            value={precio}
            onChange={(e) => setPrecio(e.target.value)}
          />
        </label>
        <button className="bg-marca text-white rounded-md px-4 py-2 h-fit">Añadir tarifa</button>
      </form>

      <label className="text-sm flex flex-col gap-1 max-w-xs">
        Filtrar por proveedor
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
          value={filtroTrunk}
          onChange={(e) => setFiltroTrunk(e.target.value)}
        >
          <option value="">Todos</option>
          {trunks.map((tk) => (
            <option key={tk.id} value={tk.id}>
              {tk.nombre}
            </option>
          ))}
        </select>
      </label>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Proveedor</th>
            <th className="p-2">Prefijo</th>
            <th className="p-2">Descripción</th>
            <th className="p-2">€/minuto</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody>
          {tarifas.map((tr) => (
            <tr key={tr.id} className="border-t border-slate-100 dark:border-slate-700">
              <td className="p-2">{nombreTrunk(tr.trunkId)}</td>
              <td className="p-2 font-mono">{tr.prefijo || '(todos)'}</td>
              <td className="p-2">{tr.descripcion ?? '—'}</td>
              <td className="p-2">{Number(tr.precioPorMinuto).toFixed(5)}</td>
              <td className="p-2">
                <button className="text-red-600 hover:underline" onClick={() => eliminar(tr.id)}>
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
          {tarifas.length === 0 && (
            <tr>
              <td colSpan={5} className="p-4 text-center text-slate-500">
                No hay tarifas de compra todavía.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

function SeccionVenta({ tenants, tenantIdInicial }: { tenants: Tenant[]; tenantIdInicial: string }) {
  const [tarifas, setTarifas] = useState<SellRate[]>([]);
  const [filtroTenant, setFiltroTenant] = useState(tenantIdInicial);
  const [tenantId, setTenantId] = useState(tenantIdInicial);
  const [prefijo, setPrefijo] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [precio, setPrecio] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function cargar() {
    const qs = filtroTenant ? `?tenantId=${filtroTenant}` : '';
    setTarifas(await api.get<SellRate[]>(`/api/tarifas/venta${qs}`));
  }

  useEffect(() => {
    cargar().catch((e) => setError(e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtroTenant]);

  async function crear(e: FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api.post('/api/tarifas/venta', {
        tenantId: tenantId || undefined,
        prefijo: prefijo || undefined,
        descripcion: descripcion || undefined,
        precioPorMinuto: Number(precio),
      });
      setPrefijo('');
      setDescripcion('');
      setPrecio('');
      await cargar();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creando la tarifa');
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/tarifas/venta/${id}`);
    await cargar();
  }

  function nombreTenant(id?: string) {
    if (!id) return 'Todos los clientes (tarifa global)';
    return tenants.find((t) => t.id === id)?.nombre ?? id;
  }

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={crear} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex gap-3 items-end flex-wrap">
        <label className="flex flex-col text-sm gap-1">
          Cliente
          <select
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={tenantId}
            onChange={(e) => setTenantId(e.target.value)}
          >
            <option value="">Todos (tarifa global por defecto)</option>
            {tenants.map((tn) => (
              <option key={tn.id} value={tn.id}>
                {tn.nombre}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col text-sm gap-1">
          Prefijo destino
          <input
            placeholder="34 (vacío = todos)"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 w-40"
            value={prefijo}
            onChange={(e) => setPrefijo(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          Descripción
          <input
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={descripcion}
            onChange={(e) => setDescripcion(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-sm gap-1">
          €/minuto
          <input
            required
            type="number"
            step="0.00001"
            min="0"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 w-32"
            value={precio}
            onChange={(e) => setPrecio(e.target.value)}
          />
        </label>
        <button className="bg-marca text-white rounded-md px-4 py-2 h-fit">Añadir tarifa</button>
      </form>

      <label className="text-sm flex flex-col gap-1 max-w-xs">
        Filtrar por cliente
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
          value={filtroTenant}
          onChange={(e) => setFiltroTenant(e.target.value)}
        >
          <option value="">Todos (incluye la tarifa global)</option>
          {tenants.map((tn) => (
            <option key={tn.id} value={tn.id}>
              {tn.nombre}
            </option>
          ))}
        </select>
      </label>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Cliente</th>
            <th className="p-2">Prefijo</th>
            <th className="p-2">Descripción</th>
            <th className="p-2">€/minuto</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody>
          {tarifas.map((tr) => (
            <tr key={tr.id} className="border-t border-slate-100 dark:border-slate-700">
              <td className="p-2">{nombreTenant(tr.tenantId)}</td>
              <td className="p-2 font-mono">{tr.prefijo || '(todos)'}</td>
              <td className="p-2">{tr.descripcion ?? '—'}</td>
              <td className="p-2">{Number(tr.precioPorMinuto).toFixed(5)}</td>
              <td className="p-2">
                <button className="text-red-600 hover:underline" onClick={() => eliminar(tr.id)}>
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
          {tarifas.length === 0 && (
            <tr>
              <td colSpan={5} className="p-4 text-center text-slate-500">
                No hay tarifas de venta todavía.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
