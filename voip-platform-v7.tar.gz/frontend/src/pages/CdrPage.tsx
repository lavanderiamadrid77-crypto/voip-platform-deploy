import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { Cdr, Tenant } from '../api/tipos';
import { useI18n } from '../i18n';

export function CdrPage() {
  const { t } = useI18n();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [tenantId, setTenantId] = useState('');
  const [filas, setFilas] = useState<Cdr[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.get<Tenant[]>('/api/tenants').then((t) => {
      setTenants(t);
      if (t[0]) setTenantId(t[0].id);
    });
  }, []);

  useEffect(() => {
    if (!tenantId) return;
    api
      .get<Cdr[]>(`/api/cdr?tenantId=${tenantId}&limite=200`)
      .then(setFilas)
      .catch((e) => setError(e.message));
  }, [tenantId]);

  function exportarCsv() {
    const encabezado = 'fecha,direccion,origen,destino,duracion_segundos,estado,costo,venta,margen,trunk\n';
    const cuerpo = filas
      .map((f) =>
        [
          f.fechaHoraInicio,
          f.direccion ?? '',
          f.origen,
          f.destino,
          f.duracionSegundos,
          f.estado,
          f.costo,
          f.venta ?? 0,
          Number(((f.venta ?? 0) - f.costo).toFixed(5)),
          f.trunkUsado ?? '',
        ].join(','),
      )
      .join('\n');
    const blob = new Blob([encabezado + cuerpo], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cdr_${tenantId}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{t('cdr')}</h1>
        <button onClick={exportarCsv} className="text-sm bg-marca text-white rounded-md px-3 py-2">
          Exportar CSV
        </button>
      </div>

      <label className="text-sm flex flex-col gap-1 max-w-xs">
        Cliente (tenant)
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
          value={tenantId}
          onChange={(e) => setTenantId(e.target.value)}
        >
          {tenants.map((tn) => (
            <option key={tn.id} value={tn.id}>
              {tn.nombre}
            </option>
          ))}
        </select>
      </label>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Fecha</th>
            <th className="p-2">Dirección</th>
            <th className="p-2">Origen</th>
            <th className="p-2">Destino</th>
            <th className="p-2">Duración</th>
            <th className="p-2">Estado</th>
            <th className="p-2">Costo (compra)</th>
            <th className="p-2">Venta</th>
            <th className="p-2">Margen</th>
          </tr>
        </thead>
        <tbody>
          {filas.map((c) => (
            <tr key={c.id} className="border-t border-slate-100 dark:border-slate-700">
              <td className="p-2">{new Date(c.fechaHoraInicio).toLocaleString()}</td>
              <td className="p-2">{c.direccion ?? '—'}</td>
              <td className="p-2">{c.origen}</td>
              <td className="p-2">{c.destino}</td>
              <td className="p-2">{c.duracionSegundos}s</td>
              <td className="p-2">{c.estado}</td>
              <td className="p-2">{Number(c.costo).toFixed(5)}</td>
              <td className="p-2">{Number(c.venta ?? 0).toFixed(5)}</td>
              <td className="p-2">{Number((c.venta ?? 0) - c.costo).toFixed(5)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
