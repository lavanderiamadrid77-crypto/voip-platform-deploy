import { FormEvent, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api/client';
import { AudioPrompt, Extension, Ivr, IvrOpcionDestinoTipo, Tenant } from '../api/tipos';

interface OpcionForm {
  digito: string;
  destinoTipo: IvrOpcionDestinoTipo;
  destinoId: string;
  etiqueta: string;
}

const opcionVacia = (): OpcionForm => ({ digito: '', destinoTipo: 'extension', destinoId: '', etiqueta: '' });

/**
 * Página combinada de "Locuciones" (grabaciones de voz que el cliente puede
 * grabar desde el navegador o subir) y de "IVR" (respuestas automáticas):
 * menús de "pulse 1 para..." que usan esas locuciones como saludo.
 */
export function IvrPage() {
  const [params] = useSearchParams();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [tenantId, setTenantId] = useState('');
  const [prompts, setPrompts] = useState<AudioPrompt[]>([]);
  const [extensiones, setExtensiones] = useState<Extension[]>([]);
  const [ivrs, setIvrs] = useState<Ivr[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.get<Tenant[]>('/api/tenants').then((t) => {
      setTenants(t);
      const inicial = params.get('tenantId');
      if (inicial && t.some((tn) => tn.id === inicial)) setTenantId(inicial);
      else if (t[0]) setTenantId(t[0].id);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function cargarTodo(id: string) {
    if (!id) return;
    const [p, e, i] = await Promise.all([
      api.get<AudioPrompt[]>(`/api/tenants/${id}/locuciones`),
      api.get<Extension[]>(`/api/tenants/${id}/extensions`),
      api.get<Ivr[]>(`/api/tenants/${id}/ivrs`),
    ]);
    setPrompts(p);
    setExtensiones(e);
    setIvrs(i);
  }

  useEffect(() => {
    cargarTodo(tenantId).catch((e) => setError(e.message));
  }, [tenantId]);

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-2xl font-semibold">IVR y locuciones</h1>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">
          Graba o sube los mensajes de voz de tu cliente ("locuciones") y arma menús de respuesta automática ("pulse 1
          para ventas, 2 para soporte...") que se reproducen al llamar.
        </p>
      </div>

      <label className="text-sm flex flex-col gap-1 max-w-xs">
        Cliente
        <select
          className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
          value={tenantId}
          onChange={(e) => setTenantId(e.target.value)}
        >
          {tenants.map((tn) => (
            <option key={tn.id} value={tn.id}>
              {tn.nombre}
            </option>
          ))}
        </select>
      </label>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      {tenantId && (
        <>
          <SeccionLocuciones tenantId={tenantId} prompts={prompts} onCambio={() => cargarTodo(tenantId)} />
          <SeccionIvrs
            tenantId={tenantId}
            ivrs={ivrs}
            prompts={prompts}
            extensiones={extensiones}
            onCambio={() => cargarTodo(tenantId)}
          />
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------
// Locuciones
// ---------------------------------------------------------------------

function SeccionLocuciones({
  tenantId,
  prompts,
  onCambio,
}: {
  tenantId: string;
  prompts: AudioPrompt[];
  onCambio: () => void;
}) {
  const [nombre, setNombre] = useState('');
  const [archivo, setArchivo] = useState<File | null>(null);
  const [grabando, setGrabando] = useState(false);
  const [audioGrabado, setAudioGrabado] = useState<Blob | null>(null);
  const [urlPreview, setUrlPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [subiendo, setSubiendo] = useState(false);
  const [reproduciendoId, setReproduciendoId] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  async function iniciarGrabacion() {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunksRef.current = [];
      mr.ondataavailable = (e) => chunksRef.current.push(e.data);
      mr.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mr.mimeType || 'audio/webm' });
        setAudioGrabado(blob);
        setUrlPreview(URL.createObjectURL(blob));
        stream.getTracks().forEach((tr) => tr.stop());
      };
      mr.start();
      mediaRecorderRef.current = mr;
      setGrabando(true);
      setAudioGrabado(null);
      setUrlPreview(null);
    } catch (err) {
      setError('No se pudo acceder al micrófono. Revisa los permisos del navegador.');
    }
  }

  function detenerGrabacion() {
    mediaRecorderRef.current?.stop();
    setGrabando(false);
  }

  async function guardarGrabacion() {
    if (!audioGrabado) return;
    setError(null);
    setSubiendo(true);
    try {
      const form = new FormData();
      form.append('nombre', nombre || 'Locución grabada');
      form.append('audio', audioGrabado, 'grabacion.webm');
      await api.postForm(`/api/tenants/${tenantId}/locuciones`, form);
      setNombre('');
      setAudioGrabado(null);
      setUrlPreview(null);
      onCambio();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error guardando la grabación');
    } finally {
      setSubiendo(false);
    }
  }

  async function subirArchivo(e: FormEvent) {
    e.preventDefault();
    if (!archivo) return;
    setError(null);
    setSubiendo(true);
    try {
      const form = new FormData();
      form.append('nombre', nombre || archivo.name);
      form.append('audio', archivo);
      await api.postForm(`/api/tenants/${tenantId}/locuciones`, form);
      setNombre('');
      setArchivo(null);
      onCambio();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error subiendo el audio');
    } finally {
      setSubiendo(false);
    }
  }

  async function reproducir(id: string) {
    setReproduciendoId(id);
    try {
      const url = await api.getBlobUrl(`/api/tenants/${tenantId}/locuciones/${id}/audio`);
      const audio = new Audio(url);
      audio.play();
      audio.onended = () => setReproduciendoId(null);
    } catch (err) {
      setError('No se pudo reproducir la locución');
      setReproduciendoId(null);
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/tenants/${tenantId}/locuciones/${id}`);
    onCambio();
  }

  return (
    <section className="flex flex-col gap-4">
      <h2 className="text-lg font-medium">Locuciones</h2>

      <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex flex-col gap-4">
        <label className="flex flex-col text-sm gap-1 max-w-sm">
          Nombre de la locución
          <input
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            placeholder="Ej: Saludo de bienvenida"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
          />
        </label>

        <div className="flex gap-3 items-center flex-wrap">
          {!grabando ? (
            <button
              type="button"
              onClick={iniciarGrabacion}
              className="bg-marca text-white rounded-md px-4 py-2 flex items-center gap-2"
            >
              🎙️ Grabar desde el navegador
            </button>
          ) : (
            <button
              type="button"
              onClick={detenerGrabacion}
              className="bg-red-600 text-white rounded-md px-4 py-2 animate-pulse"
            >
              ⏹ Detener grabación
            </button>
          )}

          {urlPreview && (
            <>
              <audio controls src={urlPreview} className="h-9" />
              <button
                type="button"
                disabled={subiendo}
                onClick={guardarGrabacion}
                className="bg-emerald-600 text-white rounded-md px-4 py-2"
              >
                Guardar grabación
              </button>
            </>
          )}
        </div>

        <form onSubmit={subirArchivo} className="flex gap-3 items-end flex-wrap border-t border-slate-100 dark:border-slate-700 pt-4">
          <label className="flex flex-col text-sm gap-1">
            O sube un archivo de audio
            <input
              type="file"
              accept="audio/*"
              onChange={(e) => setArchivo(e.target.files?.[0] ?? null)}
              className="text-sm"
            />
          </label>
          <button disabled={!archivo || subiendo} className="bg-marca text-white rounded-md px-4 py-2 h-fit">
            Subir
          </button>
        </form>

        {error && <p className="text-red-600 text-sm">{error}</p>}
      </div>

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Nombre</th>
            <th className="p-2">Creada</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody>
          {prompts.map((p) => (
            <tr key={p.id} className="border-t border-slate-100 dark:border-slate-700">
              <td className="p-2">{p.nombre}</td>
              <td className="p-2">{new Date(p.creadoEn).toLocaleString()}</td>
              <td className="p-2 flex gap-3">
                <button className="text-marca hover:underline" onClick={() => reproducir(p.id)}>
                  {reproduciendoId === p.id ? 'Reproduciendo…' : '▶ Reproducir'}
                </button>
                <button className="text-red-600 hover:underline" onClick={() => eliminar(p.id)}>
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
          {prompts.length === 0 && (
            <tr>
              <td colSpan={3} className="p-4 text-center text-slate-500">
                Todavía no hay locuciones para este cliente.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </section>
  );
}

// ---------------------------------------------------------------------
// IVR (respuestas automáticas)
// ---------------------------------------------------------------------

function SeccionIvrs({
  tenantId,
  ivrs,
  prompts,
  extensiones,
  onCambio,
}: {
  tenantId: string;
  ivrs: Ivr[];
  prompts: AudioPrompt[];
  extensiones: Extension[];
  onCambio: () => void;
}) {
  const [editandoId, setEditandoId] = useState<string | 'nuevo' | null>(null);
  const [nombre, setNombre] = useState('');
  const [promptBienvenidaId, setPromptBienvenidaId] = useState('');
  const [timeoutSegundos, setTimeoutSegundos] = useState(7);
  const [opciones, setOpciones] = useState<OpcionForm[]>([opcionVacia()]);
  const [error, setError] = useState<string | null>(null);
  const [guardando, setGuardando] = useState(false);

  function empezarNuevo() {
    setEditandoId('nuevo');
    setNombre('');
    setPromptBienvenidaId('');
    setTimeoutSegundos(7);
    setOpciones([opcionVacia()]);
    setError(null);
  }

  function empezarEdicion(ivr: Ivr) {
    setEditandoId(ivr.id);
    setNombre(ivr.nombre);
    setPromptBienvenidaId(ivr.promptBienvenidaId ?? '');
    setTimeoutSegundos(ivr.timeoutSegundos);
    setOpciones(
      ivr.opciones.length
        ? ivr.opciones.map((o) => ({
            digito: o.digito,
            destinoTipo: o.destinoTipo,
            destinoId: o.destinoId,
            etiqueta: o.etiqueta ?? '',
          }))
        : [opcionVacia()],
    );
    setError(null);
  }

  function cancelar() {
    setEditandoId(null);
  }

  async function guardar(e: FormEvent) {
    e.preventDefault();
    setError(null);
    const opcionesValidas = opciones.filter((o) => o.digito && o.destinoId);
    if (opcionesValidas.length === 0) {
      setError('Añade al menos una opción de menú (dígito + destino)');
      return;
    }
    setGuardando(true);
    try {
      const dto = {
        nombre,
        promptBienvenidaId: promptBienvenidaId || undefined,
        timeoutSegundos,
        opciones: opcionesValidas.map((o) => ({
          digito: o.digito,
          destinoTipo: o.destinoTipo,
          destinoId: o.destinoId,
          etiqueta: o.etiqueta || undefined,
        })),
      };
      if (editandoId === 'nuevo') {
        await api.post(`/api/tenants/${tenantId}/ivrs`, dto);
      } else if (editandoId) {
        await api.patch(`/api/tenants/${tenantId}/ivrs/${editandoId}`, dto);
      }
      setEditandoId(null);
      onCambio();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error guardando el IVR');
    } finally {
      setGuardando(false);
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/tenants/${tenantId}/ivrs/${id}`);
    onCambio();
  }

  function actualizarOpcion(idx: number, cambios: Partial<OpcionForm>) {
    setOpciones((prev) => prev.map((o, i) => (i === idx ? { ...o, ...cambios } : o)));
  }

  function quitarOpcion(idx: number) {
    setOpciones((prev) => prev.filter((_, i) => i !== idx));
  }

  const ivrsDisponiblesParaSubmenu = ivrs.filter((i) => i.id !== editandoId);

  return (
    <section className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-medium">IVR / respuestas automáticas</h2>
        {editandoId === null && (
          <button onClick={empezarNuevo} className="bg-marca text-white rounded-md px-4 py-2 text-sm">
            + Nuevo IVR
          </button>
        )}
      </div>

      {editandoId !== null && (
        <form onSubmit={guardar} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex flex-col gap-4">
          <div className="flex gap-3 flex-wrap items-end">
            <label className="flex flex-col text-sm gap-1">
              Nombre del menú
              <input
                required
                placeholder="Ej: Menú principal"
                className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
              />
            </label>
            <label className="flex flex-col text-sm gap-1">
              Locución de bienvenida
              <select
                className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
                value={promptBienvenidaId}
                onChange={(e) => setPromptBienvenidaId(e.target.value)}
              >
                <option value="">(silencio / sin locución)</option>
                {prompts.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.nombre}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col text-sm gap-1">
              Espera del dígito (segundos)
              <input
                type="number"
                min={1}
                className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 w-24"
                value={timeoutSegundos}
                onChange={(e) => setTimeoutSegundos(Number(e.target.value))}
              />
            </label>
          </div>

          <div className="flex flex-col gap-2">
            <div className="text-sm font-medium">Opciones del menú</div>
            {opciones.map((op, idx) => (
              <div key={idx} className="flex gap-2 items-end flex-wrap bg-slate-50 dark:bg-slate-900 rounded-md p-3">
                <label className="flex flex-col text-xs gap-1">
                  Pulsa
                  <select
                    className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1 w-16"
                    value={op.digito}
                    onChange={(e) => actualizarOpcion(idx, { digito: e.target.value })}
                  >
                    <option value="">–</option>
                    {['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="flex flex-col text-xs gap-1">
                  Va a
                  <select
                    className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                    value={op.destinoTipo}
                    onChange={(e) =>
                      actualizarOpcion(idx, { destinoTipo: e.target.value as IvrOpcionDestinoTipo, destinoId: '' })
                    }
                  >
                    <option value="extension">Extensión</option>
                    <option value="ivr">Otro IVR (submenú)</option>
                  </select>
                </label>
                <label className="flex flex-col text-xs gap-1 min-w-[10rem]">
                  Destino
                  <select
                    className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                    value={op.destinoId}
                    onChange={(e) => actualizarOpcion(idx, { destinoId: e.target.value })}
                  >
                    <option value="">Elegir…</option>
                    {op.destinoTipo === 'extension'
                      ? extensiones.map((ext) => (
                          <option key={ext.id} value={ext.id}>
                            {ext.numero} — {ext.nombre}
                          </option>
                        ))
                      : ivrsDisponiblesParaSubmenu.map((ivr) => (
                          <option key={ivr.id} value={ivr.id}>
                            {ivr.nombre}
                          </option>
                        ))}
                  </select>
                </label>
                <label className="flex flex-col text-xs gap-1">
                  Etiqueta (opcional)
                  <input
                    className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-2 py-1"
                    placeholder="Ej: Ventas"
                    value={op.etiqueta}
                    onChange={(e) => actualizarOpcion(idx, { etiqueta: e.target.value })}
                  />
                </label>
                <button
                  type="button"
                  onClick={() => quitarOpcion(idx)}
                  className="text-red-600 text-xs hover:underline h-fit pb-1"
                >
                  Quitar
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => setOpciones((prev) => [...prev, opcionVacia()])}
              className="text-marca text-sm hover:underline w-fit"
            >
              + Añadir opción
            </button>
          </div>

          {error && <p className="text-red-600 text-sm">{error}</p>}

          <div className="flex gap-3">
            <button disabled={guardando} className="bg-marca text-white rounded-md px-4 py-2">
              Guardar IVR
            </button>
            <button type="button" onClick={cancelar} className="text-sm text-slate-500 hover:underline">
              Cancelar
            </button>
          </div>
        </form>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        {ivrs.map((ivr) => (
          <div key={ivr.id} className="bg-white dark:bg-slate-800 rounded-xl shadow p-4 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="font-medium">{ivr.nombre}</div>
              <div className="flex gap-2 text-sm">
                <button className="text-marca hover:underline" onClick={() => empezarEdicion(ivr)}>
                  Editar
                </button>
                <button className="text-red-600 hover:underline" onClick={() => eliminar(ivr.id)}>
                  Eliminar
                </button>
              </div>
            </div>
            <ul className="text-sm text-slate-500 flex flex-col gap-0.5">
              {ivr.opciones.map((o) => (
                <li key={o.id}>
                  <span className="font-mono">{o.digito}</span> → {o.etiqueta || (o.destinoTipo === 'extension' ? 'extensión' : 'submenú IVR')}
                </li>
              ))}
            </ul>
          </div>
        ))}
        {ivrs.length === 0 && editandoId === null && (
          <p className="text-sm text-slate-500">Todavía no hay IVR configurados para este cliente.</p>
        )}
      </div>
    </section>
  );
}
