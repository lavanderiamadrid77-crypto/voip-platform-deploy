import { FormEvent, useEffect, useState } from 'react';
import { api } from '../api/client';
import { Trunk } from '../api/tipos';
import { useI18n } from '../i18n';

export function Trunks() {
  const { t } = useI18n();
  const [trunks, setTrunks] = useState<Trunk[]>([]);
  const [nombre, setNombre] = useState('');
  const [proveedor, setProveedor] = useState('');
  const [host, setHost] = useState('');
  const [puerto, setPuerto] = useState(5060);
  const [usuario, setUsuario] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function cargar() {
    setTrunks(await api.get<Trunk[]>('/api/trunks'));
  }

  useEffect(() => {
    cargar().catch((e) => setError(e.message));
  }, []);

  async function crear(e: FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api.post('/api/trunks', { nombre, proveedor, host, puerto, usuario, password });
      setNombre('');
      setProveedor('');
      setHost('');
      setUsuario('');
      setPassword('');
      await cargar();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error creando el troncal');
    }
  }

  async function eliminar(id: string) {
    await api.delete(`/api/trunks/${id}`);
    await cargar();
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">{t('trunks')}</h1>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">{t('trunks_subtitulo')}</p>
      </div>

      <form onSubmit={crear} className="bg-white dark:bg-slate-800 rounded-xl shadow p-5 flex gap-3 items-end flex-wrap">
        <Campo etiqueta="Nombre" valor={nombre} onChange={setNombre} />
        <Campo etiqueta="Proveedor" valor={proveedor} onChange={setProveedor} />
        <Campo etiqueta="Host" valor={host} onChange={setHost} />
        <label className="flex flex-col text-sm gap-1">
          Puerto
          <input
            type="number"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2 w-24"
            value={puerto}
            onChange={(e) => setPuerto(Number(e.target.value))}
          />
        </label>
        <Campo etiqueta="Usuario" valor={usuario} onChange={setUsuario} opcional />
        <label className="flex flex-col text-sm gap-1">
          Password
          <input
            type="password"
            className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <button className="bg-marca text-white rounded-md px-4 py-2 h-fit">{t('nuevo_trunk')}</button>
      </form>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <table className="w-full text-sm bg-white dark:bg-slate-800 rounded-xl overflow-hidden">
        <thead className="bg-slate-100 dark:bg-slate-700 text-left">
          <tr>
            <th className="p-2">Nombre</th>
            <th className="p-2">Proveedor</th>
            <th className="p-2">Host</th>
            <th className="p-2">Puerto</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody>
          {trunks.map((tk) => (
            <tr key={tk.id} className="border-t border-slate-100 dark:border-slate-700">
              <td className="p-2">{tk.nombre}</td>
              <td className="p-2">{tk.proveedor}</td>
              <td className="p-2">{tk.host}</td>
              <td className="p-2">{tk.puerto}</td>
              <td className="p-2">
                <button className="text-red-600 hover:underline" onClick={() => eliminar(tk.id)}>
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Campo({
  etiqueta,
  valor,
  onChange,
  opcional,
}: {
  etiqueta: string;
  valor: string;
  onChange: (v: string) => void;
  opcional?: boolean;
}) {
  return (
    <label className="flex flex-col text-sm gap-1">
      {etiqueta}
      <input
        required={!opcional}
        className="rounded-md border border-slate-300 dark:border-slate-600 bg-transparent px-3 py-2"
        value={valor}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}
