import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AudioPrompt } from '../common/entities/audio-prompt.entity';
import { Extension } from '../common/entities/extension.entity';
import { IvrOption } from '../common/entities/ivr-option.entity';
import { Ivr } from '../common/entities/ivr.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchModule } from '../freeswitch/freeswitch.module';
import { IvrController } from './ivr.controller';
import { IvrService } from './ivr.service';

@Module({
  imports: [TypeOrmModule.forFeature([Ivr, IvrOption, Tenant, Extension, AudioPrompt]), FreeswitchModule],
  controllers: [IvrController],
  providers: [IvrService],
})
export class IvrModule {}
