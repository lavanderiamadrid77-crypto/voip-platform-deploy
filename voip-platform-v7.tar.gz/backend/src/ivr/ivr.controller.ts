import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { TenantScopeGuard } from '../common/guards/tenant-scope.guard';
import { GuardarIvrDto } from './dto/ivr.dto';
import { IvrService } from './ivr.service';

@ApiTags('ivr')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, TenantScopeGuard)
@Controller('api/tenants/:tenantId/ivrs')
export class IvrController {
  constructor(private readonly service: IvrService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  listar(@Param('tenantId') tenantId: string) {
    return this.service.listarPorTenant(tenantId);
  }

  @Post()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  crear(@Param('tenantId') tenantId: string, @Body() dto: GuardarIvrDto) {
    return this.service.crear(tenantId, dto);
  }

  @Patch(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  actualizar(@Param('tenantId') tenantId: string, @Param('id') id: string, @Body() dto: GuardarIvrDto) {
    return this.service.actualizar(tenantId, id, dto);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  eliminar(@Param('tenantId') tenantId: string, @Param('id') id: string) {
    return this.service.eliminar(tenantId, id);
  }
}
