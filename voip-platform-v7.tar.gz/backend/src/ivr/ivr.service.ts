import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AudioPrompt } from '../common/entities/audio-prompt.entity';
import { Extension } from '../common/entities/extension.entity';
import { IvrOpcionDestinoTipo } from '../common/entities/ivr-option.entity';
import { Ivr } from '../common/entities/ivr.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { GuardarIvrDto } from './dto/ivr.dto';

@Injectable()
export class IvrService {
  constructor(
    @InjectRepository(Ivr) private readonly repo: Repository<Ivr>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
    @InjectRepository(Extension) private readonly extensionRepo: Repository<Extension>,
    @InjectRepository(AudioPrompt) private readonly promptRepo: Repository<AudioPrompt>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  listarPorTenant(tenantId: string): Promise<Ivr[]> {
    return this.repo.find({ where: { tenantId }, order: { creadoEn: 'DESC' }, relations: ['opciones'] });
  }

  async crear(tenantId: string, dto: GuardarIvrDto): Promise<Ivr> {
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Cliente no encontrado');

    await this.validarOpciones(tenantId, dto);

    const ivr = this.repo.create({
      tenantId,
      nombre: dto.nombre,
      promptBienvenidaId: dto.promptBienvenidaId,
      timeoutSegundos: dto.timeoutSegundos ?? 7,
      opciones: dto.opciones.map((o) => ({
        digito: o.digito,
        destinoTipo: o.destinoTipo,
        destinoId: o.destinoId,
        etiqueta: o.etiqueta,
      })) as any,
    });
    const guardado = await this.repo.save(ivr);
    await this.regenerarXml(tenant, guardado.id);
    return this.obtener(tenantId, guardado.id);
  }

  async actualizar(tenantId: string, id: string, dto: GuardarIvrDto): Promise<Ivr> {
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Cliente no encontrado');
    const ivr = await this.obtener(tenantId, id);

    await this.validarOpciones(tenantId, dto, id);

    ivr.nombre = dto.nombre;
    ivr.promptBienvenidaId = dto.promptBienvenidaId;
    ivr.timeoutSegundos = dto.timeoutSegundos ?? 7;
    ivr.opciones = dto.opciones.map((o) => ({
      digito: o.digito,
      destinoTipo: o.destinoTipo,
      destinoId: o.destinoId,
      etiqueta: o.etiqueta,
    })) as any;

    await this.repo.save(ivr);
    await this.regenerarXml(tenant, id);
    return this.obtener(tenantId, id);
  }

  async eliminar(tenantId: string, id: string): Promise<void> {
    const ivr = await this.obtener(tenantId, id);
    await this.freeswitch.eliminarIvrXml(ivr.id).catch(() => undefined);
    await this.repo.remove(ivr);
  }

  private async obtener(tenantId: string, id: string): Promise<Ivr> {
    const ivr = await this.repo.findOne({ where: { id, tenantId }, relations: ['opciones'] });
    if (!ivr) throw new NotFoundException('IVR no encontrado');
    return ivr;
  }

  /** Un IVR no puede tener submenú a sí mismo (evita bucle infinito trivial) */
  private async validarOpciones(tenantId: string, dto: GuardarIvrDto, ivrIdActual?: string): Promise<void> {
    const digitos = new Set<string>();
    for (const op of dto.opciones) {
      if (digitos.has(op.digito)) {
        throw new BadRequestException(`El dígito ${op.digito} está repetido`);
      }
      digitos.add(op.digito);

      if (op.destinoTipo === IvrOpcionDestinoTipo.EXTENSION) {
        const existe = await this.extensionRepo.findOne({ where: { id: op.destinoId, tenantId } });
        if (!existe) throw new BadRequestException(`La extensión de la opción ${op.digito} no existe`);
      } else if (op.destinoTipo === IvrOpcionDestinoTipo.IVR) {
        if (op.destinoId === ivrIdActual) {
          throw new BadRequestException('Un IVR no puede apuntar a sí mismo');
        }
        const existe = await this.repo.findOne({ where: { id: op.destinoId, tenantId } });
        if (!existe) throw new BadRequestException(`El IVR de la opción ${op.digito} no existe`);
      }
    }
  }

  private async regenerarXml(tenant: Tenant, ivrId: string): Promise<void> {
    const ivr = await this.repo.findOne({ where: { id: ivrId }, relations: ['opciones'] });
    if (!ivr) return;

    let promptAbsoluto: string | undefined;
    if (ivr.promptBienvenidaId) {
      const prompt = await this.promptRepo.findOne({ where: { id: ivr.promptBienvenidaId } });
      if (prompt) {
        promptAbsoluto = this.freeswitch.rutaPromptsTenantFreeswitch(tenant.subdominio, prompt.archivoRelativo);
      }
    }

    const opcionesResueltas = await Promise.all(
      ivr.opciones.map(async (op) => {
        if (op.destinoTipo === IvrOpcionDestinoTipo.EXTENSION) {
          const ext = await this.extensionRepo.findOne({ where: { id: op.destinoId } });
          return {
            digito: op.digito,
            destinoTipo: 'extension' as const,
            destinoExtensionNumero: ext?.numero,
          };
        }
        return { digito: op.digito, destinoTipo: 'ivr' as const, destinoIvrId: op.destinoId };
      }),
    );

    await this.freeswitch.escribirIvrXml({
      ivrId: ivr.id,
      tenantId: tenant.id,
      subdominioTenant: tenant.subdominio,
      timeoutSegundos: ivr.timeoutSegundos,
      promptAbsoluto,
      opciones: opcionesResueltas,
    });
  }
}
