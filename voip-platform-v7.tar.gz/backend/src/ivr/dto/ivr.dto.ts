import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  IsArray,
  IsEnum,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  Min,
  ValidateNested,
} from 'class-validator';
import { IvrOpcionDestinoTipo } from '../../common/entities/ivr-option.entity';

export class IvrOpcionDto {
  @IsIn(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'])
  digito: string;

  @IsEnum(IvrOpcionDestinoTipo)
  destinoTipo: IvrOpcionDestinoTipo;

  @IsString()
  destinoId: string;

  @IsOptional()
  @IsString()
  etiqueta?: string;
}

export class GuardarIvrDto {
  @IsString()
  nombre: string;

  @IsOptional()
  @IsString()
  promptBienvenidaId?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  timeoutSegundos?: number;

  @IsArray()
  @ArrayMaxSize(10)
  @ValidateNested({ each: true })
  @Type(() => IvrOpcionDto)
  opciones: IvrOpcionDto[];
}
