import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Cdr } from '../common/entities/cdr.entity';
import { RatesModule } from '../rates/rates.module';
import { FreeswitchEventsService } from './freeswitch-events.service';
import { FreeswitchService } from './freeswitch.service';

@Module({
  imports: [TypeOrmModule.forFeature([Cdr]), RatesModule],
  providers: [FreeswitchService, FreeswitchEventsService],
  exports: [FreeswitchService],
})
export class FreeswitchModule {}
