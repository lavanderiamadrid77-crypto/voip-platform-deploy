import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Cdr } from '../common/entities/cdr.entity';
import { RatesService } from '../rates/rates.service';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const esl = require('modesl');

/**
 * Escucha en tiempo real los eventos de FreeSWITCH vía ESL y genera el
 * registro de CDR cuando una llamada cuelga (CHANNEL_HANGUP_COMPLETE).
 * Esta es una conexión ESL independiente de la de comandos (FreeswitchService)
 * porque el modo "event" bloquea el socket para otros usos.
 */
@Injectable()
export class FreeswitchEventsService implements OnModuleInit {
  private readonly logger = new Logger(FreeswitchEventsService.name);

  constructor(
    private readonly config: ConfigService,
    @InjectRepository(Cdr) private readonly cdrRepo: Repository<Cdr>,
    private readonly rates: RatesService,
  ) {}

  onModuleInit() {
    this.conectar();
  }

  private conectar() {
    const host = this.config.get<string>('FREESWITCH_ESL_HOST', 'freeswitch');
    const port = this.config.get<number>('FREESWITCH_ESL_PORT', 8021);
    const password = this.config.get<string>('FREESWITCH_ESL_PASSWORD', 'ClueCon');

    const conn = new esl.Connection(host, port, password, () => {
      this.logger.log('Suscrito a eventos de FreeSWITCH para generar CDR');
      conn.subscribe('CHANNEL_HANGUP_COMPLETE');
      conn.on('esl::event::CHANNEL_HANGUP_COMPLETE::*', (evt: any) => {
        this.registrarCdr(evt).catch((e) =>
          this.logger.error(`No se pudo guardar CDR: ${e.message}`),
        );
      });
    });

    conn.on('error', () => setTimeout(() => this.conectar(), 5000));
    conn.on('esl::end', () => setTimeout(() => this.conectar(), 5000));
  }

  private async registrarCdr(evt: any): Promise<void> {
    const get = (campo: string) => evt.getHeader(campo) as string | undefined;

    const tenantId = get('variable_accountcode');
    if (!tenantId) {
      // Llamada fuera de un contexto de tenant conocido (ej. tráfico interno de FS); se ignora.
      return;
    }

    const direccion = get('variable_call_direccion') ?? 'interna';
    const destino = get('Caller-Destination-Number') ?? 'desconocido';
    const duracionSegundos = Number(get('variable_billsec') ?? 0);
    const minutos = duracionSegundos / 60;

    // Para llamadas salientes el proveedor usado es el gateway de FreeSWITCH
    // (sip_gateway_name); para entrantes es el que fijamos nosotros mismos al
    // enrutar el DID (trunk_entrante), porque sip_gateway_name no siempre
    // queda disponible de forma fiable en llamadas que llegan de fuera.
    const trunkUsado =
      direccion === 'saliente'
        ? get('variable_sip_gateway_name')
        : direccion === 'entrante'
          ? (get('variable_trunk_entrante') ?? get('variable_sip_gateway_name'))
          : undefined;

    let costo = 0;
    let venta = 0;
    if (direccion !== 'interna' && minutos > 0) {
      const [precioCompra, precioVenta] = await Promise.all([
        this.rates.precioCompraPorMinuto(trunkUsado, destino),
        this.rates.precioVentaPorMinuto(tenantId, destino),
      ]);
      costo = Number((precioCompra * minutos).toFixed(5));
      venta = Number((precioVenta * minutos).toFixed(5));
    }

    const cdr = this.cdrRepo.create({
      tenantId,
      callUuid: get('Unique-ID'),
      origen: get('Caller-Caller-ID-Number') ?? get('Caller-Username') ?? 'desconocido',
      destino,
      fechaHoraInicio: new Date(Number(get('Caller-Channel-Created-Time') ?? 0) / 1000 || Date.now()),
      duracionSegundos,
      estado: get('variable_hangup_cause') ?? 'desconocido',
      trunkUsado,
      direccion,
      costo,
      venta,
    });
    await this.cdrRepo.save(cdr);
  }
}
