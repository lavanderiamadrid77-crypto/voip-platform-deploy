import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs/promises';
import * as path from 'path';

// `modesl` no trae tipos oficiales; se declara mínimamente aquí para no
// depender de @types/modesl (no existe en npm).
// eslint-disable-next-line @typescript-eslint/no-var-requires
const esl = require('modesl');

/**
 * Encapsula toda la comunicación con FreeSWITCH:
 *  - Conexión ESL (Event Socket Library) para comandos y eventos en vivo.
 *  - Generación de los ficheros XML de directory/dialplan/gateways que
 *    FreeSWITCH lee desde disco (montados como volumen compartido).
 *
 * Nota: FreeSWITCH normalmente usa mod_xml_curl para configuración 100%
 * dinámica vía HTTP. Para el MVP se usa el enfoque más simple de escribir
 * ficheros XML a un volumen compartido + "reloadxml" por ESL, que es más
 * fácil de depurar y no requiere levantar un servidor XML-RPC aparte.
 * Migrar a mod_xml_curl queda documentado como mejora de Fase 2.
 */
@Injectable()
export class FreeswitchService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(FreeswitchService.name);
  private connection: any;
  private reconectando = false;

  constructor(private readonly config: ConfigService) {}

  async onModuleInit() {
    await this.conectar();
  }

  onModuleDestroy() {
    this.connection?.disconnect?.();
  }

  private conectar(): Promise<void> {
    return new Promise((resolve) => {
      const host = this.config.get<string>('FREESWITCH_ESL_HOST', 'freeswitch');
      const port = this.config.get<number>('FREESWITCH_ESL_PORT', 8021);
      const password = this.config.get<string>('FREESWITCH_ESL_PASSWORD', 'ClueCon');

      this.connection = new esl.Connection(host, port, password, () => {
        this.logger.log(`Conectado a FreeSWITCH ESL en ${host}:${port}`);
        resolve();
      });

      this.connection.on('error', (err: Error) => {
        this.logger.error(`Error de conexión ESL: ${err.message}`);
        this.reintentar();
      });

      this.connection.on('esl::end', () => {
        this.logger.warn('Conexión ESL cerrada, reintentando...');
        this.reintentar();
      });
    });
  }

  private reintentar() {
    if (this.reconectando) return;
    this.reconectando = true;
    setTimeout(() => {
      this.reconectando = false;
      this.conectar().catch(() => undefined);
    }, 5000);
  }

  /** Ejecuta un comando de la consola de FreeSWITCH (fs_cli) vía ESL */
  async ejecutarComando(comando: string): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.connection || !this.connection.connected?.()) {
        return reject(new Error('Sin conexión activa a FreeSWITCH ESL'));
      }
      this.connection.api(comando, (res: any) => {
        resolve(res?.getBody?.() ?? '');
      });
    });
  }

  /** Recarga toda la configuración XML (directory, dialplan, sip_profiles includes) */
  async recargarXml(): Promise<void> {
    await this.ejecutarComando('reloadxml');
  }

  /** Fuerza a un perfil Sofia a releer sus gateways sin reiniciar el perfil entero */
  async recargarGateways(perfil = 'external'): Promise<void> {
    await this.ejecutarComando(`sofia profile ${perfil} rescan reloadxml`);
  }

  /**
   * Declara el dominio SIP de un tenant: conf/directory/<subdominio>.xml
   * Este fichero es lo que hace que cada tenant sea un dominio SIP
   * independiente dentro de FreeSWITCH (aislamiento real, no solo lógico),
   * incluyendo a su vez todos los usuarios/extensiones que viven en
   * conf/directory/<subdominio>/*.xml
   */
  async escribirDominioTenantXml(params: { subdominio: string; canalesMax: number }): Promise<void> {
    const dir = path.join(this.confPath(), 'directory');
    await fs.mkdir(dir, { recursive: true });
    await fs.mkdir(path.join(dir, params.subdominio), { recursive: true });
    const xml = `<include>
  <domain name="${params.subdominio}">
    <params>
      <param name="dial-string" value="\${sofia_contact(*/\${dialed_user}@\${dialed_domain})}"/>
    </params>
    <variables>
      <variable name="tenant_subdominio" value="${params.subdominio}"/>
      <variable name="max_channels" value="${params.canalesMax}"/>
    </variables>
    <groups>
      <group name="default">
        <users>
          <X-PRE-PROCESS cmd="include" data="${params.subdominio}/*.xml"/>
        </users>
      </group>
    </groups>
  </domain>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.subdominio}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarDominioTenantXml(subdominio: string): Promise<void> {
    await fs.rm(path.join(this.confPath(), 'directory', `${subdominio}.xml`), { force: true });
    await fs.rm(path.join(this.confPath(), 'directory', subdominio), { recursive: true, force: true });
    await this.recargarXml();
  }

  /**
   * Escribe el XML de <directory> para una extensión dentro de
   * conf/directory/<subdominio>/<numero>.xml
   */
  async escribirExtensionXml(params: {
    tenantId: string;
    subdominioTenant: string;
    numero: string;
    nombre: string;
    passwordPlano: string;
    codecs: string;
  }): Promise<void> {
    const dir = path.join(this.confPath(), 'directory', params.subdominioTenant);
    await fs.mkdir(dir, { recursive: true });
    const xml = `<include>
  <user id="${params.numero}">
    <params>
      <param name="password" value="${params.passwordPlano}"/>
    </params>
    <variables>
      <variable name="toll_allow" value="domestic,international,local"/>
      <!-- accountcode = UUID del tenant (no el subdominio): es lo que
           freeswitch-events.service.ts usa para atribuir cada CDR al
           tenant correcto en la tabla 'cdr' (cuya columna tenantId es un
           UUID, igual que en extensions/trunks). El subdominio sigue
           disponible aparte en tenant_subdominio para todo lo demás
           (dominio SIP, rutas de dialplan, etc.) -->
      <variable name="accountcode" value="${params.tenantId}"/>
      <variable name="tenant_subdominio" value="${params.subdominioTenant}"/>
      <variable name="user_context" value="tenant_${params.subdominioTenant}"/>
      <variable name="effective_caller_id_name" value="${params.nombre}"/>
      <variable name="effective_caller_id_number" value="${params.numero}"/>
      <variable name="codec_string" value="${params.codecs}"/>
    </variables>
  </user>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.numero}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarExtensionXml(subdominioTenant: string, numero: string): Promise<void> {
    const file = path.join(this.confPath(), 'directory', subdominioTenant, `${numero}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  /**
   * Escribe el XML de <gateway> de un trunk saliente/entrante dentro de
   * conf/sip_profiles/external/<nombre>.xml
   */
  async escribirTrunkXml(params: {
    nombre: string;
    host: string;
    puerto: number;
    usuario?: string;
    passwordPlano?: string;
  }): Promise<void> {
    const dir = path.join(this.confPath(), 'sip_profiles', 'external');
    await fs.mkdir(dir, { recursive: true });
    const xml = `<include>
  <gateway name="${params.nombre}">
    <param name="username" value="${params.usuario ?? params.nombre}"/>
    <param name="password" value="${params.passwordPlano ?? ''}"/>
    <param name="realm" value="${params.host}"/>
    <param name="proxy" value="${params.host}:${params.puerto}"/>
    <param name="register" value="${params.usuario ? 'true' : 'false'}"/>
    <param name="caller-id-in-from" value="true"/>
  </gateway>
</include>
`;
    await fs.writeFile(path.join(dir, `${params.nombre}.xml`), xml, 'utf-8');
    await this.recargarGateways('external');
  }

  async eliminarTrunkXml(nombre: string): Promise<void> {
    const file = path.join(this.confPath(), 'sip_profiles', 'external', `${nombre}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarGateways('external');
  }

  // ---------------------------------------------------------------------
  // Helpers de nombres/escapado
  // ---------------------------------------------------------------------

  /** Escapa caracteres especiales de regex para poder usar un valor arbitrario dentro de un expression="^...$" */
  private escapeRegex(valor: string): string {
    return valor.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /** Nombre único (como destination_number interno) del menú de un IVR, usado para transfer/bridge internos */
  private nombreMenuIvr(ivrId: string): string {
    return `ivr_menu_${ivrId}`;
  }

  /** Nombre (solo informativo, para el atributo name="" de <extension>) de una opción de un IVR */
  private nombreOpcionIvr(ivrId: string, digito: string): string {
    return `ivr_opcion_${ivrId}_${digito}`;
  }

  /** Nombre de la variable de canal donde se guarda el dígito pulsado en un IVR concreto (evita colisiones entre IVRs) */
  private variableDigitoIvr(ivrId: string): string {
    return `ivr_digito_${ivrId.replace(/-/g, '')}`;
  }

  // ---------------------------------------------------------------------
  // Números SIP (DIDs) — enrutamiento de llamadas entrantes
  // ---------------------------------------------------------------------

  private dirDialplanPublicoDinamico(): string {
    return path.join(this.confPath(), 'dialplan', 'public', 'dinamico');
  }

  /**
   * Escribe el dialplan dinámico para un número SIP (DID): al recibir una
   * llamada con ese destination_number en el contexto "public" (llamadas
   * entrantes desde trunks), la enruta a una extensión o a un IVR del
   * tenant al que está asignado el número.
   */
  async escribirDidXml(params: {
    numero: string;
    tenantId: string;
    subdominioTenant: string;
    destinoTipo: 'extension' | 'ivr';
    destinoExtensionNumero?: string;
    destinoIvrId?: string;
    trunkProveedorNombre?: string;
  }): Promise<void> {
    const dir = this.dirDialplanPublicoDinamico();
    await fs.mkdir(dir, { recursive: true });

    const numeroEscapado = this.escapeRegex(params.numero);
    // trunk_entrante: nombre del proveedor por el que llegó este número, usado
    // por freeswitch-events.service.ts para calcular el costo de compra de
    // llamadas entrantes (además del sip_gateway_name, que en llamadas
    // entrantes no siempre queda disponible de forma fiable).
    const accionesComunes = `      <action application="set" data="accountcode=${params.tenantId}"/>
      <action application="set" data="tenant_subdominio=${params.subdominioTenant}"/>
      <action application="set" data="call_direccion=entrante"/>${
        params.trunkProveedorNombre
          ? `\n      <action application="set" data="trunk_entrante=${params.trunkProveedorNombre}"/>`
          : ''
      }`;

    let accionDestino: string;
    if (params.destinoTipo === 'ivr' && params.destinoIvrId) {
      accionDestino = `      <action application="answer"/>
      <action application="transfer" data="${this.nombreMenuIvr(params.destinoIvrId)} XML public"/>`;
    } else if (params.destinoTipo === 'extension' && params.destinoExtensionNumero) {
      accionDestino = `      <action application="set" data="hangup_after_bridge=true"/>
      <action application="bridge" data="user/${params.destinoExtensionNumero}@${params.subdominioTenant}"/>
      <action application="answer"/>
      <action application="sleep" data="1000"/>
      <action application="voicemail" data="default ${params.subdominioTenant} ${params.destinoExtensionNumero}"/>`;
    } else {
      accionDestino = `      <action application="log" data="WARNING DID ${params.numero} sin destino configurado"/>
      <action application="respond" data="404"/>`;
    }

    const xml = `<include>
  <extension name="did_${numeroEscapado}">
    <condition field="destination_number" expression="^${numeroEscapado}$">
${accionesComunes}
${accionDestino}
    </condition>
  </extension>
</include>
`;
    await fs.writeFile(path.join(dir, `did_${params.numero.replace(/[^a-zA-Z0-9]/g, '_')}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarDidXml(numero: string): Promise<void> {
    const file = path.join(
      this.dirDialplanPublicoDinamico(),
      `did_${numero.replace(/[^a-zA-Z0-9]/g, '_')}.xml`,
    );
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  // ---------------------------------------------------------------------
  // IVR / respuestas automáticas
  // ---------------------------------------------------------------------

  /**
   * Escribe el dialplan dinámico de un IVR: una extensión "menú" que
   * contesta, reproduce la locución de bienvenida y pide un dígito
   * (play_and_get_digits), guardándolo en una variable de canal única para
   * este IVR; seguida de una extensión por cada opción configurada (a
   * extensión o a otro IVR = submenú) que compara esa variable, más una de
   * respaldo para dígitos no válidos que repite el menú.
   */
  async escribirIvrXml(params: {
    ivrId: string;
    tenantId: string;
    subdominioTenant: string;
    timeoutSegundos: number;
    promptAbsoluto?: string;
    opciones: Array<{
      digito: string;
      destinoTipo: 'extension' | 'ivr';
      destinoExtensionNumero?: string;
      destinoIvrId?: string;
    }>;
  }): Promise<void> {
    const dir = this.dirDialplanPublicoDinamico();
    await fs.mkdir(dir, { recursive: true });

    const prompt = params.promptAbsoluto ?? 'silence_stream://1000';
    const nombreMenu = this.nombreMenuIvr(params.ivrId);
    const varDigito = this.variableDigitoIvr(params.ivrId);
    const timeoutMs = Math.max(1, params.timeoutSegundos) * 1000;
    const accionesComunes = `      <action application="set" data="accountcode=${params.tenantId}"/>
      <action application="set" data="tenant_subdominio=${params.subdominioTenant}"/>`;

    const bloqueMenu = `  <extension name="${nombreMenu}" continue="true">
    <condition field="destination_number" expression="^${nombreMenu}$">
${accionesComunes}
      <action application="answer"/>
      <action application="play_and_get_digits" data="1 1 3 ${timeoutMs} # ${prompt} ${prompt} ${varDigito} \\d ${timeoutMs}"/>
    </condition>
  </extension>
`;

    const bloquesOpciones = params.opciones
      .map((op) => {
        const nombreOpcion = this.nombreOpcionIvr(params.ivrId, op.digito);
        let accion: string;
        if (op.destinoTipo === 'ivr' && op.destinoIvrId) {
          accion = `      <action application="transfer" data="${this.nombreMenuIvr(op.destinoIvrId)} XML public"/>`;
        } else if (op.destinoTipo === 'extension' && op.destinoExtensionNumero) {
          accion = `      <action application="set" data="hangup_after_bridge=true"/>
      <action application="bridge" data="user/${op.destinoExtensionNumero}@${params.subdominioTenant}"/>
      <action application="answer"/>
      <action application="sleep" data="1000"/>
      <action application="voicemail" data="default ${params.subdominioTenant} ${op.destinoExtensionNumero}"/>`;
        } else {
          accion = `      <action application="respond" data="404"/>`;
        }
        return `  <extension name="${nombreOpcion}">
    <condition field="\${${varDigito}}" expression="^${op.digito}$">
${accionesComunes}
${accion}
    </condition>
  </extension>
`;
      })
      .join('\n');

    // Respaldo: si no se pulsó ningún dígito válido (o se agotaron los
    // intentos de play_and_get_digits y la variable quedó vacía), se repite
    // el menú desde el principio. Esta extensión va SIEMPRE al final, tras
    // las opciones configuradas, para que actúe solo como último recurso.
    const xml = `<include>
${bloqueMenu}
${bloquesOpciones}
  <extension name="${nombreMenu}_repetir">
    <condition field="\${${varDigito}}" expression=".*">
${accionesComunes}
      <action application="transfer" data="${nombreMenu} XML public"/>
    </condition>
  </extension>
</include>
`;
    await fs.writeFile(path.join(dir, `ivr_${params.ivrId}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarIvrXml(ivrId: string): Promise<void> {
    const file = path.join(this.dirDialplanPublicoDinamico(), `ivr_${ivrId}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  // ---------------------------------------------------------------------
  // Enrutamiento saliente por tenant (LCR simple por prioridad de trunk)
  // ---------------------------------------------------------------------

  private dirDialplanDefaultDinamico(): string {
    return path.join(this.confPath(), 'dialplan', 'default', 'dinamico');
  }

  /**
   * Escribe/actualiza la ruta de salida de un tenant: al marcar un número
   * (contexto "default", el de las extensiones internas) se intenta cada
   * trunk activo disponible para ese tenant (propios primero, luego
   * compartidos), en orden de prioridad, uno tras otro (failover) hasta que
   * alguno complete la llamada.
   */
  async escribirRutaSalienteTenantXml(params: {
    tenantId: string;
    subdominioTenant: string;
    nombresTrunksOrdenados: string[];
  }): Promise<void> {
    const dir = this.dirDialplanDefaultDinamico();
    await fs.mkdir(dir, { recursive: true });

    if (params.nombresTrunksOrdenados.length === 0) {
      // Sin trunks disponibles: se elimina la ruta (si existía) para que la
      // llamada caiga en el manejo por defecto (normalmente "no route").
      await this.eliminarRutaSalienteTenantXml(params.subdominioTenant);
      return;
    }

    const bridgeString = params.nombresTrunksOrdenados
      .map((nombre) => `sofia/gateway/${nombre}/\${destination_number}`)
      .join('|');

    const xml = `<include>
  <extension name="saliente_${params.subdominioTenant}">
    <condition field="\${tenant_subdominio}" expression="^${params.subdominioTenant}$">
      <condition field="destination_number" expression="^(\\d{6,15})$">
        <action application="set" data="accountcode=${params.tenantId}"/>
        <action application="set" data="call_direccion=saliente"/>
        <action application="set" data="hangup_after_bridge=true"/>
        <action application="bridge" data="${bridgeString}"/>
      </condition>
    </condition>
  </extension>
</include>
`;
    await fs.writeFile(path.join(dir, `saliente_${params.subdominioTenant}.xml`), xml, 'utf-8');
    await this.recargarXml();
  }

  async eliminarRutaSalienteTenantXml(subdominioTenant: string): Promise<void> {
    const file = path.join(this.dirDialplanDefaultDinamico(), `saliente_${subdominioTenant}.xml`);
    await fs.rm(file, { force: true });
    await this.recargarXml();
  }

  // ---------------------------------------------------------------------
  // Locuciones (prompts de audio)
  // ---------------------------------------------------------------------

  /** Ruta (lado backend) a la carpeta de locuciones de un tenant, dentro del volumen compartido de prompts */
  rutaPromptsTenantBackend(subdominioTenant: string): string {
    const base = this.config.get<string>('FREESWITCH_PROMPTS_PATH_BACKEND', '/freeswitch-conf/prompts');
    return path.join(base, subdominioTenant);
  }

  /** Ruta absoluta (lado FreeSWITCH) a un fichero de locución concreto, para usar en <action application="playback"/> o similar */
  rutaPromptsTenantFreeswitch(subdominioTenant: string, archivoRelativo: string): string {
    const base = this.config.get<string>('FREESWITCH_PROMPTS_PATH_FS', '/etc/freeswitch/prompts');
    return path.join(base, subdominioTenant, archivoRelativo);
  }

  /** Ruta al volumen compartido de configuración de FreeSWITCH (montado en docker-compose) */
  private confPath(): string {
    return this.config.get<string>('FREESWITCH_CONF_PATH', '/freeswitch-conf');
  }
}
