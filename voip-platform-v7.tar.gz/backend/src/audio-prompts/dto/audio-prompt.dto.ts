import { IsString } from 'class-validator';

export class CrearAudioPromptDto {
  @IsString()
  nombre: string;
}
