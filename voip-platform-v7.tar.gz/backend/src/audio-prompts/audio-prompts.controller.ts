import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiConsumes, ApiTags } from '@nestjs/swagger';
import type { Response } from 'express';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { TenantScopeGuard } from '../common/guards/tenant-scope.guard';
import { AudioPromptsService } from './audio-prompts.service';

@ApiTags('audio-prompts')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, TenantScopeGuard)
@Controller('api/tenants/:tenantId/locuciones')
export class AudioPromptsController {
  constructor(private readonly service: AudioPromptsService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  listar(@Param('tenantId') tenantId: string) {
    return this.service.listarPorTenant(tenantId);
  }

  /** Sube o graba (desde el navegador) una locución. Acepta cualquier formato de audio; se transcodifica a WAV. */
  @Post()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('audio', { limits: { fileSize: 20 * 1024 * 1024 } }))
  subir(
    @Param('tenantId') tenantId: string,
    @Body('nombre') nombre: string,
    @UploadedFile() archivo: Express.Multer.File,
  ) {
    return this.service.subir(tenantId, nombre || 'Locución sin nombre', archivo);
  }

  @Get(':id/audio')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  async reproducir(@Param('tenantId') tenantId: string, @Param('id') id: string, @Res() res: Response) {
    const ruta = await this.service.rutaArchivo(tenantId, id);
    res.sendFile(ruta);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  eliminar(@Param('tenantId') tenantId: string, @Param('id') id: string) {
    return this.service.eliminar(tenantId, id);
  }
}
