import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AudioPrompt } from '../common/entities/audio-prompt.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { FreeswitchModule } from '../freeswitch/freeswitch.module';
import { AudioPromptsController } from './audio-prompts.controller';
import { AudioPromptsService } from './audio-prompts.service';

@Module({
  imports: [TypeOrmModule.forFeature([AudioPrompt, Tenant]), FreeswitchModule],
  controllers: [AudioPromptsController],
  providers: [AudioPromptsService],
})
export class AudioPromptsModule {}
