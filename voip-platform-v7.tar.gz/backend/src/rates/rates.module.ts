import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BuyRate } from '../common/entities/buy-rate.entity';
import { SellRate } from '../common/entities/sell-rate.entity';
import { Trunk } from '../common/entities/trunk.entity';
import { BuyRatesController, SellRatesController } from './rates.controller';
import { RatesService } from './rates.service';

@Module({
  imports: [TypeOrmModule.forFeature([BuyRate, SellRate, Trunk])],
  controllers: [BuyRatesController, SellRatesController],
  providers: [RatesService],
  exports: [RatesService],
})
export class RatesModule {}
