import { Body, Controller, Delete, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { CrearBuyRateDto, CrearSellRateDto } from './dto/rate.dto';
import { RatesService } from './rates.service';

/** Tarifas de COMPRA: lo que nos cobra cada proveedor (troncal) por minuto según destino. Solo super_admin. */
@ApiTags('rates')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('api/tarifas/compra')
export class BuyRatesController {
  constructor(private readonly service: RatesService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN)
  listar(@Query('trunkId') trunkId?: string) {
    return this.service.listarCompra(trunkId);
  }

  @Post()
  @Roles(Rol.SUPER_ADMIN)
  crear(@Body() dto: CrearBuyRateDto) {
    return this.service.crearCompra(dto);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN)
  eliminar(@Param('id') id: string) {
    return this.service.eliminarCompra(id);
  }
}

/** Tarifas de VENTA: lo que le cobramos a cada cliente por minuto según destino. */
@ApiTags('rates')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('api/tarifas/venta')
export class SellRatesController {
  constructor(private readonly service: RatesService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  listar(@Query('tenantId') tenantId: string | undefined, @Req() req: any) {
    // Un ADMIN (nivel cliente) solo puede ver sus propias tarifas de venta,
    // sin importar qué tenantId envíe en la query string.
    const tenantIdEfectivo = req.user?.rol === Rol.ADMIN ? req.user.tenantId : tenantId;
    return this.service.listarVenta(tenantIdEfectivo);
  }

  @Post()
  @Roles(Rol.SUPER_ADMIN)
  crear(@Body() dto: CrearSellRateDto) {
    return this.service.crearVenta(dto);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN)
  eliminar(@Param('id') id: string) {
    return this.service.eliminarVenta(id);
  }
}
