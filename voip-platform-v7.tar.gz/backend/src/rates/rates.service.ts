import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BuyRate } from '../common/entities/buy-rate.entity';
import { SellRate } from '../common/entities/sell-rate.entity';
import { Trunk } from '../common/entities/trunk.entity';
import { CrearBuyRateDto, CrearSellRateDto } from './dto/rate.dto';

/**
 * Motor de tarifas mínimo (estilo LCR): cada tarifa tiene un prefijo de
 * número destino ("" = por defecto/catch-all) y un precio por minuto. Al
 * valorar una llamada se busca, entre las tarifas del proveedor/tenant, la
 * que tenga el prefijo MÁS LARGO que sea inicio del número destino (ej.
 * "34911" gana a "34" para un número que empiece por 34911).
 */
@Injectable()
export class RatesService {
  constructor(
    @InjectRepository(BuyRate) private readonly buyRepo: Repository<BuyRate>,
    @InjectRepository(SellRate) private readonly sellRepo: Repository<SellRate>,
    @InjectRepository(Trunk) private readonly trunkRepo: Repository<Trunk>,
  ) {}

  // --- Tarifas de compra (por proveedor/trunk) ---------------------------

  listarCompra(trunkId?: string): Promise<BuyRate[]> {
    return this.buyRepo.find({
      where: trunkId ? { trunkId } : {},
      order: { prefijo: 'ASC' },
    });
  }

  async crearCompra(dto: CrearBuyRateDto): Promise<BuyRate> {
    const trunk = await this.trunkRepo.findOne({ where: { id: dto.trunkId } });
    if (!trunk) throw new NotFoundException('Proveedor (troncal) no encontrado');
    const tarifa = this.buyRepo.create({
      trunkId: dto.trunkId,
      prefijo: dto.prefijo ?? '',
      descripcion: dto.descripcion,
      precioPorMinuto: dto.precioPorMinuto,
    });
    return this.buyRepo.save(tarifa);
  }

  async eliminarCompra(id: string): Promise<void> {
    await this.buyRepo.delete(id);
  }

  // --- Tarifas de venta (por tenant, o global si tenantId es nulo) -------

  listarVenta(tenantId?: string): Promise<SellRate[]> {
    if (tenantId) {
      return this.sellRepo.find({ where: { tenantId }, order: { prefijo: 'ASC' } });
    }
    return this.sellRepo
      .createQueryBuilder('sr')
      .where('sr.tenantId IS NULL')
      .orderBy('sr.prefijo', 'ASC')
      .getMany();
  }

  async crearVenta(dto: CrearSellRateDto): Promise<SellRate> {
    const tarifa = this.sellRepo.create({
      tenantId: dto.tenantId,
      prefijo: dto.prefijo ?? '',
      descripcion: dto.descripcion,
      precioPorMinuto: dto.precioPorMinuto,
    });
    return this.sellRepo.save(tarifa);
  }

  async eliminarVenta(id: string): Promise<void> {
    await this.sellRepo.delete(id);
  }

  // --- Valoración de llamadas (usado al cerrar cada CDR) ------------------

  /** Precio por minuto de compra para un trunk (por su NOMBRE, tal como lo reporta FreeSWITCH) y un destino */
  async precioCompraPorMinuto(trunkNombre: string | undefined, destino: string): Promise<number> {
    if (!trunkNombre) return 0;
    const trunk = await this.trunkRepo.findOne({ where: { nombre: trunkNombre } });
    if (!trunk) return 0;
    const tarifas = await this.buyRepo.find({ where: { trunkId: trunk.id, activo: true } });
    return this.mejorCoincidencia(tarifas, destino);
  }

  /** Precio por minuto de venta para un tenant y un destino; si el tenant no tiene tarifa propia, usa la global */
  async precioVentaPorMinuto(tenantId: string | undefined, destino: string): Promise<number> {
    if (!tenantId) return 0;
    const propias = await this.sellRepo.find({ where: { tenantId, activo: true } });
    const propia = this.mejorCoincidencia(propias, destino);
    if (propia > 0) return propia;

    const globales = await this.sellRepo
      .createQueryBuilder('sr')
      .where('sr.tenantId IS NULL')
      .andWhere('sr.activo = true')
      .getMany();
    return this.mejorCoincidencia(globales, destino);
  }

  private mejorCoincidencia(tarifas: Array<{ prefijo: string; precioPorMinuto: number }>, destinoBruto: string): number {
    const destino = (destinoBruto || '').replace(/^\+/, '');
    let mejor: { prefijo: string; precioPorMinuto: number } | undefined;
    for (const tarifa of tarifas) {
      if (tarifa.prefijo === '' || destino.startsWith(tarifa.prefijo)) {
        if (!mejor || tarifa.prefijo.length > mejor.prefijo.length) {
          mejor = tarifa;
        }
      }
    }
    return mejor ? Number(mejor.precioPorMinuto) : 0;
  }
}
