import { IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class CrearBuyRateDto {
  @IsString()
  trunkId: string;

  @IsOptional()
  @IsString()
  prefijo?: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsNumber()
  @Min(0)
  precioPorMinuto: number;
}

export class CrearSellRateDto {
  @IsOptional()
  @IsString()
  tenantId?: string;

  @IsOptional()
  @IsString()
  prefijo?: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsNumber()
  @Min(0)
  precioPorMinuto: number;
}
