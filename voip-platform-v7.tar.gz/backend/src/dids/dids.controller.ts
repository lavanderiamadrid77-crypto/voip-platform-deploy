import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Roles } from '../common/decorators/roles.decorator';
import { Rol } from '../common/entities/user.entity';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { TenantScopeGuard } from '../common/guards/tenant-scope.guard';
import { AsignarDidDto, ConfigurarDestinoDidDto, CrearDidDto } from './dto/did.dto';
import { DidsService } from './dids.service';

/** Gestión a nivel plataforma del "pool" de números SIP: alta y asignación a clientes. Solo super_admin. */
@ApiTags('dids')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('api/dids')
export class DidsController {
  constructor(private readonly service: DidsService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN)
  listar(@Query('tenantId') tenantId?: string) {
    return this.service.listarTodos(tenantId);
  }

  @Post()
  @Roles(Rol.SUPER_ADMIN)
  crear(@Body() dto: CrearDidDto) {
    return this.service.crear(dto);
  }

  @Patch(':id/asignar')
  @Roles(Rol.SUPER_ADMIN)
  asignar(@Param('id') id: string, @Body() dto: AsignarDidDto) {
    return this.service.asignar(id, dto);
  }

  @Delete(':id')
  @Roles(Rol.SUPER_ADMIN)
  eliminar(@Param('id') id: string) {
    return this.service.eliminar(id);
  }
}

/** Vista y autoconfiguración del cliente sobre SUS PROPIOS números SIP ya asignados. */
@ApiTags('dids')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard, TenantScopeGuard)
@Controller('api/tenants/:tenantId/dids')
export class TenantDidsController {
  constructor(private readonly service: DidsService) {}

  @Get()
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  listar(@Param('tenantId') tenantId: string) {
    return this.service.listarPorTenant(tenantId);
  }

  @Patch(':id/destino')
  @Roles(Rol.SUPER_ADMIN, Rol.ADMIN)
  configurarDestino(
    @Param('tenantId') tenantId: string,
    @Param('id') id: string,
    @Body() dto: ConfigurarDestinoDidDto,
  ) {
    return this.service.configurarDestino(tenantId, id, dto);
  }
}
