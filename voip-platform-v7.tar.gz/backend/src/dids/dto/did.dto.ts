import { IsEnum, IsOptional, IsString } from 'class-validator';
import { DidDestinoTipo } from '../../common/entities/did.entity';

export class CrearDidDto {
  @IsString()
  numero: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsOptional()
  @IsString()
  trunkProveedorId?: string;
}

export class AsignarDidDto {
  @IsOptional()
  @IsString()
  tenantId?: string;
}

export class ConfigurarDestinoDidDto {
  @IsEnum(DidDestinoTipo)
  destinoTipo: DidDestinoTipo;

  @IsOptional()
  @IsString()
  destinoId?: string;
}
