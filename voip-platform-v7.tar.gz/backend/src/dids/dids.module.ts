import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Did } from '../common/entities/did.entity';
import { Extension } from '../common/entities/extension.entity';
import { Ivr } from '../common/entities/ivr.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { Trunk } from '../common/entities/trunk.entity';
import { FreeswitchModule } from '../freeswitch/freeswitch.module';
import { DidsController, TenantDidsController } from './dids.controller';
import { DidsService } from './dids.service';

@Module({
  imports: [TypeOrmModule.forFeature([Did, Tenant, Extension, Ivr, Trunk]), FreeswitchModule],
  controllers: [DidsController, TenantDidsController],
  providers: [DidsService],
})
export class DidsModule {}
