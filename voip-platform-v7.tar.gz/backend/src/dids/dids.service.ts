import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Did, DidDestinoTipo } from '../common/entities/did.entity';
import { Extension } from '../common/entities/extension.entity';
import { Ivr } from '../common/entities/ivr.entity';
import { Tenant } from '../common/entities/tenant.entity';
import { Trunk } from '../common/entities/trunk.entity';
import { FreeswitchService } from '../freeswitch/freeswitch.service';
import { AsignarDidDto, ConfigurarDestinoDidDto, CrearDidDto } from './dto/did.dto';

@Injectable()
export class DidsService {
  constructor(
    @InjectRepository(Did) private readonly repo: Repository<Did>,
    @InjectRepository(Tenant) private readonly tenantRepo: Repository<Tenant>,
    @InjectRepository(Extension) private readonly extensionRepo: Repository<Extension>,
    @InjectRepository(Ivr) private readonly ivrRepo: Repository<Ivr>,
    @InjectRepository(Trunk) private readonly trunkRepo: Repository<Trunk>,
    private readonly freeswitch: FreeswitchService,
  ) {}

  listarTodos(tenantId?: string): Promise<Did[]> {
    return this.repo.find({
      where: tenantId ? { tenantId } : {},
      order: { creadoEn: 'DESC' },
    });
  }

  listarPorTenant(tenantId: string): Promise<Did[]> {
    return this.repo.find({ where: { tenantId }, order: { numero: 'ASC' } });
  }

  async crear(dto: CrearDidDto): Promise<Did> {
    const existe = await this.repo.findOne({ where: { numero: dto.numero } });
    if (existe) throw new ConflictException('Ese número SIP ya existe');
    const did = this.repo.create({
      numero: dto.numero,
      descripcion: dto.descripcion,
      trunkProveedorId: dto.trunkProveedorId,
      destinoTipo: DidDestinoTipo.NINGUNO,
    });
    return this.repo.save(did);
  }

  /** Asigna (o libera, con tenantId=undefined) un número a un cliente. Al reasignar se limpia el destino previo. */
  async asignar(id: string, dto: AsignarDidDto): Promise<Did> {
    const did = await this.obtener(id);
    if (did.tenantId !== dto.tenantId) {
      await this.freeswitch.eliminarDidXml(did.numero).catch(() => undefined);
      did.destinoTipo = DidDestinoTipo.NINGUNO;
      did.destinoId = undefined;
    }
    did.tenantId = dto.tenantId;
    return this.repo.save(did);
  }

  /** Configura a dónde suena un número SIP ya asignado a un tenant (extensión o IVR) */
  async configurarDestino(tenantId: string, id: string, dto: ConfigurarDestinoDidDto): Promise<Did> {
    const did = await this.obtener(id);
    if (did.tenantId !== tenantId) {
      throw new BadRequestException('Ese número SIP no pertenece a este cliente');
    }
    const tenant = await this.tenantRepo.findOne({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Cliente no encontrado');

    const trunkProveedor = did.trunkProveedorId
      ? await this.trunkRepo.findOne({ where: { id: did.trunkProveedorId } })
      : undefined;

    did.destinoTipo = dto.destinoTipo;
    did.destinoId = dto.destinoId;

    if (dto.destinoTipo === DidDestinoTipo.NINGUNO || !dto.destinoId) {
      did.destinoTipo = DidDestinoTipo.NINGUNO;
      did.destinoId = undefined;
      await this.freeswitch.eliminarDidXml(did.numero).catch(() => undefined);
      return this.repo.save(did);
    }

    if (dto.destinoTipo === DidDestinoTipo.EXTENSION) {
      const ext = await this.extensionRepo.findOne({ where: { id: dto.destinoId, tenantId } });
      if (!ext) throw new BadRequestException('Esa extensión no pertenece a este cliente');
      await this.freeswitch.escribirDidXml({
        numero: did.numero,
        tenantId,
        subdominioTenant: tenant.subdominio,
        destinoTipo: 'extension',
        destinoExtensionNumero: ext.numero,
        trunkProveedorNombre: trunkProveedor?.nombre,
      });
    } else if (dto.destinoTipo === DidDestinoTipo.IVR) {
      const ivr = await this.ivrRepo.findOne({ where: { id: dto.destinoId, tenantId } });
      if (!ivr) throw new BadRequestException('Ese IVR no pertenece a este cliente');
      await this.freeswitch.escribirDidXml({
        numero: did.numero,
        tenantId,
        subdominioTenant: tenant.subdominio,
        destinoTipo: 'ivr',
        destinoIvrId: ivr.id,
        trunkProveedorNombre: trunkProveedor?.nombre,
      });
    }

    return this.repo.save(did);
  }

  async eliminar(id: string): Promise<void> {
    const did = await this.obtener(id);
    await this.freeswitch.eliminarDidXml(did.numero).catch(() => undefined);
    await this.repo.remove(did);
  }

  private async obtener(id: string): Promise<Did> {
    const did = await this.repo.findOne({ where: { id } });
    if (!did) throw new NotFoundException('Número SIP no encontrado');
    return did;
  }
}
