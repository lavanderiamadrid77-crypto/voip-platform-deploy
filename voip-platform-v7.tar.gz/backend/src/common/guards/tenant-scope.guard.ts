import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Rol } from '../entities/user.entity';

/**
 * Además de RolesGuard (que solo mira el rol), este guard impide que un
 * ADMIN (administrador a nivel de un cliente/tenant concreto) acceda a
 * recursos de OTRO tenant simplemente cambiando el :tenantId de la URL.
 * super_admin no tiene esta restricción (gestiona todos los tenants).
 */
@Injectable()
export class TenantScopeGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest();
    const { user } = req;
    const tenantIdRuta = req.params?.tenantId;
    if (!user || !tenantIdRuta) return true;
    if (user.rol === Rol.ADMIN && user.tenantId !== tenantIdRuta) {
      throw new ForbiddenException('No tienes acceso a los recursos de otro cliente');
    }
    return true;
  }
}
