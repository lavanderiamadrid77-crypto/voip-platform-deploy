import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { AudioPrompt } from './audio-prompt.entity';
import { Tenant } from './tenant.entity';
import { IvrOption } from './ivr-option.entity';

/**
 * Un IVR ("respuesta automática"): reproduce una locución de bienvenida y
 * espera que el que llama pulse un dígito, según las IvrOption asociadas.
 * Se genera como dialplan dinámico (ver FreeswitchService.escribirIvrXml)
 * y puede ser el destino de un Did (número entrante) o de otra opción de
 * IVR (submenús).
 */
@Entity('ivrs')
export class Ivr {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' })
  tenant: Tenant;

  @Column()
  tenantId: string;

  @Column()
  nombre: string;

  @ManyToOne(() => AudioPrompt, { nullable: true, onDelete: 'SET NULL' })
  promptBienvenida?: AudioPrompt;

  @Column({ nullable: true })
  promptBienvenidaId?: string;

  /** Segundos que espera un dígito antes de repetir el menú */
  @Column({ default: 7 })
  timeoutSegundos: number;

  @OneToMany(() => IvrOption, (opcion) => opcion.ivr, { cascade: true, orphanedRowAction: 'delete' })
  opciones: IvrOption[];

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;

  @UpdateDateColumn()
  actualizadoEn: Date;
}
