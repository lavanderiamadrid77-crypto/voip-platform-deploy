import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Ivr } from './ivr.entity';

export enum IvrOpcionDestinoTipo {
  EXTENSION = 'extension',
  IVR = 'ivr',
}

/** Una opción de menú dentro de un Ivr: "si pulsa 1, vaya a X" */
@Entity('ivr_options')
export class IvrOption {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Ivr, (ivr) => ivr.opciones, { onDelete: 'CASCADE' })
  ivr: Ivr;

  @Column()
  ivrId: string;

  /** Un solo dígito: 0-9 */
  @Column()
  digito: string;

  @Column({ type: 'enum', enum: IvrOpcionDestinoTipo })
  destinoTipo: IvrOpcionDestinoTipo;

  /** id de Extension o de Ivr (submenú), según destinoTipo */
  @Column()
  destinoId: string;

  @Column({ nullable: true })
  etiqueta?: string;
}
