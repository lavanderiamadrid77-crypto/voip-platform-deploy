import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('cdr')
@Index(['tenantId', 'fechaHoraInicio'])
export class Cdr {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column({ nullable: true })
  callUuid?: string;

  @Column()
  origen: string;

  @Column()
  destino: string;

  @Column()
  fechaHoraInicio: Date;

  @Column({ default: 0 })
  duracionSegundos: number;

  @Column({ default: 'desconocido' })
  estado: string;

  @Column('decimal', { precision: 10, scale: 5, default: 0 })
  costo: number;

  @Column('decimal', { precision: 10, scale: 5, default: 0 })
  venta: number;

  @Column({ nullable: true })
  trunkUsado?: string;

  @Column({ default: 'interna' })
  direccion: string;

  @Column({ nullable: true })
  grabacionUrl?: string;

  @CreateDateColumn()
  creadoEn: Date;
}
