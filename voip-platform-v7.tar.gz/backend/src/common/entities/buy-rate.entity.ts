import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Trunk } from './trunk.entity';

/**
 * Tarifa de COMPRA: lo que nos cobra un proveedor (Trunk) por minuto según
 * el prefijo del número destino. Coincidencia por prefijo más largo (LCR
 * clásico): "34" (España) es más genérico que "34911" (Madrid fijo).
 */
@Entity('buy_rates')
@Index(['trunkId', 'prefijo'], { unique: true })
export class BuyRate {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Trunk, { onDelete: 'CASCADE' })
  trunk: Trunk;

  @Column()
  trunkId: string;

  /** Prefijo del número destino, sin "+". Vacío = tarifa por defecto (catch-all) */
  @Column({ default: '' })
  prefijo: string;

  @Column({ nullable: true })
  descripcion?: string;

  @Column('decimal', { precision: 10, scale: 5, default: 0 })
  precioPorMinuto: number;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;
}
