import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Tenant } from './tenant.entity';

/**
 * Tarifa de VENTA: lo que le cobramos a un cliente (Tenant) por minuto
 * según el prefijo del número destino. tenantId nulo = tarifa por defecto
 * de la plataforma, aplicada a cualquier tenant sin tarifa propia para ese
 * prefijo (se resuelve primero la específica del tenant, luego la global).
 */
@Entity('sell_rates')
@Index(['tenantId', 'prefijo'], { unique: true })
export class SellRate {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Tenant, { nullable: true, onDelete: 'CASCADE' })
  tenant?: Tenant;

  @Column({ nullable: true })
  tenantId?: string;

  /** Prefijo del número destino, sin "+". Vacío = tarifa por defecto (catch-all) */
  @Column({ default: '' })
  prefijo: string;

  @Column({ nullable: true })
  descripcion?: string;

  @Column('decimal', { precision: 10, scale: 5, default: 0 })
  precioPorMinuto: number;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;
}
