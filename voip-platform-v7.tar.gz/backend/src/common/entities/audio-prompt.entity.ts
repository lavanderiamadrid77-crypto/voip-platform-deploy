import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Tenant } from './tenant.entity';

/**
 * Una "locución": un audio (saludo, mensaje de IVR, etc.) grabado o subido
 * por el cliente. Se almacena ya transcodificado a WAV mono 8kHz (formato
 * que FreeSWITCH reproduce sin problemas) en el volumen compartido de
 * prompts, en la ruta relativa `archivoRelativo` dentro de la carpeta del
 * tenant (ver FreeswitchService.rutaPromptsTenant).
 */
@Entity('audio_prompts')
export class AudioPrompt {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' })
  tenant: Tenant;

  @Column()
  tenantId: string;

  @Column()
  nombre: string;

  /** Ruta relativa dentro de la carpeta del tenant en el volumen de prompts, ej: "abc123.wav" */
  @Column()
  archivoRelativo: string;

  @Column({ nullable: true })
  duracionSegundos?: number;

  @CreateDateColumn()
  creadoEn: Date;
}
