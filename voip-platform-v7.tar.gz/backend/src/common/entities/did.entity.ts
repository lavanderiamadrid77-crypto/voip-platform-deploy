import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Tenant } from './tenant.entity';
import { Trunk } from './trunk.entity';

export enum DidDestinoTipo {
  EXTENSION = 'extension',
  IVR = 'ivr',
  NINGUNO = 'ninguno',
}

/**
 * Un "Did" es un número SIP/PSTN (número de teléfono) que la plataforma
 * puede recibir de un proveedor (Trunk) y enrutar hacia dentro de la
 * centralita de un cliente (Tenant): a una extensión concreta o a un IVR.
 *
 * Mientras `destinoTipo` sea NINGUNO (o el DID no tenga tenant asignado),
 * el dialplan público sigue rechazando la llamada (ver
 * freeswitch/conf/dialplan/public/00_inbound_placeholder.xml).
 */
@Entity('dids')
export class Did {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Número en formato E.164 o el formato que envíe el proveedor, ej: "34911234567" */
  @Column({ unique: true })
  @Index()
  numero: string;

  @Column({ nullable: true })
  descripcion?: string;

  /** Nulo = número aún en el "pool", sin asignar a ningún cliente */
  @ManyToOne(() => Tenant, { nullable: true, onDelete: 'SET NULL' })
  tenant?: Tenant;

  @Column({ nullable: true })
  tenantId?: string;

  /** Proveedor por el que se espera que llegue este número (informativo, para tarifas de compra) */
  @ManyToOne(() => Trunk, { nullable: true, onDelete: 'SET NULL' })
  trunkProveedor?: Trunk;

  @Column({ nullable: true })
  trunkProveedorId?: string;

  @Column({ type: 'enum', enum: DidDestinoTipo, default: DidDestinoTipo.NINGUNO })
  destinoTipo: DidDestinoTipo;

  /** id de Extension o de Ivr, según destinoTipo */
  @Column({ nullable: true })
  destinoId?: string;

  @Column({ default: true })
  activo: boolean;

  @CreateDateColumn()
  creadoEn: Date;

  @UpdateDateColumn()
  actualizadoEn: Date;
}
