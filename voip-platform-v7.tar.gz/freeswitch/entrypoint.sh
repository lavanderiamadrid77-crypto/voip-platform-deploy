#!/bin/bash
set -euo pipefail

CONF_DIR="/etc/freeswitch"

# 1) Sustituye SOLO la variable FREESWITCH_ESL_PASSWORD dentro de la
#    plantilla de event_socket.conf. Se limita explícitamente la lista de
#    variables a sustituir para no tocar por accidente la sintaxis nativa
#    de FreeSWITCH (${...} y $${...}) que aparece en el resto de ficheros.
: "${FREESWITCH_ESL_PASSWORD:?Debes definir FREESWITCH_ESL_PASSWORD}"
envsubst '${FREESWITCH_ESL_PASSWORD}' \
  < "${CONF_DIR}/autoload_configs/event_socket.conf.xml.template" \
  > "${CONF_DIR}/autoload_configs/event_socket.conf.xml"

# 2) Certificados TLS para el perfil WSS (webphone). En este entorno de
#    pruebas se generan autofirmados si no existen; en producción real
#    debes sustituirlos por certificados válidos (Let's Encrypt, etc.)
#    montando el volumen correspondiente.
TLS_DIR="${CONF_DIR}/tls"
mkdir -p "$TLS_DIR"
if [ ! -f "$TLS_DIR/wss.pem" ]; then
  echo "[entrypoint] Generando certificado TLS autofirmado para WSS (solo pruebas)..."
  openssl req -x509 -newkey rsa:2048 -keyout "$TLS_DIR/wss.key" -out "$TLS_DIR/wss.crt" \
    -days 365 -nodes -subj "/CN=${FREESWITCH_DOMAIN:-plataforma.local}"
  cat "$TLS_DIR/wss.crt" "$TLS_DIR/wss.key" > "$TLS_DIR/wss.pem"
fi

# 3) Directorios dinámicos que el backend rellena (extensiones/tenants/gateways)
mkdir -p "${CONF_DIR}/directory" "${CONF_DIR}/sip_profiles/external"

echo "[entrypoint] Arrancando FreeSWITCH..."
exec freeswitch -nonat -nf -c
